# AETHER AI — VISUAL DESIGN SYSTEM SPECIFICATION
**Version**: 3.0.0 (Obsidian Spatial Edition)  
**Author**: Principal Product Designer & Senior Android UI Engineer  
**Status**: APPROVED & IMPLEMENTED  

---

## 1. Spatial Surface Ladder & Color Architecture

AETHER AI builds depth using an **inky surface ladder** where physical elevation correlates with subtle tone shifts and 1px specular highlight rims, rather than diffuse muddy drop shadows.

```
Elevation Level      Color Token      Hex Value       Material Description
─────────────────────────────────────────────────────────────────────────────
Z0 (Deep Canvas)     CanvasBase       #040711         Cosmic inky void background
Z1 (Workspace Tray)  SurfaceDeep      #080D1A         Recessed docking trays & grids
Z2 (Floating Window) SurfaceWindow    #0E1626 (88%)   Frosted glass window container
Z3 (Active Focus)    SurfaceElevated  #152033 (94%)   Active window header & dialogs
Z4 (Top Floating)    SurfaceOverlay   #1C2A44 (98%)   Command palette & companion dock
```

### Hairline Specular Borders
Containers use a 1px composite border that catches ambient light at the top edge:
- Top / Leading Edge: `rgba(0, 240, 255, 0.40)` (Electric Cyan highlight)
- Bottom / Trailing Edge: `rgba(255, 255, 255, 0.05)` (Subtle metallic rim)

### Punctuation Color Roles
- **Electric Cyan (`#00F0FF`)**: Active focus states, selected tabs, compiler success, AETHER CORE energy.
- **Neon Violet (`#8B5CF6`)**: AI reasoning, autonomous agent thoughts, companion knowledge queries.
- **Holo Emerald (`#10B981`)**: Verified command execution, patch applied, tests passing, normal thermal state.
- **Holo Amber (`#F59E0B`)**: Pinned windows, moderate thermal throttling, security audit warnings.
- **Holo Rose (`#F43F5E`)**: Critical vulnerabilities, terminal syntax errors, emergency stop controls.

---

## 2. Typography & Information Density

- **Display & Section Headers**: Inter / System Sans with SemiBold (600) and Bold (700) weight, tracking `+0.2px` to prevent dark-mode optical glow bleed.
- **Body & Controls**: Clean sans-serif with minimum 13sp–14sp sizing for effortless readability against dark glass.
- **Telemetry, Code & Terminal**: Strict Monospace (`FontFamily.Monospace`) for tabular alignment, memory numbers, line numbers, and shell logs.

---

## 3. Motion & Physics System

- **Window Repositioning**: Zero lag during dragging; touch tracking directly updates viewport offsets (`change.consume()`).
- **Snapping & Layout Presets**: Smooth spring animation (`spring(dampingRatio = 0.8f, stiffness = 400f)`) for snap-to-grid and preset transitions under 220ms.
- **Companion Floating Idle**: Continuous gentle sinusoidal wave (`tween(2000, easing = FastOutSlowInEasing)`).
- **Reduced-Motion Support**: Respects system `Settings.Global.ANIMATOR_DURATION_SCALE`; disables ambient particle drift and floating bobbing when reduced motion is requested.

---

## 4. Mobile Ergonomics & Viewport Scaling

1. **Thumb-Zone Prioritization**: Primary workspace toggles, command execution triggers, and companion summoning controls are situated in the lower 40% of the screen.
2. **Dynamic Clamping**: Window dragging automatically clamps coordinates to ensure window title bars and controls never move off-screen or become unreachable.
3. **Responsive Split Modes**:
   - Portrait Phone (< 600dp): Floating stacking mode with quick-switch dock pills and 50/50 vertical split.
   - Landscape / Tablet (> 600dp): Multi-column spatial layout with side-by-side editor, terminal, and agent views.
