# AETHER AI — COMPONENT CATALOG & ATOMIC UI SPECIFICATION
**Version**: 3.0.0  
**Design System**: Obsidian Spatial System  

---

## 1. Atomic & Molecular Components

| Component | Visual Specification | Interactive Behavior | Touch Target |
|:---|:---|:---|:---|
| **AetherButton (Primary)** | Electric Cyan fill (`#00F0FF`), inky black text (`#001E26`), 8dp rounded corners. | Ripple feedback on touch; subtle brightness increase on press. | Minimum 48dp x 36dp |
| **AetherButton (Secondary)** | Dark glass surface (`#162238`), 1px metallic border, white text (`#F8FAFC`). | Glow highlight on press. | Minimum 48dp x 36dp |
| **WindowHeaderBar** | Elevated glass header (`#141F33`), title, status dot, pin, max, min, close actions. | Header area initiates window dragging; double tap toggles maximize. | 38dp height, 32dp action buttons |
| **GripResizeHandle** | Bottom-right angled metallic hatch icon (`#38BDF866`). | Dragging expands/shrinks window width and height with boundary limits. | 28dp x 28dp corner touch zone |
| **CompanionAvatar3D** | Procedural 3D robot bust with glowing sensor visor, holographic orbital crest ring, and halo. | Tap cycles companion role; drag positions companion anywhere on screen. | 64dp x 64dp |
| **CompanionSpeechChip** | Compact frosted glass bubble with cyan/violet hairline stroke and dismiss button. | Floats above companion; auto-updates on agent/terminal events; tap dismisses. | 32dp height, max 240dp width |
| **CommandPaletteBar** | Pill-shaped glass container with search icon, input field, and execute trigger. | Expands with quick-action suggestions on focus; submits commands on enter. | 44dp height |
| **CodeEditorGutter** | Monospace line number strip (`#64748B`), active line highlighted in cyan. | Tab switching, undo/redo buttons in compact 28dp height header bar. | Full height, 36dp gutter width |
| **TerminalExecutionCard** | Deep black console box (`#020409`), green monospace output (`#4ADE80`), duration chip. | Live stream text appended automatically; scroll state auto-advances. | Dynamic height |
| **UnifiedDiffCard** | Dual-tone lines: additions in emerald green (`#064E3B`/`#6EE7B7`), deletions in rose (`#7F1D1D`/`#FCA5A5`). | "Approve & Apply" button mutates file on disk; "Reject" discards. | 36dp action buttons |
| **TelemetryPill** | Rounded 8dp chip with icon, metric label, and colored status dot. | Tap refreshes hardware telemetry immediately. | 26dp height |
| **OrbitDockOrb** | 36dp circular glass sphere with metallic border and glowing subsystem icon. | Tap summons floating window or brings existing window to front. | 44dp touch area |
