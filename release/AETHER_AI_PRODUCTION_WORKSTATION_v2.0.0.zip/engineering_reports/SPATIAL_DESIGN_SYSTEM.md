# AETHER AI — SPATIAL 3D DESIGN SYSTEM SPECIFICATION
**Version**: 2.5.0 Spatial Edition  
**Author**: Principal Spatial UI/UX Architect & 3D Interaction Designer  
**Status**: IMPLEMENTED & PRODUCTION-READY  

---

## 1. Spatial Computing Philosophy & Aesthetic Vibe

AETHER AI abandons standard flat mobile application metaphors in favor of a **spatial computing workstation**. The environment models a floating cockpit where developers supervise multi-agent operations, edit code, and inspect system telemetry within a three-dimensional cosmic environment.

### Core Tenets
- **Spatial Elevation & Z-Layering**: Elements occupy defined depth planes (Z0 deep space canvas, Z1 interactive AETHER CORE, Z2 floating windows, Z3 active focus window, Z4 floating companion avatars & orbit dock).
- **Glassmorphic Tactility**: Windows use translucent dark glass (`#0E1626` at 85% opacity) with subtle metallic gradient rims (`#38BDF8` to `#475569`) and specular highlights.
- **Intelligent Motion**: Procedural 3D rotations, floating bobbing, and spring animations without disorienting motion.
- **Subdued Cybernetic Lighting**: Controlled cyan (`#00F0FF`), violet (`#8B5CF6`), and emerald (`#10B981`) accents replace harsh neon saturation.

---

## 2. Color Palette & Material Tokens

```
Canvas / Void:        #03060D (Deep Space Black)
                      #080D1A (Nebula Dark)
Glass Surfaces:       #0E1626 (85% alpha glassmorphism)
                      #162238 (95% alpha elevated glass)
Holographic Cyan:     #00F0FF (Primary core energy & active window border)
Holographic Violet:   #8B5CF6 (AI agent & companion secondary aura)
Holographic Emerald:  #10B981 (Terminal execution & success states)
Holographic Amber:    #F59E0B (Warnings, thermal elevation & pinned states)
Holographic Rose:     #F43F5E (Errors, security vulnerabilities & close controls)
```

---

## 3. The Interactive AETHER CORE

A central procedural 3D visual nucleus rendered via Compose Canvas with dynamic lighting:
- **Nested Isometric Gyroscope**: Outer rings rotate across X/Y/Z planes according to system load and user drag gestures.
- **Internal Tesseract Cube**: Wireframe geometric inner cube pulsating to indicate local model or cloud inference activity.
- **Orbital Subsystem Constellation**: Floating interactive nodes represent active tools (Editor, Terminal, Agent, Audit, Models) and can be clicked to summon windows.
- **Particle Field**: Background stars float in depth-sorted perspective with density dynamically scaled by the device's hardware tier.

---

## 4. Modular Floating Window Architecture (`FloatingWindowManager`)

A reusable window management system for mobile touchscreens:
- **Header Dragging**: Smooth repositioning across screen bounds.
- **Corner Resizing**: Dragging the bottom-right grip dynamically adjusts window width and height.
- **Maximize & Minimize**: Full-screen expansion or compact dock pill minimization.
- **Pinning**: Pinned windows maintain their topmost elevation during multi-tasking.
- **Stacking Order**: Tapping any part of a window brings it to the top (`zIndex`).

### Workspace Presets
1. **Developer**: Code Editor + Sandboxed Terminal.
2. **AI Agent**: ReAct Autonomous Loop + Terminal.
3. **Debugging**: Terminal + Security Scanner + Device Telemetry.
4. **Research**: Model Hub + Knowledge Memory + Editor.
5. **Minimal**: AETHER CORE 3D alone with floating companion.

---

## 5. Miniature 3D AI Companions

Seven distinct assistants with unique procedural 3D geometric avatars, orbital crest rings, and contextual thought bubbles:
1. **Architect**: System design & modular structure (Cyan/Violet).
2. **Coder**: Implementation & code generation (Emerald/Cyan).
3. **Debugger**: Error investigation & terminal diagnostics (Amber/Rose).
4. **Researcher**: Knowledge base & GGUF tables (Violet/Sky).
5. **Security Guardian**: Sandbox confinement & vulnerability protection (Rose/Amber).
6. **Build Engineer**: Compilation & Gradle optimization (Sky/Cyan).
7. **Project Manager**: Autonomous ReAct loop orchestration (Gold/Violet).
