package com.aether.spatial.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.editor.DiffLine
import com.aether.editor.DiffType
import com.aether.hardware.DeviceHardwareTier
import com.aether.hardware.ThermalStatus
import com.aether.inference.InferenceBackendType
import com.aether.project.AuditFinding
import com.aether.project.FindingSeverity
import com.aether.spatial.core.*
import com.aether.spatial.navigation.SpatialOrbitDock
import com.aether.spatial.window.FloatingWindowManager
import com.aether.spatial.window.SpatialWindow
import com.aether.spatial.window.WindowType
import com.aether.spatial.window.WorkspacePreset
import com.aether.ui.WorkstationUiState
import com.aether.ui.WorkstationViewModel
import java.io.File
import kotlin.math.roundToInt

@Composable
fun SpatialWorkstationScreen(
    viewModel: WorkstationViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val windowManager = remember { FloatingWindowManager() }
    var windowsTrigger by remember { mutableIntStateOf(0) }
    var activePreset by remember { mutableStateOf(WorkspacePreset.DEVELOPER) }
    var renderQuality by remember { mutableStateOf(SpatialRenderQuality.PERFORMANCE) }

    var companionRole by remember { mutableStateOf(CompanionRole.ARCHITECT) }
    var companionSpeech by remember { mutableStateOf<String?>(CompanionRole.ARCHITECT.defaultSpeech) }
    var isSpeechVisible by remember { mutableStateOf(true) }

    // Draggable companion position
    var companionOffset by remember { mutableStateOf(Offset(260f, 60f)) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    // React companion speech to system state
    LaunchedEffect(state.isAuditing, state.isInferenceRunning, state.isTerminalRunning, state.agentState.isRunning) {
        when {
            state.agentState.isRunning -> {
                companionRole = CompanionRole.PROJECT_MANAGER
                companionSpeech = "Autonomous ReAct loop active. Monitoring tool execution..."
                isSpeechVisible = true
            }
            state.isAuditing -> {
                companionRole = CompanionRole.SECURITY_GUARDIAN
                companionSpeech = "Scanning workspace tree for security leaks and static risks..."
                isSpeechVisible = true
            }
            state.isInferenceRunning -> {
                companionRole = CompanionRole.RESEARCHER
                companionSpeech = "Streaming local GGUF tokens at ${"%.1f".format(state.tokensPerSec)} tok/s..."
                isSpeechVisible = true
            }
            state.isTerminalRunning -> {
                companionRole = CompanionRole.DEBUGGER
                companionSpeech = "Executing sandboxed child process in workspace container."
                isSpeechVisible = true
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(SpatialColors.CanvasBase)
            .onGloballyPositioned { coordinates ->
                windowManager.updateScreenBounds(
                    coordinates.size.width.toFloat(),
                    coordinates.size.height.toFloat()
                )
            }
    ) {
        // -----------------------------------------------------------------
        // LAYER 1: OBSIDIAN SPATIAL CANVAS & TOP COMMAND BAR
        // -----------------------------------------------------------------
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Command Bar
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SpatialColors.SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderTop),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SpatialColors.HoloCyan))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AETHER AI",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SpatialColors.HoloCyan
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "WORKSTATION v2.5",
                                style = MaterialTheme.typography.labelSmall,
                                color = SpatialColors.HoloViolet,
                                fontSize = 10.sp
                            )
                        }

                        // Backend switcher chip
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SpatialColors.SurfaceDeep,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.MetallicSubtle),
                            modifier = Modifier.clickable {
                                val next = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) {
                                    InferenceBackendType.CLOUD_GEMINI
                                } else {
                                    InferenceBackendType.LOCAL_CPU_NEON
                                }
                                viewModel.switchBackend(next)
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) SpatialColors.HoloCyan else SpatialColors.HoloViolet)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) "Local ARM64 NEON" else "Cloud Gemini API",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = SpatialColors.TextPrimary
                                )
                            }
                        }
                    }

                    // Live Telemetry Bar
                    val profile = state.hardwareProfile
                    if (profile != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val ramPct = if (profile.totalRamMb > 0) ((profile.totalRamMb - profile.availableRamMb) * 100 / profile.totalRamMb).toInt() else 0
                            TelemetryChip(Icons.Default.Memory, "RAM ${profile.availableRamMb}M Free (${ramPct}%)", SpatialColors.HoloCyan)
                            TelemetryChip(Icons.Default.Speed, "${profile.cpuCoreCount} Cores (${profile.cpuArchitecture})", SpatialColors.HoloSky)
                            TelemetryChip(
                                Icons.Default.Thermostat,
                                profile.thermalStatus.label,
                                if (profile.thermalStatus == ThermalStatus.NORMAL) SpatialColors.HoloEmerald else SpatialColors.HoloAmber
                            )
                            TelemetryChip(
                                if (profile.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                "${profile.batteryPercent}%",
                                if (profile.batteryPercent < 20) SpatialColors.HoloRose else SpatialColors.TextSecondary
                            )
                            TelemetryChip(Icons.Default.Grade, profile.effectiveTier.label, SpatialColors.HoloViolet)
                        }
                    }
                }
            }

            // Compact Ambient 3D AETHER CORE HUD
            AetherCore3D(
                systemLoadPct = 0.35f,
                quality = renderQuality,
                onNodeClicked = { typeStr ->
                    try {
                        val type = WindowType.valueOf(typeStr)
                        windowManager.openWindow(type)
                        windowsTrigger++
                    } catch (_: Exception) {}
                }
            )
        }

        // -----------------------------------------------------------------
        // LAYER 2: DRAGGABLE MINIATURE 3D AI COMPANION
        // -----------------------------------------------------------------
        Miniature3DCompanion(
            companionState = CompanionState(
                role = companionRole,
                currentSpeech = companionSpeech,
                isSpeechVisible = isSpeechVisible
            ),
            modifier = Modifier
                .offset { IntOffset(companionOffset.x.roundToInt(), companionOffset.y.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        companionOffset = Offset(
                            (companionOffset.x + dragAmount.x).coerceIn(10f, 800f),
                            (companionOffset.y + dragAmount.y).coerceIn(40f, 1600f)
                        )
                    }
                },
            onCompanionClicked = {
                val all = CompanionRole.values()
                val nextIdx = (companionRole.ordinal + 1) % all.size
                companionRole = all[nextIdx]
                companionSpeech = companionRole.defaultSpeech
                isSpeechVisible = true
            },
            onActionClicked = { role ->
                when (role) {
                    CompanionRole.ARCHITECT -> windowManager.openWindow(WindowType.AGENT)
                    CompanionRole.CODER -> windowManager.openWindow(WindowType.EDITOR)
                    CompanionRole.DEBUGGER -> windowManager.openWindow(WindowType.TERMINAL)
                    CompanionRole.RESEARCHER -> windowManager.openWindow(WindowType.MODELS)
                    CompanionRole.SECURITY_GUARDIAN -> windowManager.openWindow(WindowType.AUDIT)
                    CompanionRole.BUILD_ENGINEER -> windowManager.openWindow(WindowType.TERMINAL)
                    CompanionRole.PROJECT_MANAGER -> windowManager.openWindow(WindowType.AGENT)
                }
                windowsTrigger++
            },
            onDismissSpeech = { isSpeechVisible = false }
        )

        // -----------------------------------------------------------------
        // LAYER 3: MODULAR FLOATING WINDOW SYSTEM
        // -----------------------------------------------------------------
        val windowsList = remember(windowsTrigger) { windowManager.getAllWindows() }

        for (win in windowsList) {
            SpatialWindow(
                windowState = win,
                onMove = { delta ->
                    windowManager.moveWindow(win.type, delta)
                    windowsTrigger++
                },
                onResize = { dW, dH ->
                    windowManager.resizeWindow(win.type, dW, dH)
                    windowsTrigger++
                },
                onFocus = {
                    windowManager.bringToFront(win.type)
                    windowsTrigger++
                },
                onClose = {
                    windowManager.closeWindow(win.type)
                    windowsTrigger++
                },
                onMinimize = {
                    windowManager.minimizeWindow(win.type)
                    windowsTrigger++
                },
                onToggleMaximize = {
                    windowManager.toggleMaximize(win.type)
                    windowsTrigger++
                },
                onTogglePin = {
                    windowManager.togglePin(win.type)
                    windowsTrigger++
                }
            ) {
                when (win.type) {
                    WindowType.EDITOR -> FloatingEditorContent(state, viewModel)
                    WindowType.TERMINAL -> FloatingTerminalContent(state, viewModel)
                    WindowType.AGENT -> FloatingAgentContent(state, viewModel)
                    WindowType.AUDIT -> FloatingAuditContent(state, viewModel, onReviewPatch = { finding ->
                        viewModel.reviewFindingPatch(finding)
                        windowManager.openWindow(WindowType.EDITOR)
                        windowsTrigger++
                    })
                    WindowType.MODELS -> FloatingModelsContent(state, viewModel)
                    WindowType.DEVICE_MONITOR -> FloatingDeviceMonitorContent(state, renderQuality) { renderQuality = it }
                    WindowType.MEMORY -> FloatingMemoryContent(state, viewModel)
                    WindowType.SETTINGS -> FloatingSettingsContent(state, viewModel)
                }
            }
        }

        // -----------------------------------------------------------------
        // LAYER 4: SPATIAL ORBIT DOCK
        // -----------------------------------------------------------------
        SpatialOrbitDock(
            activeWindows = windowsList.filter { it.isVisible && !it.isMinimized }.map { it.type },
            currentPreset = activePreset,
            activeCompanion = companionRole,
            modifier = Modifier.align(Alignment.BottomCenter).windowInsetsPadding(WindowInsets.navigationBars),
            onOpenWindow = { type ->
                windowManager.openWindow(type)
                windowsTrigger++
            },
            onApplyPreset = { preset ->
                activePreset = preset
                windowManager.applyPreset(preset)
                windowsTrigger++
            },
            onSelectCompanion = { role ->
                companionRole = role
                companionSpeech = role.defaultSpeech
                isSpeechVisible = true
            }
        )

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 90.dp)
        )
    }
}

@Composable
fun TelemetryChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .background(SpatialColors.SurfaceDeep, RoundedCornerShape(6.dp))
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(11.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(label, fontSize = 10.sp, color = SpatialColors.TextPrimary, fontFamily = FontFamily.Monospace)
    }
}

// -------------------------------------------------------------------------
// REFACTORED FLOATING MODULE CONTENTS
// -------------------------------------------------------------------------

@Composable
fun FloatingEditorContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Tab row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(SpatialColors.SurfaceElevated)
                .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.openTabs.indices.toList()) { index ->
                val tab = state.openTabs[index]
                val isActive = tab == state.activeTab
                Surface(
                    shape = RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp),
                    color = if (isActive) SpatialColors.CanvasBase else SpatialColors.SurfaceDeep,
                    border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderTop) else null,
                    modifier = Modifier.clickable { viewModel.selectEditorTab(index) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = tab.fileName + if (tab.isDirty) " *" else "",
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            color = if (isActive) SpatialColors.HoloCyan else SpatialColors.TextSecondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = SpatialColors.TextMuted,
                            modifier = Modifier.size(12.dp).clickable { viewModel.closeEditorTab(index) }
                        )
                    }
                }
            }
        }

        // Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(SpatialColors.SurfaceDeep)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = { viewModel.saveActiveFile() },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloCyan, contentColor = Color.Black),
                    modifier = Modifier.height(28.dp).testTag("save_file_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = { viewModel.undoEditor() }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo", tint = SpatialColors.TextPrimary, modifier = Modifier.size(14.dp))
                }
                IconButton(onClick = { viewModel.redoEditor() }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Redo, contentDescription = "Redo", tint = SpatialColors.TextPrimary, modifier = Modifier.size(14.dp))
                }
            }

            Text(
                text = "${state.symbols.size} symbols",
                fontSize = 10.sp,
                color = SpatialColors.HoloViolet,
                fontFamily = FontFamily.Monospace
            )
        }

        // Editor Buffer with integrated Line Numbers Gutter
        val activeTab = state.activeTab
        if (activeTab != null) {
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                // Line Number Gutter
                val lineCount = activeTab.content.lines().size.coerceAtLeast(1)
                val gutterText = (1..lineCount).joinToString("\n") { it.toString().padStart(3) }
                Surface(
                    color = SpatialColors.SurfaceDeep.copy(alpha = 0.8f),
                    modifier = Modifier.width(34.dp).fillMaxHeight()
                ) {
                    Text(
                        text = gutterText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = SpatialColors.TextMuted,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp)
                    )
                }

                OutlinedTextField(
                    value = activeTab.content,
                    onValueChange = { viewModel.updateEditorContent(it) },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .testTag("code_editor_field"),
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = SpatialColors.TextPrimary
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SpatialColors.CanvasBase,
                        unfocusedContainerColor = SpatialColors.CanvasBase,
                        focusedBorderColor = SpatialColors.HoloCyan,
                        unfocusedBorderColor = SpatialColors.SpecularBorderBase
                    )
                )
            }
        } else {
            Box(modifier = Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No file currently open", color = SpatialColors.TextMuted, fontSize = 12.sp)
            }
        }

        // Pending Unified Diff Review Card
        if (state.pendingDiffLines.isNotEmpty() && state.pendingDiffFile != null) {
            Surface(
                color = SpatialColors.SurfaceElevated,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.HoloCyan),
                modifier = Modifier.fillMaxWidth().heightIn(max = 150.dp).padding(4.dp)
            ) {
                Column(modifier = Modifier.padding(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Patch: ${File(state.pendingDiffFile ?: "").name}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = SpatialColors.HoloCyan
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.rejectPatch() },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.height(24.dp)
                            ) {
                                Text("Reject", fontSize = 10.sp, color = SpatialColors.HoloRose)
                            }
                            Button(
                                onClick = { viewModel.approveAndApplyPatch() },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloEmerald),
                                modifier = Modifier.height(24.dp).testTag("approve_patch_button")
                            ) {
                                Text("Approve & Apply", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(SpatialColors.CanvasBase)
                            .padding(4.dp)
                    ) {
                        items(state.pendingDiffLines) { diff ->
                            val color = when (diff.type) {
                                DiffType.ADDITION -> SpatialColors.HoloEmerald
                                DiffType.DELETION -> SpatialColors.HoloRose
                                DiffType.CONTEXT -> SpatialColors.TextMuted
                            }
                            val prefix = when (diff.type) {
                                DiffType.ADDITION -> "+ "
                                DiffType.DELETION -> "- "
                                DiffType.CONTEXT -> "  "
                            }
                            Text(
                                text = "$prefix${diff.text}",
                                color = color,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingTerminalContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    var commandInput by remember { mutableStateOf("") }
    val quickCmds = listOf("git status", "ls -la", "pwd", "find . -maxdepth 2", "cat MainActivity.kt")

    Column(modifier = Modifier.fillMaxSize().padding(6.dp)) {
        // Quick allowlisted commands
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(quickCmds) { cmd ->
                SuggestionChip(
                    onClick = {
                        commandInput = cmd
                        viewModel.runTerminalCommand(cmd)
                    },
                    label = { Text(cmd, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = SpatialColors.SurfaceDeep),
                    modifier = Modifier.height(24.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Monospace Terminal Console
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF020408), RoundedCornerShape(8.dp))
                .border(1.dp, SpatialColors.SpecularBorderBase, RoundedCornerShape(8.dp))
                .padding(8.dp)
        ) {
            val scroll = rememberScrollState()
            LaunchedEffect(state.terminalOutput) {
                scroll.animateScrollTo(scroll.maxValue)
            }
            Text(
                text = state.terminalOutput,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color(0xFF4ADE80),
                modifier = Modifier.verticalScroll(scroll)
            )
            if (state.isTerminalRunning) {
                CircularProgressIndicator(
                    color = SpatialColors.HoloCyan,
                    modifier = Modifier.size(16.dp).align(Alignment.TopEnd),
                    strokeWidth = 2.dp
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Input bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                singleLine = true,
                placeholder = { Text("Command...", fontSize = 11.sp) },
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier.weight(1f).testTag("terminal_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SpatialColors.SurfaceDeep,
                    unfocusedContainerColor = SpatialColors.SurfaceDeep
                )
            )
            Button(
                onClick = {
                    viewModel.runTerminalCommand(commandInput)
                    commandInput = ""
                },
                enabled = !state.isTerminalRunning && commandInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloCyan, contentColor = Color.Black),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(36.dp).testTag("terminal_run_button")
            ) {
                Text("Run", fontSize = 11.sp)
            }
            IconButton(onClick = { viewModel.clearTerminal() }, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Clear", tint = SpatialColors.TextMuted)
            }
        }
    }
}

@Composable
fun FloatingAgentContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    var objective by remember { mutableStateOf("Audit workspace for security vulnerabilities and optimize code") }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        OutlinedTextField(
            value = objective,
            onValueChange = { objective = it },
            label = { Text("ReAct Agent Objective", fontSize = 11.sp) },
            modifier = Modifier.fillMaxWidth().testTag("agent_objective_field")
        )
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            onClick = { viewModel.startReActAgent(objective) },
            enabled = !state.agentState.isRunning && objective.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloViolet),
            modifier = Modifier.align(Alignment.End).height(32.dp).testTag("start_agent_button"),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
        ) {
            if (state.agentState.isRunning) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reasoning...", fontSize = 11.sp)
            } else {
                Text("Launch ReAct Loop", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.agentState.steps) { step ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = SpatialColors.SurfaceDeep,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderBase)
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Step ${step.stepIndex}: ${step.selectedTool}", fontWeight = FontWeight.Bold, color = SpatialColors.HoloCyan, fontSize = 11.sp)
                        }
                        Text("Thought: ${step.thought}", fontSize = 10.sp, color = SpatialColors.TextSecondary)
                        Text("Obs: ${step.observation}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = SpatialColors.HoloSky)
                    }
                }
            }

            if (state.agentState.finalOutput != null) {
                item {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SpatialColors.SurfaceElevated,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.HoloEmerald)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Synthesis Complete", fontWeight = FontWeight.Bold, color = SpatialColors.HoloEmerald, fontSize = 11.sp)
                            Text(state.agentState.finalOutput ?: "", fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingAuditContent(
    state: WorkstationUiState,
    viewModel: WorkstationViewModel,
    onReviewPatch: (AuditFinding) -> Unit
) {
    val report = state.auditReport

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = if (report != null) "Health Score: ${report.healthScore}/100" else "Security Scanner Ready",
                    fontWeight = FontWeight.Bold,
                    color = SpatialColors.HoloAmber,
                    fontSize = 12.sp
                )
                Text(
                    text = if (report != null) "${report.scannedFilesCount} files scanned in ${report.scanDurationMs}ms" else "Recursive workspace analysis",
                    fontSize = 10.sp,
                    color = SpatialColors.TextMuted
                )
            }
            Button(
                onClick = { viewModel.runProjectAudit() },
                enabled = !state.isAuditing,
                colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloAmber),
                modifier = Modifier.height(28.dp).testTag("run_audit_button"),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("Scan", fontSize = 11.sp, color = Color.Black)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        if (report != null) {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(report.findings) { finding ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SpatialColors.SurfaceDeep,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderBase)
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(finding.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = SpatialColors.TextPrimary)
                                Text(finding.severity.name, fontSize = 9.sp, color = SpatialColors.HoloRose)
                            }
                            Text(finding.description, fontSize = 10.sp, color = SpatialColors.TextMuted)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = { onReviewPatch(finding) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloCyan, contentColor = Color.Black),
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 1.dp),
                                    modifier = Modifier.height(22.dp)
                                ) {
                                    Text("Patch", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingModelsContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    var prompt by remember { mutableStateOf("Write a Kotlin coroutine routine.") }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            items(state.availableModels) { model ->
                val isSelected = model.id == state.activeLoadedModel?.id
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) SpatialColors.HoloCyan.copy(alpha = 0.2f) else SpatialColors.SurfaceDeep,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) SpatialColors.HoloCyan else SpatialColors.SpecularBorderBase),
                    modifier = Modifier.clickable { viewModel.selectModel(model) }
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text(model.name, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = if (isSelected) SpatialColors.HoloCyan else SpatialColors.TextPrimary)
                        Text("${model.sizeMb}MB • ${model.quantization.name}", fontSize = 9.sp, color = SpatialColors.TextMuted)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(Color(0xFF020408), RoundedCornerShape(6.dp))
                .border(1.dp, SpatialColors.SpecularBorderBase, RoundedCornerShape(6.dp))
                .padding(6.dp)
        ) {
            val scroll = rememberScrollState()
            Text(
                text = if (state.inferenceOutput.isBlank()) "Model: ${state.activeLoadedModel?.name ?: "None"}\nStreaming console ready." else state.inferenceOutput,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = SpatialColors.TextPrimary,
                modifier = Modifier.verticalScroll(scroll)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("inference_prompt_input"),
                textStyle = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
            )
            Button(
                onClick = { viewModel.runInference(prompt) },
                enabled = !state.isInferenceRunning,
                colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloCyan, contentColor = Color.Black),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(36.dp).testTag("run_inference_button")
            ) {
                Text("Gen", fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun FloatingDeviceMonitorContent(
    state: WorkstationUiState,
    renderQuality: SpatialRenderQuality,
    onSetRenderQuality: (SpatialRenderQuality) -> Unit
) {
    val profile = state.hardwareProfile

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Device Capability & 3D Engine", fontWeight = FontWeight.Bold, color = SpatialColors.HoloCyan, fontSize = 12.sp)

        if (profile != null) {
            Text("Hardware: ${profile.manufacturer} ${profile.model}", fontSize = 11.sp)
            Text("CPU: ${profile.cpuArchitecture} (${profile.cpuCoreCount} Cores, NEON: ${profile.supportsNeon})", fontSize = 10.sp, color = SpatialColors.TextMuted)
            Text("RAM: ${profile.availableRamMb}MB Free / ${profile.totalRamMb}MB Total", fontSize = 10.sp, color = SpatialColors.HoloSky)
            Text("Safe Model Budget: ${profile.maxSafeModelRamMb}MB", fontSize = 10.sp, color = SpatialColors.HoloEmerald)
            Text("Thermal: ${profile.thermalStatus.label}", fontSize = 10.sp, color = if (profile.thermalStatus == ThermalStatus.NORMAL) SpatialColors.HoloEmerald else SpatialColors.HoloAmber)
        }

        HorizontalDivider(color = SpatialColors.SpecularBorderBase)

        Text("Adaptive 3D Rendering Quality", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = SpatialColors.HoloViolet)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            SpatialRenderQuality.values().forEach { q ->
                val isSelected = renderQuality == q
                FilterChip(
                    selected = isSelected,
                    onClick = { onSetRenderQuality(q) },
                    label = { Text(q.label, fontSize = 9.sp) },
                    modifier = Modifier.height(26.dp)
                )
            }
        }
    }
}

@Composable
fun FloatingMemoryContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("Title", fontSize = 10.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        viewModel.addMemory("DECISION", title, content)
                        title = ""
                        content = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SpatialColors.HoloViolet),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Text("Add", fontSize = 10.sp)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.memories) { mem ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SpatialColors.SurfaceDeep,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderBase)
                ) {
                    Column(modifier = Modifier.padding(6.dp)) {
                        Text(mem.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = SpatialColors.HoloCyan)
                        Text(mem.content, fontSize = 10.sp, color = SpatialColors.TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
fun FloatingSettingsContent(state: WorkstationUiState, viewModel: WorkstationViewModel) {
    val profile = state.hardwareProfile

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text("Security & Sandboxing", fontWeight = FontWeight.Bold, color = SpatialColors.HoloCyan, fontSize = 12.sp)
        Text("• Canonical Path Confinement: ACTIVE", fontSize = 10.sp, color = SpatialColors.HoloEmerald)
        Text("• Keystore AES-256-GCM Wrapping: ACTIVE", fontSize = 10.sp, color = SpatialColors.HoloEmerald)
        Text("• Environment Secret Scrubbing: ACTIVE", fontSize = 10.sp, color = SpatialColors.HoloEmerald)
        Text("• SSRF & Loopback Blocker: ACTIVE", fontSize = 10.sp, color = SpatialColors.HoloEmerald)

        HorizontalDivider(color = SpatialColors.SpecularBorderBase)

        Text("Hardware Tier Override", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = SpatialColors.HoloViolet)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            DeviceHardwareTier.values().forEach { tier ->
                val isSelected = profile?.effectiveTier == tier
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.setDeviceTierOverride(if (profile?.userOverrideTier == tier) null else tier) },
                    label = { Text(tier.name.take(4), fontSize = 9.sp) },
                    modifier = Modifier.height(26.dp)
                )
            }
        }
    }
}
