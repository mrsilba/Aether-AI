package com.aether.spatial.window

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp

enum class WindowType(val title: String, val iconName: String) {
    EDITOR("Code Editor", "Code"),
    TERMINAL("Terminal", "Terminal"),
    AGENT("ReAct Agent", "SmartToy"),
    AUDIT("Security Audit", "Security"),
    MODELS("Models Hub", "Psychology"),
    MEMORY("Project Memory", "Storage"),
    DEVICE_MONITOR("Device Telemetry", "Speed"),
    SETTINGS("Settings", "Settings")
}

enum class WorkspacePreset(val label: String, val description: String) {
    DEVELOPER("Developer", "Editor & Sandboxed Terminal active"),
    AI_AGENT("AI Agent", "Autonomous ReAct Agent & MCP Inspector"),
    DEBUGGING("Debugging", "Terminal, Audit Scanner & Device Telemetry"),
    RESEARCH("Research", "Models Hub, Knowledge Memory & Editor"),
    MINIMAL("Minimal 3D Core", "AETHER CORE 3D environment & companions")
}

data class SpatialWindowState(
    val type: WindowType,
    val position: Offset = Offset(16f, 50f),
    val size: DpSize = DpSize(340.dp, 360.dp),
    val isVisible: Boolean = true,
    val isMinimized: Boolean = false,
    val isMaximized: Boolean = false,
    val isPinned: Boolean = false,
    val zIndex: Float = 1f
)

class FloatingWindowManager {

    private val windows = mutableMapOf<WindowType, SpatialWindowState>()
    private var nextZIndex = 1f
    private var screenWidthPx = 1080f
    private var screenHeightPx = 2200f

    init {
        // Initialize windows with standard default positions
        WindowType.values().forEachIndexed { index, type ->
            val offsetX = 12f + (index % 3) * 16f
            val offsetY = 36f + (index % 4) * 22f
            windows[type] = SpatialWindowState(
                type = type,
                position = Offset(offsetX, offsetY),
                size = DpSize(340.dp, 350.dp),
                isVisible = index < 2, // Default open Editor + Terminal
                isMinimized = false,
                isMaximized = false,
                zIndex = index.toFloat()
            )
        }
        nextZIndex = WindowType.values().size.toFloat()
    }

    fun updateScreenBounds(width: Float, height: Float) {
        if (width > 0 && height > 0) {
            screenWidthPx = width
            screenHeightPx = height
        }
    }

    fun getAllWindows(): List<SpatialWindowState> = windows.values.toList()

    fun getWindow(type: WindowType): SpatialWindowState? = windows[type]

    fun openWindow(type: WindowType) {
        val cur = windows[type] ?: return
        bringToFront(type)
        windows[type] = cur.copy(isVisible = true, isMinimized = false)
    }

    fun closeWindow(type: WindowType) {
        val cur = windows[type] ?: return
        windows[type] = cur.copy(isVisible = false)
    }

    fun minimizeWindow(type: WindowType) {
        val cur = windows[type] ?: return
        windows[type] = cur.copy(isMinimized = true)
    }

    fun restoreWindow(type: WindowType) {
        val cur = windows[type] ?: return
        bringToFront(type)
        windows[type] = cur.copy(isMinimized = false, isVisible = true)
    }

    fun toggleMaximize(type: WindowType) {
        val cur = windows[type] ?: return
        bringToFront(type)
        windows[type] = cur.copy(isMaximized = !cur.isMaximized)
    }

    fun togglePin(type: WindowType) {
        val cur = windows[type] ?: return
        windows[type] = cur.copy(isPinned = !cur.isPinned)
    }

    fun moveWindow(type: WindowType, delta: Offset) {
        val cur = windows[type] ?: return
        if (cur.isMaximized) return

        // Clamp to screen bounds to prevent moving windows off-screen
        val maxX = (screenWidthPx - 180f).coerceAtLeast(0f)
        val maxY = (screenHeightPx - 160f).coerceAtLeast(0f)

        val newX = (cur.position.x + delta.x).coerceIn(0f, maxX)
        val newY = (cur.position.y + delta.y).coerceIn(0f, maxY)
        windows[type] = cur.copy(position = Offset(newX, newY))
    }

    fun resizeWindow(type: WindowType, deltaW: Dp, deltaH: Dp) {
        val cur = windows[type] ?: return
        if (cur.isMaximized) return
        val newW = (cur.size.width + deltaW).coerceIn(240.dp, 580.dp)
        val newH = (cur.size.height + deltaH).coerceIn(180.dp, 750.dp)
        windows[type] = cur.copy(size = DpSize(newW, newH))
    }

    fun bringToFront(type: WindowType) {
        val cur = windows[type] ?: return
        nextZIndex += 1f
        windows[type] = cur.copy(zIndex = nextZIndex)
    }

    fun applyPreset(preset: WorkspacePreset) {
        when (preset) {
            WorkspacePreset.DEVELOPER -> {
                windows.values.forEach { windows[it.type] = it.copy(isVisible = false, isMaximized = false) }
                openWindow(WindowType.EDITOR)
                openWindow(WindowType.TERMINAL)
                windows[WindowType.EDITOR] = windows[WindowType.EDITOR]!!.copy(
                    position = Offset(12f, 20f),
                    size = DpSize(345.dp, 330.dp)
                )
                windows[WindowType.TERMINAL] = windows[WindowType.TERMINAL]!!.copy(
                    position = Offset(24f, 260f),
                    size = DpSize(345.dp, 290.dp)
                )
            }
            WorkspacePreset.AI_AGENT -> {
                windows.values.forEach { windows[it.type] = it.copy(isVisible = false, isMaximized = false) }
                openWindow(WindowType.AGENT)
                openWindow(WindowType.TERMINAL)
                windows[WindowType.AGENT] = windows[WindowType.AGENT]!!.copy(
                    position = Offset(12f, 20f),
                    size = DpSize(350.dp, 370.dp)
                )
                windows[WindowType.TERMINAL] = windows[WindowType.TERMINAL]!!.copy(
                    position = Offset(20f, 280f),
                    size = DpSize(340.dp, 260.dp)
                )
            }
            WorkspacePreset.DEBUGGING -> {
                windows.values.forEach { windows[it.type] = it.copy(isVisible = false, isMaximized = false) }
                openWindow(WindowType.TERMINAL)
                openWindow(WindowType.AUDIT)
                windows[WindowType.TERMINAL] = windows[WindowType.TERMINAL]!!.copy(
                    position = Offset(12f, 20f),
                    size = DpSize(345.dp, 300.dp)
                )
                windows[WindowType.AUDIT] = windows[WindowType.AUDIT]!!.copy(
                    position = Offset(20f, 260f),
                    size = DpSize(345.dp, 310.dp)
                )
            }
            WorkspacePreset.RESEARCH -> {
                windows.values.forEach { windows[it.type] = it.copy(isVisible = false, isMaximized = false) }
                openWindow(WindowType.MODELS)
                openWindow(WindowType.MEMORY)
            }
            WorkspacePreset.MINIMAL -> {
                windows.values.forEach { windows[it.type] = it.copy(isVisible = false, isMaximized = false) }
            }
        }
    }
}
