package com.aether.spatial.core

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

enum class CompanionRole(
    val title: String,
    val description: String,
    val primaryColor: Color,
    val accentColor: Color,
    val defaultSpeech: String,
    val actionLabel: String
) {
    ARCHITECT(
        "Architect",
        "System design & modular structure",
        SpatialColors.HoloCyan,
        SpatialColors.HoloViolet,
        "Clean architecture active. Ready to model project modules.",
        "Model System"
    ),
    CODER(
        "Coder",
        "Code synthesis & patch generation",
        SpatialColors.HoloEmerald,
        SpatialColors.HoloCyan,
        "Syntax engine ready across Kotlin, Python, and C++.",
        "Open Editor"
    ),
    DEBUGGER(
        "Debugger",
        "Error analysis & terminal diagnostics",
        SpatialColors.HoloAmber,
        SpatialColors.HoloRose,
        "Monitoring child process exit codes and stderr streams.",
        "Check Logs"
    ),
    RESEARCHER(
        "Researcher",
        "Knowledge base & documentation",
        SpatialColors.HoloViolet,
        SpatialColors.HoloSky,
        "Project memory and GGUF quantization tables synchronized.",
        "Load Model"
    ),
    SECURITY_GUARDIAN(
        "Security Guardian",
        "Vulnerability & sandbox protection",
        SpatialColors.HoloRose,
        SpatialColors.HoloAmber,
        "Confinement active. Zero-trust directory traversal defense.",
        "Run Audit"
    ),
    BUILD_ENGINEER(
        "Build Engineer",
        "Compilation & Gradle optimization",
        SpatialColors.HoloSky,
        SpatialColors.HoloCyan,
        "Gradle daemon ready. ABI splits configured for ARM64.",
        "Run Build"
    ),
    PROJECT_MANAGER(
        "Project Manager",
        "ReAct agent tool orchestration",
        Color(0xFFFBBF24),
        SpatialColors.HoloViolet,
        "Autonomous ReAct loops coordinated under strict supervision.",
        "Launch Agent"
    )
}

enum class CompanionVisualState {
    IDLE,
    THINKING,
    WORKING,
    SUCCESS,
    WARNING,
    ERROR
}

data class CompanionState(
    val role: CompanionRole = CompanionRole.ARCHITECT,
    val visualState: CompanionVisualState = CompanionVisualState.IDLE,
    val currentSpeech: String? = CompanionRole.ARCHITECT.defaultSpeech,
    val isSpeechVisible: Boolean = true,
    val isPanelExpanded: Boolean = false
)

@Composable
fun Miniature3DCompanion(
    companionState: CompanionState,
    modifier: Modifier = Modifier,
    onCompanionClicked: () -> Unit,
    onActionClicked: (CompanionRole) -> Unit,
    onDismissSpeech: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "companion_anim")

    // Vertical floating bobbing animation
    val floatOffset by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bobbing"
    )

    // Orbital ring rotation
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rot"
    )

    // Visor sensor scanning pulse
    val scanPulse by infiniteTransition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanner"
    )

    val role = companionState.role

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End
    ) {
        // Speech Bubble with Direct Action
        AnimatedVisibility(visible = companionState.isSpeechVisible && !companionState.currentSpeech.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = SpatialColors.SurfaceOverlay,
                border = androidx.compose.foundation.BorderStroke(1.dp, role.primaryColor.copy(alpha = 0.5f)),
                modifier = Modifier
                    .padding(bottom = 6.dp)
                    .widthIn(max = 240.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = role.title.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = role.primaryColor,
                            fontSize = 10.sp
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = SpatialColors.TextMuted,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onDismissSpeech() }
                        )
                    }

                    Text(
                        text = companionState.currentSpeech ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = SpatialColors.TextPrimary
                    )

                    Button(
                        onClick = { onActionClicked(role) },
                        colors = ButtonDefaults.buttonColors(containerColor = role.primaryColor),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(26.dp).align(Alignment.End)
                    ) {
                        Text(role.actionLabel, fontSize = 10.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Procedural 3D Geometric Robot Avatar
        Box(
            modifier = Modifier
                .size(64.dp)
                .clickable { onCompanionClicked() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f + floatOffset

                // 1. Ambient Holographic Halo
                drawCircle(
                    color = role.primaryColor.copy(alpha = 0.25f),
                    radius = 26f,
                    center = Offset(cx, cy)
                )

                // 2. Rotating 3D Orbital Crest
                val angleRad = (ringRotation * PI / 180f).toFloat()
                val rx = 24f
                val ry = 8f
                for (i in 0 until 14) {
                    val theta = angleRad + (i.toFloat() / 14) * 2 * PI.toFloat()
                    val px = cx + rx * cos(theta)
                    val py = cy + ry * sin(theta)
                    val alpha = ((sin(theta) + 1f) / 2f).coerceIn(0.2f, 0.95f)
                    drawCircle(
                        color = role.accentColor.copy(alpha = alpha),
                        radius = 2.2f,
                        center = Offset(px, py)
                    )
                }

                // 3. Angular Robotic Helmet & Torso
                val helmPath = Path().apply {
                    moveTo(cx - 16f, cy - 8f)
                    lineTo(cx + 16f, cy - 8f)
                    lineTo(cx + 20f, cy + 6f)
                    lineTo(cx + 12f, cy + 18f)
                    lineTo(cx - 12f, cy + 18f)
                    lineTo(cx - 20f, cy + 6f)
                    close()
                }
                drawPath(helmPath, color = SpatialColors.SurfaceElevated)
                drawPath(helmPath, color = role.primaryColor, style = Stroke(width = 1.8f))

                // 4. Horizontal Glowing Visor Eye
                drawLine(
                    color = SpatialColors.CanvasBase,
                    start = Offset(cx - 14f, cy + 3f),
                    end = Offset(cx + 14f, cy + 3f),
                    strokeWidth = 5f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = role.primaryColor,
                    start = Offset(cx - 12f, cy + 3f),
                    end = Offset(cx + 12f, cy + 3f),
                    strokeWidth = 2.5f,
                    cap = StrokeCap.Round
                )
                // Scanning beam node
                drawCircle(
                    color = Color.White,
                    radius = 2.5f,
                    center = Offset(cx + scanPulse, cy + 3f)
                )

                // 5. State Glow Beacon on Crown
                val stateColor = when (companionState.visualState) {
                    CompanionVisualState.IDLE -> role.primaryColor
                    CompanionVisualState.THINKING -> SpatialColors.HoloViolet
                    CompanionVisualState.WORKING -> SpatialColors.HoloCyan
                    CompanionVisualState.SUCCESS -> SpatialColors.HoloEmerald
                    CompanionVisualState.WARNING -> SpatialColors.HoloAmber
                    CompanionVisualState.ERROR -> SpatialColors.HoloRose
                }
                drawCircle(
                    color = stateColor,
                    radius = 3.5f,
                    center = Offset(cx, cy - 11f)
                )
            }
        }
    }
}
