package com.aether.spatial.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.hardware.HardwareCapabilityProfile
import com.aether.spatial.core.SpatialColors
import com.aether.spatial.core.spatialGlassPanel
import kotlin.math.sin

// -----------------------------------------------------------------------------
// 1. TOP HEADER APP BAR (Matching Reference Image)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceTopHeader(
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    batteryPct: Int = 92,
    timeString: String = "12:45",
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Logo & Title
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Faceted 3D Logo Diamond
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF6366F1), Color(0xFF9333EA), Color(0xFF00F0FF))
                        )
                    )
                    .border(1.2.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "A",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 20.sp
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "AETHER AI",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = SpatialColors.TextPrimary,
                    fontSize = 17.sp,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Spatial AI Developer Workspace",
                    style = MaterialTheme.typography.labelSmall,
                    color = SpatialColors.TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Center Search Bar: "Search anything... (Ctrl + K)"
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SpatialColors.SurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.GlassBorder),
            modifier = Modifier
                .widthIn(min = 220.dp, max = 340.dp)
                .height(36.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = SpatialColors.TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (searchQuery.isBlank()) "Search anything... (Ctrl + K)" else searchQuery,
                    color = if (searchQuery.isBlank()) SpatialColors.TextMuted else SpatialColors.TextPrimary,
                    fontSize = 12.sp,
                    maxLines = 1
                )
            }
        }

        // Right Status Indicators
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Online status
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(SpatialColors.HoloEmerald)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Online", fontSize = 12.sp, color = SpatialColors.TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.width(12.dp))

            // Clock
            Icon(Icons.Default.Schedule, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(timeString, fontSize = 12.sp, color = SpatialColors.TextSecondary)
            Spacer(modifier = Modifier.width(12.dp))

            // Battery
            Icon(Icons.Default.BatteryChargingFull, contentDescription = null, tint = SpatialColors.HoloEmerald, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("$batteryPct%", fontSize = 12.sp, color = SpatialColors.TextSecondary)
            Spacer(modifier = Modifier.width(12.dp))

            // User Avatar
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(SpatialColors.HoloViolet),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = "Profile", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 2. ACTIVE PROJECT CARD (Matching Reference Top-Left)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceActiveProjectCard(
    projectName: String = "Quantum-Dev",
    projectPath: String = "/storage/emulated/0/Quantum-Dev",
    modifier: Modifier = Modifier,
    onOpenProject: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.widthIn(max = 280.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = SpatialColors.HoloCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Active Project",
                        style = MaterialTheme.typography.labelSmall,
                        color = SpatialColors.TextMuted,
                        fontSize = 11.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Favorite",
                    tint = SpatialColors.HoloAmber,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Project Icon + Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF3B82F6)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Terminal, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = projectName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SpatialColors.TextPrimary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = projectPath,
                        style = MaterialTheme.typography.labelSmall,
                        color = SpatialColors.TextMuted,
                        fontSize = 9.sp,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Open Button
            Button(
                onClick = onOpenProject,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6366F1),
                    contentColor = Color.White
                ),
                contentPadding = PaddingValues(0.dp)
            ) {
                Text("Open", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 3. SYSTEM MONITOR WITH 3 CIRCULAR ARC GAUGES (Matching Reference Mid-Left)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceSystemMonitorCard(
    profile: HardwareCapabilityProfile?,
    modifier: Modifier = Modifier
) {
    val cpuPct = 28
    val ramPct = if (profile != null && profile.totalRamMb > 0) {
        ((profile.totalRamMb - profile.availableRamMb) * 100 / profile.totalRamMb).toInt().coerceIn(10, 95)
    } else 62
    val gpuPct = 45
    val tempC = when (profile?.thermalStatus) {
        com.aether.hardware.ThermalStatus.NORMAL -> 38
        com.aether.hardware.ThermalStatus.LIGHT -> 42
        com.aether.hardware.ThermalStatus.MODERATE -> 48
        else -> 42
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.widthIn(max = 280.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(SpatialColors.HoloViolet),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "System Monitor",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SpatialColors.TextPrimary,
                        fontSize = 13.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("⋮⋮", color = SpatialColors.TextMuted, fontSize = 12.sp)
                    Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 3 Circular Arc Gauges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ArcGauge(label = "CPU", percent = cpuPct, arcColor = SpatialColors.HoloCyan)
                ArcGauge(label = "RAM", percent = ramPct, arcColor = Color(0xFF3B82F6))
                ArcGauge(label = "GPU", percent = gpuPct, arcColor = SpatialColors.HoloEmerald)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Wave Chart + Temperature
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mini Wave
                MiniTelemetryWave(
                    modifier = Modifier
                        .width(120.dp)
                        .height(26.dp)
                )

                // Temp Indicator
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Temp ", fontSize = 11.sp, color = SpatialColors.TextMuted)
                    Text("$tempC°C", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SpatialColors.TextPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Thermostat,
                        contentDescription = null,
                        tint = if (tempC > 45) SpatialColors.HoloRose else SpatialColors.HoloCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ArcGauge(label: String, percent: Int, arcColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.size(54.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = 5f
                val sweepAngle = 240f
                val startAngle = 150f

                // Track
                drawArc(
                    color = SpatialColors.SurfaceDeep,
                    startAngle = startAngle,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )

                // Active Arc
                val activeSweep = (percent / 100f) * sweepAngle
                drawArc(
                    color = arcColor,
                    startAngle = startAngle,
                    sweepAngle = activeSweep,
                    useCenter = false,
                    style = Stroke(width = stroke, cap = StrokeCap.Round)
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$percent%",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = SpatialColors.TextPrimary
                )
            }
        }
        Text(text = label, fontSize = 10.sp, color = SpatialColors.TextMuted, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun MiniTelemetryWave(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(2500, easing = LinearEasing), RepeatMode.Restart),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val points = mutableListOf<Offset>()
        val step = w / 20f

        for (i in 0..20) {
            val x = i * step
            val y = h / 2f + (sin(i * 0.5f + wavePhase) * (h * 0.35f)).toFloat()
            points.add(Offset(x, y))
        }

        for (i in 0 until points.size - 1) {
            drawLine(
                color = SpatialColors.HoloCyan.copy(alpha = 0.8f),
                start = points[i],
                end = points[i + 1],
                strokeWidth = 2f,
                cap = StrokeCap.Round
            )
        }
    }
}

// -----------------------------------------------------------------------------
// 4. FLOATING TOOLS GRID (Matching Reference Bottom-Left)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceFloatingToolsCard(
    modifier: Modifier = Modifier,
    onToolClicked: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.widthIn(max = 280.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF3B82F6)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.GridView, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Floating Tools",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SpatialColors.TextPrimary,
                        fontSize = 13.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("⋮⋮", color = SpatialColors.TextMuted, fontSize = 12.sp)
                    Icon(Icons.Default.Minimize, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
                    Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 8 Grid Icon Tiles
            val toolsRow1 = listOf(
                Triple("Code", Icons.Default.Code, SpatialColors.HoloCyan),
                Triple("Terminal", Icons.Default.Terminal, SpatialColors.HoloViolet),
                Triple("Explorer", Icons.Default.Folder, Color(0xFF3B82F6)),
                Triple("Debugger", Icons.Default.BugReport, SpatialColors.HoloAmber)
            )
            val toolsRow2 = listOf(
                Triple("Build", Icons.Default.Build, Color(0xFF818CF8)),
                Triple("Security", Icons.Default.Security, SpatialColors.HoloEmerald),
                Triple("Analyzer", Icons.Default.Analytics, Color(0xFFFB923C)),
                Triple("More", Icons.Default.MoreHoriz, SpatialColors.TextMuted)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for ((name, icon, color) in toolsRow1) {
                    ToolIconTile(name, icon, color) { onToolClicked(name) }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                for ((name, icon, color) in toolsRow2) {
                    ToolIconTile(name, icon, color) { onToolClicked(name) }
                }
            }
        }
    }
}

@Composable
fun ToolIconTile(name: String, icon: ImageVector, color: Color, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SpatialColors.SurfaceDeep)
                .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = name, tint = color, modifier = Modifier.size(22.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = name, fontSize = 10.sp, color = SpatialColors.TextSecondary)
    }
}

// -----------------------------------------------------------------------------
// 5. PROJECT TREE CARD (Matching Reference Mid-Right)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceProjectTreeCard(
    modifier: Modifier = Modifier,
    onFileSelected: (String) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.widthIn(max = 240.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccountTree, contentDescription = null, tint = SpatialColors.HoloCyan, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Project Tree", fontWeight = FontWeight.Bold, color = SpatialColors.TextPrimary, fontSize = 13.sp)
                }
                Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // File Tree List
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                TreeItem("▼ app", isFolder = true, tint = Color(0xFFA855F7), indent = 0)
                TreeItem("▼ src", isFolder = true, tint = Color(0xFFFBBF24), indent = 1)
                TreeItem("▼ main", isFolder = true, tint = Color(0xFFFBBF24), indent = 2)
                TreeItem("▶ java", isFolder = true, tint = Color(0xFFFBBF24), indent = 3)
                TreeItem("▶ res", isFolder = true, tint = Color(0xFFFBBF24), indent = 3)
                TreeItem("AndroidManifest.xml", isFolder = false, tint = Color(0xFF38BDF8), indent = 2) { onFileSelected("AndroidManifest.xml") }
                TreeItem("build.gradle.kts", isFolder = false, tint = Color(0xFFA855F7), indent = 2) { onFileSelected("build.gradle.kts") }
            }
        }
    }
}

@Composable
fun TreeItem(
    title: String,
    isFolder: Boolean,
    tint: Color,
    indent: Int,
    onClick: (() -> Unit)? = null
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = (indent * 12).dp)
            .clickable(enabled = onClick != null) { onClick?.invoke() }
            .padding(vertical = 2.dp)
    ) {
        Icon(
            imageVector = if (isFolder) Icons.Default.Folder else Icons.Default.Description,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            fontSize = 11.sp,
            color = if (isFolder) SpatialColors.TextPrimary else SpatialColors.TextSecondary,
            fontFamily = FontFamily.Monospace
        )
    }
}

// -----------------------------------------------------------------------------
// 6. QUICK ACTIONS CARD (Matching Reference Bottom-Right)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceQuickActionsCard(
    modifier: Modifier = Modifier,
    onNewProject: () -> Unit,
    onRunBuild: () -> Unit,
    onScanSecurity: () -> Unit,
    onOpenSecurity: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.widthIn(max = 240.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bolt, contentDescription = null, tint = SpatialColors.HoloViolet, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Quick Actions", fontWeight = FontWeight.Bold, color = SpatialColors.TextPrimary, fontSize = 13.sp)
                }
                Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons List
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                QuickActionRow("New Project", Icons.Default.CreateNewFolder, SpatialColors.HoloCyan, onNewProject)
                QuickActionRow("Run Build", Icons.Default.PlayArrow, SpatialColors.HoloEmerald, onRunBuild)
                QuickActionRow("Scan Security", Icons.Default.Shield, SpatialColors.HoloSky, onScanSecurity)
                QuickActionRow("Open Security", Icons.Default.Security, Color(0xFFA855F7), onOpenSecurity)
            }
        }
    }
}

@Composable
fun QuickActionRow(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = SpatialColors.SurfaceDeep,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(15.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(title, fontSize = 11.sp, color = SpatialColors.TextPrimary, fontWeight = FontWeight.Medium)
        }
    }
}

// -----------------------------------------------------------------------------
// 7. TOAST NOTIFICATION CARD (Matching Reference Bottom-Left Toast)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceBuildNotificationToast(
    title: String = "Build Completed Successfully!",
    subtitle: String = "Your app is ready to run.",
    timeAgo: String = "2m ago",
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.HoloEmerald.copy(alpha = 0.5f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(SpatialColors.HoloEmerald.copy(alpha = 0.2f))
                    .border(1.5.dp, SpatialColors.HoloEmerald, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = SpatialColors.HoloEmerald, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SpatialColors.TextPrimary)
                Text(subtitle, fontSize = 10.sp, color = SpatialColors.TextMuted)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Text(timeAgo, fontSize = 10.sp, color = SpatialColors.TextMuted)
        }
    }
}

// -----------------------------------------------------------------------------
// 8. WORKSPACE PRESETS PILL BAR (Matching Reference Bottom-Center)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceWorkspacePresetsBar(
    currentPreset: String,
    onPresetSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = SpatialColors.SurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.GlassBorder),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "Workspace Presets",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = SpatialColors.TextMuted,
                modifier = Modifier.padding(horizontal = 6.dp)
            )

            val presets = listOf("Developer", "AI Agent", "Research", "Minimal", "Custom")
            for (p in presets) {
                val isSelected = p == currentPreset
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) SpatialColors.ActivePillGradient else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                        )
                        .clickable { onPresetSelect(p) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = p,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else SpatialColors.TextSecondary
                    )
                }
            }

            // Grid Layout Icon button
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SpatialColors.SurfaceDeep),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GridView, contentDescription = null, tint = SpatialColors.HoloCyan, modifier = Modifier.size(16.dp))
            }
        }
    }
}

// -----------------------------------------------------------------------------
// 9. BOTTOM NAVIGATION DOCK (Matching Reference Bottom Dock)
// -----------------------------------------------------------------------------
@Composable
fun ReferenceBottomNavDock(
    currentTab: String,
    onTabSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = SpatialColors.SurfaceOverlay,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            BottomDockItem("Dashboard", Icons.Default.Dashboard, currentTab == "Dashboard") { onTabSelect("Dashboard") }
            BottomDockItem("Workspace", Icons.Default.Window, currentTab == "Workspace", isPrimary = true) { onTabSelect("Workspace") }
            BottomDockItem("AI Agents", Icons.Default.SmartToy, currentTab == "AI Agents") { onTabSelect("AI Agents") }
            BottomDockItem("Tools", Icons.Default.Build, currentTab == "Tools") { onTabSelect("Tools") }
            BottomDockItem("Notifications", Icons.Default.Notifications, currentTab == "Notifications", badgeCount = 3) { onTabSelect("Notifications") }
            BottomDockItem("Profile", Icons.Default.Person, currentTab == "Profile") { onTabSelect("Profile") }
        }
    }
}

@Composable
fun BottomDockItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    isPrimary: Boolean = false,
    badgeCount: Int? = null,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isSelected -> SpatialColors.HoloViolet.copy(alpha = 0.35f)
                            isPrimary -> Color(0xFF6366F1).copy(alpha = 0.25f)
                            else -> Color.Transparent
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isSelected) SpatialColors.HoloCyan else SpatialColors.TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
            if (badgeCount != null) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(SpatialColors.HoloRose),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "$badgeCount", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(
            text = title,
            fontSize = 9.sp,
            color = if (isSelected) SpatialColors.HoloCyan else SpatialColors.TextMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
