package com.aether.spatial.core

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.*

data class Point3D(val x: Float, val y: Float, val z: Float) {
    fun rotateX(angleRad: Float): Point3D {
        val cos = cos(angleRad)
        val sin = sin(angleRad)
        return Point3D(x, y * cos - z * sin, y * sin + z * cos)
    }

    fun rotateY(angleRad: Float): Point3D {
        val cos = cos(angleRad)
        val sin = sin(angleRad)
        return Point3D(x * cos + z * sin, y, -x * sin + z * cos)
    }

    fun rotateZ(angleRad: Float): Point3D {
        val cos = cos(angleRad)
        val sin = sin(angleRad)
        return Point3D(x * cos - y * sin, x * sin + y * cos, z)
    }

    fun project(width: Float, height: Float, fov: Float = 360f, distance: Float = 400f): Offset {
        val factor = fov / (distance + z).coerceAtLeast(1f)
        return Offset(
            x = width / 2f + x * factor,
            y = height / 2f + y * factor
        )
    }
}

@Composable
fun AetherCore3D(
    modifier: Modifier = Modifier,
    systemLoadPct: Float = 0.25f,
    quality: SpatialRenderQuality = SpatialRenderQuality.PERFORMANCE,
    onNodeClicked: ((String) -> Unit)? = null
) {
    var manualRotX by remember { mutableFloatStateOf(0.35f) }
    var manualRotY by remember { mutableFloatStateOf(0.45f) }

    val infiniteTransition = rememberInfiniteTransition(label = "core_anim")
    val autoRot by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(18000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "auto_rotation"
    )

    val corePulse by infiniteTransition.animateFloat(
        initialValue = 0.90f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Particles constellation
    val particleCount = quality.particleCount
    val particles = remember(particleCount) {
        List(particleCount) {
            val theta = (it.toFloat() / particleCount) * 2 * PI
            val phi = (it * 1.618f) * PI
            val r = 130f + (it % 4) * 20f
            Point3D(
                x = (r * sin(phi) * cos(theta)).toFloat(),
                y = (r * sin(phi) * sin(theta)).toFloat(),
                z = (r * cos(phi)).toFloat()
            )
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    manualRotY += dragAmount.x * 0.006f
                    manualRotX -= dragAmount.y * 0.006f
                }
            }
    ) {
        val w = size.width
        val h = size.height

        // 1. Ambient Radial Glow
        drawCircle(
            brush = SpatialColors.CoreAuraGradient,
            radius = 70f * corePulse,
            center = Offset(w / 2f, h / 2f)
        )

        val currentRotX = manualRotX
        val currentRotY = manualRotY + autoRot

        // 2. Ambient Particles
        if (quality.particleCount > 0) {
            val projectedParticles = particles.map { pt ->
                pt.rotateX(currentRotX).rotateY(currentRotY).project(w, h)
            }
            drawPoints(
                points = projectedParticles,
                pointMode = PointMode.Points,
                color = SpatialColors.HoloCyan.copy(alpha = 0.35f),
                strokeWidth = 2.5f,
                cap = StrokeCap.Round
            )
        }

        // 3. Precision 3D Gyroscope Rings
        drawSpatialRing(w, h, radius = 55f * corePulse, rotX = currentRotX, rotY = currentRotY, color = SpatialColors.HoloCyan.copy(alpha = 0.7f))
        drawSpatialRing(w, h, radius = 42f, rotX = currentRotX + 0.9f, rotY = currentRotY * 1.2f, color = SpatialColors.HoloViolet.copy(alpha = 0.6f))

        // 4. Inner Geometric Tesseract
        val cubeSize = 22f * corePulse
        val vertices = listOf(
            Point3D(-cubeSize, -cubeSize, -cubeSize),
            Point3D(cubeSize, -cubeSize, -cubeSize),
            Point3D(cubeSize, cubeSize, -cubeSize),
            Point3D(-cubeSize, cubeSize, -cubeSize),
            Point3D(-cubeSize, -cubeSize, cubeSize),
            Point3D(cubeSize, -cubeSize, cubeSize),
            Point3D(cubeSize, cubeSize, cubeSize),
            Point3D(-cubeSize, cubeSize, cubeSize)
        )

        val projectedVertices = vertices.map {
            it.rotateX(currentRotX).rotateY(currentRotY).project(w, h)
        }

        val edges = listOf(
            0 to 1, 1 to 2, 2 to 3, 3 to 0,
            4 to 5, 5 to 6, 6 to 7, 7 to 4,
            0 to 4, 1 to 5, 2 to 6, 3 to 7
        )

        for ((p1, p2) in edges) {
            drawLine(
                color = SpatialColors.HoloCyan.copy(alpha = 0.85f),
                start = projectedVertices[p1],
                end = projectedVertices[p2],
                strokeWidth = 1.8f,
                cap = StrokeCap.Round
            )
        }

        // 5. Core Spark Node
        drawCircle(
            color = Color.White,
            radius = 4f * corePulse,
            center = Offset(w / 2f, h / 2f)
        )
        drawCircle(
            color = SpatialColors.HoloCyan,
            radius = 8f * corePulse,
            center = Offset(w / 2f, h / 2f),
            style = Stroke(width = 1.5f)
        )
    }
}

private fun DrawScope.drawSpatialRing(
    width: Float,
    height: Float,
    radius: Float,
    rotX: Float,
    rotY: Float,
    color: Color,
    segments: Int = 32
) {
    val points = mutableListOf<Offset>()
    for (i in 0..segments) {
        val angle = (i.toFloat() / segments) * 2 * PI
        val pt = Point3D(
            x = (radius * cos(angle)).toFloat(),
            y = 0f,
            z = (radius * sin(angle)).toFloat()
        ).rotateX(rotX).rotateY(rotY).project(width, height)
        points.add(pt)
    }

    for (i in 0 until points.size - 1) {
        drawLine(
            color = color,
            start = points[i],
            end = points[i + 1],
            strokeWidth = 1.4f,
            cap = StrokeCap.Round
        )
    }
}
