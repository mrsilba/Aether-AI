package com.aether.spatial.core

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Animated 3D Holographic Energy Pedestal with Robot Companion (matching reference image right side).
 */
@Composable
fun HologramPedestalCompanion(
    activeRole: CompanionRole,
    speechText: String = "Everything is under control!",
    modifier: Modifier = Modifier,
    onCompanionClicked: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pedestal_loop")

    val beamPulse by infiniteTransition.animateFloat(
        initialValue = 0.82f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "beam_pulse"
    )

    val botBob by infiniteTransition.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bot_bob"
    )

    val eyeGlow by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eye_glow"
    )

    Column(
        modifier = modifier.clickable { onCompanionClicked() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Speech Bubble (matching reference: "Everything is under control!")
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = SpatialColors.SurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.HoloCyan.copy(alpha = 0.6f)),
            modifier = Modifier
                .padding(bottom = 6.dp)
                .widthIn(max = 180.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(
                    text = activeRole.title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = activeRole.primaryColor
                )
                Text(
                    text = speechText,
                    fontSize = 11.sp,
                    color = SpatialColors.TextPrimary
                )
            }
        }

        // 3D Canvas rendering the Robot + Holographic Cylinder Pedestal
        Box(
            modifier = Modifier
                .size(width = 110.dp, height = 150.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cx = size.width / 2f
                val cy = size.height / 2f

                // 1. Base Mechanical Base Ring
                drawOval(
                    brush = Brush.radialGradient(
                        colors = listOf(SpatialColors.HoloViolet.copy(alpha = 0.8f), SpatialColors.SurfaceDeep),
                        center = Offset(cx, cy + 55f),
                        radius = 45f
                    ),
                    topLeft = Offset(cx - 40f, cy + 46f),
                    size = androidx.compose.ui.geometry.Size(80f, 22f)
                )

                // 2. Holographic Illuminated Energy Cylinder
                drawPath(
                    path = Path().apply {
                        moveTo(cx - 30f, cy + 48f)
                        lineTo(cx + 30f, cy + 48f)
                        lineTo(cx + 24f, cy + 5f)
                        lineTo(cx - 24f, cy + 5f)
                        close()
                    },
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            SpatialColors.HoloCyan.copy(alpha = 0.35f * beamPulse),
                            SpatialColors.HoloViolet.copy(alpha = 0.15f * beamPulse)
                        )
                    )
                )

                // Energy Rings in cylinder
                drawOval(
                    color = SpatialColors.HoloCyan.copy(alpha = 0.7f * beamPulse),
                    topLeft = Offset(cx - 24f, cy + 30f),
                    size = androidx.compose.ui.geometry.Size(48f, 12f),
                    style = Stroke(width = 1.5f)
                )
                drawOval(
                    color = SpatialColors.HoloViolet.copy(alpha = 0.8f * beamPulse),
                    topLeft = Offset(cx - 22f, cy + 14f),
                    size = androidx.compose.ui.geometry.Size(44f, 10f),
                    style = Stroke(width = 1.5f)
                )

                // 3. Platform Disc Top
                drawOval(
                    color = SpatialColors.SurfaceElevated,
                    topLeft = Offset(cx - 24f, cy + 2f),
                    size = androidx.compose.ui.geometry.Size(48f, 12f)
                )
                drawOval(
                    color = SpatialColors.HoloCyan,
                    topLeft = Offset(cx - 24f, cy + 2f),
                    size = androidx.compose.ui.geometry.Size(48f, 12f),
                    style = Stroke(width = 1.5f)
                )

                // 4. Robot Companion Body (Standing atop pedestal with bobbing)
                val botY = cy - 22f + botBob

                // Robot Legs / Feet
                drawRoundRect(
                    color = SpatialColors.SurfaceElevated,
                    topLeft = Offset(cx - 10f, botY + 18f),
                    size = androidx.compose.ui.geometry.Size(7f, 10f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
                )
                drawRoundRect(
                    color = SpatialColors.SurfaceElevated,
                    topLeft = Offset(cx + 3f, botY + 18f),
                    size = androidx.compose.ui.geometry.Size(7f, 10f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f, 3f)
                )

                // Robot Torso
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFFE2E8F0), Color(0xFF94A3B8))
                    ),
                    topLeft = Offset(cx - 12f, botY + 4f),
                    size = androidx.compose.ui.geometry.Size(24f, 18f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                )
                // Torso core light
                drawCircle(
                    color = activeRole.primaryColor,
                    radius = 3f,
                    center = Offset(cx, botY + 13f)
                )

                // Robot Head / Helmet
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFFF8FAFC), Color(0xFFCBD5E1))
                    ),
                    topLeft = Offset(cx - 16f, botY - 18f),
                    size = androidx.compose.ui.geometry.Size(32f, 22f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f)
                )
                drawRoundRect(
                    color = SpatialColors.HoloCyan.copy(alpha = 0.5f),
                    topLeft = Offset(cx - 16f, botY - 18f),
                    size = androidx.compose.ui.geometry.Size(32f, 22f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f),
                    style = Stroke(width = 1.2f)
                )

                // Visor Glass (Dark face screen)
                drawRoundRect(
                    color = SpatialColors.CanvasBase,
                    topLeft = Offset(cx - 12f, botY - 13f),
                    size = androidx.compose.ui.geometry.Size(24f, 13f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )

                // Glowing Cyan Eyes
                val eyeAlpha = eyeGlow
                drawCircle(
                    color = activeRole.primaryColor.copy(alpha = eyeAlpha),
                    radius = 2.5f,
                    center = Offset(cx - 5f, botY - 7f)
                )
                drawCircle(
                    color = activeRole.primaryColor.copy(alpha = eyeAlpha),
                    radius = 2.5f,
                    center = Offset(cx + 5f, botY - 7f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = eyeAlpha),
                    radius = 1f,
                    center = Offset(cx - 5f, botY - 7f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = eyeAlpha),
                    radius = 1f,
                    center = Offset(cx + 5f, botY - 7f)
                )

                // Floating Holographic Tablet HUD in Hand
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(SpatialColors.HoloCyan.copy(alpha = 0.7f), SpatialColors.HoloViolet.copy(alpha = 0.4f))
                    ),
                    topLeft = Offset(cx - 25f, botY + 2f),
                    size = androidx.compose.ui.geometry.Size(12f, 16f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f, 2f)
                )
                // Grid lines on HUD
                drawLine(
                    color = Color.White.copy(alpha = 0.8f),
                    start = Offset(cx - 23f, botY + 6f),
                    end = Offset(cx - 15f, botY + 6f),
                    strokeWidth = 1f
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.8f),
                    start = Offset(cx - 23f, botY + 10f),
                    end = Offset(cx - 17f, botY + 10f),
                    strokeWidth = 1f
                )
            }
        }
    }
}

/**
 * AI Companions Showcase Card (matching reference top-right card: "AI Companions - 7 Active").
 */
@Composable
fun CompanionsShowcaseCard(
    activeRole: CompanionRole,
    onRoleSelected: (CompanionRole) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = SpatialColors.SurfaceWindow,
        border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(SpatialColors.HoloViolet),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("A", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "AI Companions",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = SpatialColors.TextPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "7 Active",
                        style = MaterialTheme.typography.labelSmall,
                        color = SpatialColors.HoloEmerald
                    )
                }

                // Chat bubble
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SpatialColors.SurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.GlassBorder)
                ) {
                    Text(
                        text = "Ready to build something amazing?",
                        fontSize = 10.sp,
                        color = SpatialColors.TextSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Row of companions on glowing pads
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                items(CompanionRole.values()) { role ->
                    val isSelected = role == activeRole
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clickable { onRoleSelected(role) }
                    ) {
                        // Mini Robot Avatar
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) role.primaryColor.copy(alpha = 0.25f) else SpatialColors.SurfaceDeep)
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) role.primaryColor else SpatialColors.GlassBorder,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = role.title.take(2).uppercase(),
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) role.primaryColor else SpatialColors.TextSecondary,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        // Glowing base oval
                        Box(
                            modifier = Modifier
                                .width(28.dp)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (isSelected) role.primaryColor else SpatialColors.GlassBorder.copy(alpha = 0.3f)
                                )
                        )
                    }
                }
            }
        }
    }
}
