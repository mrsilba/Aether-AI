package com.aether.spatial.core

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

@Composable
fun AetherCoreArmillary3D(
    modifier: Modifier = Modifier,
    systemStatus: String = "Optimal Performance",
    quality: SpatialRenderQuality = SpatialRenderQuality.PERFORMANCE,
    onToolCubeClicked: ((String) -> Unit)? = null
) {
    var userRotX by remember { mutableFloatStateOf(0.28f) }
    var userRotY by remember { mutableFloatStateOf(0.40f) }

    val infiniteTransition = rememberInfiniteTransition(label = "armillary_loop")

    val orbitAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orbit_angle"
    )

    val corePulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    // Orbital tool cube definitions
    val toolCubes = remember {
        listOf(
            Triple("CODE", SpatialColors.HoloCyan, 0f),
            Triple("TERMINAL", SpatialColors.HoloEmerald, (PI / 2).toFloat()),
            Triple("AGENT", SpatialColors.HoloViolet, PI.toFloat()),
            Triple("EXPLORER", SpatialColors.HoloSky, (3 * PI / 2).toFloat())
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        userRotY += dragAmount.x * 0.007f
                        userRotX -= dragAmount.y * 0.007f
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val cy = h / 2f - 10f

            // 1. Cosmic Nebula Aura
            drawCircle(
                brush = SpatialColors.CoreAuraGradient,
                radius = 110f * corePulse,
                center = Offset(cx, cy)
            )

            // 2. Base Illuminated Pedestal Ring
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(SpatialColors.HoloViolet.copy(alpha = 0.5f), SpatialColors.HoloCyan.copy(alpha = 0.2f), Color.Transparent),
                    center = Offset(cx, cy + 85f),
                    radius = 90f
                ),
                topLeft = Offset(cx - 85f, cy + 70f),
                size = androidx.compose.ui.geometry.Size(170f, 32f)
            )

            val rotX = userRotX
            val rotY = userRotY + orbitAngle * 0.4f

            // 3. Primary Inclined Armillary Metallic Ring (tilted orbit)
            drawTiltedArmillaryRing(
                cx, cy,
                radius = 88f * corePulse,
                tiltX = 0.45f + rotX * 0.3f,
                tiltY = rotY,
                brush = Brush.sweepGradient(
                    colors = listOf(
                        SpatialColors.HoloCyan,
                        SpatialColors.HoloViolet,
                        Color(0xFFFBBF24),
                        SpatialColors.HoloCyan
                    ),
                    center = Offset(cx, cy)
                ),
                strokeWidth = 3.5f
            )

            // 4. Secondary Counter-Rotating Ring
            drawTiltedArmillaryRing(
                cx, cy,
                radius = 72f,
                tiltX = -0.55f + rotX * 0.2f,
                tiltY = -rotY * 0.8f,
                brush = Brush.sweepGradient(
                    colors = listOf(
                        SpatialColors.HoloViolet,
                        SpatialColors.HoloSky,
                        SpatialColors.HoloEmerald,
                        SpatialColors.HoloViolet
                    ),
                    center = Offset(cx, cy)
                ),
                strokeWidth = 2.2f
            )

            // 5. Vertical Gimbal Ring with Metallic Mounts
            drawTiltedArmillaryRing(
                cx, cy,
                radius = 60f * corePulse,
                tiltX = 1.2f,
                tiltY = rotY * 0.5f,
                brush = Brush.linearGradient(
                    listOf(SpatialColors.HoloCyan.copy(alpha = 0.8f), SpatialColors.HoloViolet.copy(alpha = 0.8f))
                ),
                strokeWidth = 1.8f
            )

            // 6. Inner Geometric Tesseract (3D Hypercube with Translucent Faces)
            val cubeR = 26f * corePulse
            val vertices = listOf(
                Point3D(-cubeR, -cubeR, -cubeR),
                Point3D(cubeR, -cubeR, -cubeR),
                Point3D(cubeR, cubeR, -cubeR),
                Point3D(-cubeR, cubeR, -cubeR),
                Point3D(-cubeR, -cubeR, cubeR),
                Point3D(cubeR, -cubeR, cubeR),
                Point3D(cubeR, cubeR, cubeR),
                Point3D(-cubeR, cubeR, cubeR)
            )

            val projVerts = vertices.map {
                it.rotateX(rotX).rotateY(rotY).project(w, h, fov = 350f, distance = 380f)
            }

            // Draw isometric inner faces with soft translucent color
            val faceIndices = listOf(
                listOf(0, 1, 2, 3), // Front
                listOf(4, 5, 6, 7), // Back
                listOf(0, 1, 5, 4), // Top
                listOf(2, 3, 7, 6)  // Bottom
            )

            for (face in faceIndices) {
                val path = Path().apply {
                    moveTo(projVerts[face[0]].x, projVerts[face[0]].y)
                    lineTo(projVerts[face[1]].x, projVerts[face[1]].y)
                    lineTo(projVerts[face[2]].x, projVerts[face[2]].y)
                    lineTo(projVerts[face[3]].x, projVerts[face[3]].y)
                    close()
                }
                drawPath(path, color = SpatialColors.HoloViolet.copy(alpha = 0.16f))
            }

            // Draw Wireframe Edges
            val edges = listOf(
                0 to 1, 1 to 2, 2 to 3, 3 to 0,
                4 to 5, 5 to 6, 6 to 7, 7 to 4,
                0 to 4, 1 to 5, 2 to 6, 3 to 7
            )

            for ((i1, i2) in edges) {
                drawLine(
                    color = SpatialColors.HoloCyan.copy(alpha = 0.9f),
                    start = projVerts[i1],
                    end = projVerts[i2],
                    strokeWidth = 2f,
                    cap = StrokeCap.Round
                )
            }

            // Inner Central Nucleus
            drawCircle(
                color = Color.White,
                radius = 5.5f * corePulse,
                center = Offset(cx, cy)
            )
            drawCircle(
                color = SpatialColors.HoloCyan,
                radius = 12f * corePulse,
                center = Offset(cx, cy),
                style = Stroke(width = 2f)
            )

            // 7. Floating Orbiting Tool Cubes
            val ringRadius = 100f
            for ((toolId, color, baseAngle) in toolCubes) {
                val angle = baseAngle + orbitAngle
                val pt = Point3D(
                    x = ringRadius * cos(angle),
                    y = 24f * sin(angle * 1.5f),
                    z = ringRadius * sin(angle)
                ).rotateX(rotX * 0.5f).rotateY(rotY * 0.7f)

                val proj = pt.project(w, h, fov = 350f, distance = 380f)
                val alpha = ((pt.z + 150f) / 300f).coerceIn(0.4f, 1f)

                // Cube halo & box
                drawCircle(
                    color = color.copy(alpha = alpha * 0.35f),
                    radius = 14f,
                    center = proj
                )
                drawRoundRect(
                    color = SpatialColors.SurfaceElevated.copy(alpha = alpha),
                    topLeft = Offset(proj.x - 9f, proj.y - 9f),
                    size = androidx.compose.ui.geometry.Size(18f, 18f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )
                drawRoundRect(
                    color = color.copy(alpha = alpha),
                    topLeft = Offset(proj.x - 9f, proj.y - 9f),
                    size = androidx.compose.ui.geometry.Size(18f, 18f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
                    style = Stroke(width = 1.5f)
                )
                drawCircle(
                    color = Color.White.copy(alpha = alpha),
                    radius = 2.5f,
                    center = proj
                )
            }
        }

        // 8. Glowing Pill Badge: "✜ AETHER CORE • Optimal Performance"
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = SpatialColors.SurfaceWindow,
            border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 6.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(SpatialColors.HoloEmerald)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AETHER CORE",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = SpatialColors.HoloCyan,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• $systemStatus",
                    style = MaterialTheme.typography.labelSmall,
                    color = SpatialColors.HoloEmerald,
                    fontSize = 11.sp
                )
            }
        }
    }
}

private fun DrawScope.drawTiltedArmillaryRing(
    cx: Float,
    cy: Float,
    radius: Float,
    tiltX: Float,
    tiltY: Float,
    brush: Brush,
    strokeWidth: Float,
    segments: Int = 40
) {
    val points = mutableListOf<Offset>()
    for (i in 0..segments) {
        val angle = (i.toFloat() / segments) * 2 * PI
        val pt = Point3D(
            x = (radius * cos(angle)).toFloat(),
            y = 0f,
            z = (radius * sin(angle)).toFloat()
        ).rotateX(tiltX).rotateY(tiltY)
        points.add(Offset(cx + pt.x, cy + pt.y))
    }

    val path = Path().apply {
        if (points.isNotEmpty()) {
            moveTo(points[0].x, points[0].y)
            for (p in points) {
                lineTo(p.x, p.y)
            }
            close()
        }
    }

    drawPath(
        path = path,
        brush = brush,
        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
    )
}
