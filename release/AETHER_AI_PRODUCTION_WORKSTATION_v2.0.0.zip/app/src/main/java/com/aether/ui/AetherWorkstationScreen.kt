package com.aether.ui

import java.io.File
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.agent.AgentStep
import com.aether.editor.CodeSymbol
import com.aether.editor.DiffLine
import com.aether.editor.DiffType
import com.aether.editor.EditorTab
import com.aether.hardware.DeviceHardwareTier
import com.aether.hardware.PowerPreference
import com.aether.hardware.ThermalStatus
import com.aether.inference.InferenceBackendType
import com.aether.inference.ModelDescriptor
import com.aether.project.AuditFinding
import com.aether.project.FindingSeverity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AetherWorkstationScreen(
    viewModel: WorkstationViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            WorkstationTopBar(
                state = state,
                onRefreshHardware = { viewModel.refreshHardwareProfile() },
                onSelectBackend = { viewModel.switchBackend(it) }
            )
        },
        bottomBar = {
            WorkstationBottomNav(
                currentScreen = state.currentScreen,
                onScreenSelected = { viewModel.switchScreen(it) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (state.currentScreen) {
                WorkstationScreen.DASHBOARD -> DashboardScreen(
                    state = state,
                    onNavigate = { viewModel.switchScreen(it) },
                    onRunAudit = { viewModel.runProjectAudit() }
                )
                WorkstationScreen.EDITOR -> EditorScreen(
                    state = state,
                    onSelectTab = { viewModel.selectEditorTab(it) },
                    onCloseTab = { viewModel.closeEditorTab(it) },
                    onContentChange = { viewModel.updateEditorContent(it) },
                    onSave = { viewModel.saveActiveFile() },
                    onUndo = { viewModel.undoEditor() },
                    onRedo = { viewModel.redoEditor() },
                    onApprovePatch = { viewModel.approveAndApplyPatch() },
                    onRejectPatch = { viewModel.rejectPatch() }
                )
                WorkstationScreen.TERMINAL -> TerminalScreen(
                    state = state,
                    onRunCommand = { viewModel.runTerminalCommand(it) },
                    onClear = { viewModel.clearTerminal() }
                )
                WorkstationScreen.AGENT -> AgentScreen(
                    state = state,
                    onStartAgent = { viewModel.startReActAgent(it) }
                )
                WorkstationScreen.AUDIT -> AuditScreen(
                    state = state,
                    onRunAudit = { viewModel.runProjectAudit() },
                    onReviewPatch = { viewModel.reviewFindingPatch(it) }
                )
                WorkstationScreen.MODELS -> ModelsHubScreen(
                    state = state,
                    onSelectModel = { viewModel.selectModel(it) },
                    onRunInference = { viewModel.runInference(it) },
                    onCancelInference = { viewModel.cancelInference() },
                    onSelectBackend = { viewModel.switchBackend(it) }
                )
                WorkstationScreen.MEMORY -> MemoryScreen(
                    state = state,
                    onAddMemory = { cat, title, content -> viewModel.addMemory(cat, title, content) }
                )
                WorkstationScreen.SETTINGS -> SettingsScreen(
                    state = state,
                    onSetTierOverride = { viewModel.setDeviceTierOverride(it) },
                    onSetPowerPreference = { viewModel.setPowerPreference(it) }
                )
            }
        }
    }
}

@Composable
fun WorkstationTopBar(
    state: WorkstationUiState,
    onRefreshHardware: () -> Unit,
    onSelectBackend: (InferenceBackendType) -> Unit
) {
    val profile = state.hardwareProfile

    Surface(
        color = CyberSurface,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(CyberPrimary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "AETHER AI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WORKSTATION",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberOnSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Backend indicator badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CyberSurfaceVariant,
                        modifier = Modifier.clickable {
                            val next = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) {
                                InferenceBackendType.CLOUD_GEMINI
                            } else {
                                InferenceBackendType.LOCAL_CPU_NEON
                            }
                            onSelectBackend(next)
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) Icons.Default.Memory else Icons.Default.Cloud,
                                contentDescription = "Active Backend",
                                tint = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) CyberPrimary else CyberSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (state.activeInferenceBackend == InferenceBackendType.LOCAL_CPU_NEON) "Local NEON" else "Cloud Gemini",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefreshHardware,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("refresh_hardware_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Telemetry",
                            tint = CyberPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Real-time Telemetry Row
            if (profile != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val ramPct = if (profile.totalRamMb > 0) ((profile.totalRamMb - profile.availableRamMb) * 100 / profile.totalRamMb).toInt() else 0
                    TelemetryBadge(
                        icon = Icons.Default.Memory,
                        label = "RAM ${profile.availableRamMb}MB free (${ramPct}% used)",
                        color = if (profile.isLowMemory) CyberError else CyberPrimary
                    )
                    TelemetryBadge(
                        icon = Icons.Default.Speed,
                        label = "${profile.cpuCoreCount} Cores (${profile.cpuArchitecture})",
                        color = CyberTertiary
                    )
                    TelemetryBadge(
                        icon = Icons.Default.Thermostat,
                        label = profile.thermalStatus.label,
                        color = when (profile.thermalStatus) {
                            ThermalStatus.NORMAL, ThermalStatus.LIGHT -> CyberSuccess
                            ThermalStatus.MODERATE -> CyberWarning
                            else -> CyberError
                        }
                    )
                    TelemetryBadge(
                        icon = if (profile.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                        label = "${profile.batteryPercent}%${if (profile.isCharging) " (Charging)" else ""}",
                        color = if (profile.batteryPercent < 20) CyberError else CyberOnSurfaceVariant
                    )
                    TelemetryBadge(
                        icon = Icons.Default.Grade,
                        label = profile.effectiveTier.label,
                        color = CyberSecondary
                    )
                }
            }
        }
    }
}

@Composable
fun TelemetryBadge(icon: ImageVector, label: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = CyberSurfaceVariant.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun WorkstationBottomNav(
    currentScreen: WorkstationScreen,
    onScreenSelected: (WorkstationScreen) -> Unit
) {
    NavigationBar(
        containerColor = CyberSurface,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        val primaryScreens = listOf(
            WorkstationScreen.DASHBOARD,
            WorkstationScreen.EDITOR,
            WorkstationScreen.TERMINAL,
            WorkstationScreen.AGENT,
            WorkstationScreen.AUDIT,
            WorkstationScreen.MODELS,
            WorkstationScreen.MEMORY,
            WorkstationScreen.SETTINGS
        )

        primaryScreens.forEach { screen ->
            val isSelected = currentScreen == screen
            val icon = when (screen) {
                WorkstationScreen.DASHBOARD -> Icons.Default.Dashboard
                WorkstationScreen.EDITOR -> Icons.Default.Code
                WorkstationScreen.TERMINAL -> Icons.Default.Terminal
                WorkstationScreen.AGENT -> Icons.Default.SmartToy
                WorkstationScreen.AUDIT -> Icons.Default.Security
                WorkstationScreen.MODELS -> Icons.Default.Psychology
                WorkstationScreen.MEMORY -> Icons.Default.Storage
                WorkstationScreen.SETTINGS -> Icons.Default.Settings
            }

            NavigationBarItem(
                selected = isSelected,
                onClick = { onScreenSelected(screen) },
                icon = { Icon(icon, contentDescription = screen.title) },
                label = { Text(screen.title, fontSize = 10.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CyberPrimary,
                    selectedTextColor = CyberPrimary,
                    indicatorColor = CyberSurfaceVariant,
                    unselectedIconColor = CyberOnSurfaceVariant,
                    unselectedTextColor = CyberOnSurfaceVariant
                ),
                modifier = Modifier.testTag("nav_item_${screen.name.lowercase()}")
            )
        }
    }
}

// -------------------------------------------------------------
// SCREEN 1: DASHBOARD
// -------------------------------------------------------------
@Composable
fun DashboardScreen(
    state: WorkstationUiState,
    onNavigate: (WorkstationScreen) -> Unit,
    onRunAudit: () -> Unit
) {
    val profile = state.hardwareProfile

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CyberSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Engineering Workstation Ready",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hardware-adaptive execution engine active for ${profile?.manufacturer ?: "Android"} ${profile?.model ?: "Device"}. Local ARM64 NEON & GGUF quantized models configured.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CyberOnSurfaceVariant
                )
            }
        }

        // Hardware Profile Summary Card
        if (profile != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Hardware Capability Profile",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    HorizontalDivider(color = CyberBorder)

                    DetailRow("Hardware Tier", profile.effectiveTier.label, CyberSecondary)
                    DetailRow("RAM Configuration", "${profile.availableRamMb} MB Free / ${profile.totalRamMb} MB Total", CyberPrimary)
                    DetailRow("Safe Model RAM Budget", "${profile.maxSafeModelRamMb} MB Safe Allocation", CyberSuccess)
                    DetailRow("CPU Architecture", "${profile.cpuArchitecture} (${profile.cpuCoreCount} Cores, NEON: ${profile.supportsNeon})", CyberOnSurface)
                    DetailRow("Recommended Threads", "${profile.recommendedThreads} Threads", CyberTertiary)
                    DetailRow("Thermal Condition", profile.thermalStatus.label, if (profile.thermalStatus == ThermalStatus.NORMAL) CyberSuccess else CyberWarning)
                    DetailRow("Storage Available", "${profile.storageAvailableMb} MB", CyberOnSurfaceVariant)
                }
            }
        }

        // Quick Launch Actions
        Text(
            text = "Workstation Subsystems",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ActionTile(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Code,
                title = "Code Editor",
                subtitle = "${state.openTabs.size} Files Open",
                color = CyberPrimary,
                onClick = { onNavigate(WorkstationScreen.EDITOR) }
            )
            ActionTile(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Terminal,
                title = "Terminal",
                subtitle = "Sandboxed Shell",
                color = CyberSuccess,
                onClick = { onNavigate(WorkstationScreen.TERMINAL) }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ActionTile(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.SmartToy,
                title = "ReAct Agent",
                subtitle = "Autonomous Tool Loop",
                color = CyberSecondary,
                onClick = { onNavigate(WorkstationScreen.AGENT) }
            )
            ActionTile(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Security,
                title = "Security Audit",
                subtitle = state.auditReport?.let { "Score: ${it.healthScore}/100" } ?: "Run Scan",
                color = CyberWarning,
                onClick = {
                    onRunAudit()
                    onNavigate(WorkstationScreen.AUDIT)
                }
            )
        }
    }
}

@Composable
fun ActionTile(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CyberSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        modifier = modifier
            .height(100.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(icon, contentDescription = title, tint = color, modifier = Modifier.size(24.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = CyberOnSurfaceVariant)
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = CyberOnSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = color)
    }
}

// -------------------------------------------------------------
// SCREEN 2: CODE EDITOR & DIFF VIEW
// -------------------------------------------------------------
@Composable
fun EditorScreen(
    state: WorkstationUiState,
    onSelectTab: (Int) -> Unit,
    onCloseTab: (Int) -> Unit,
    onContentChange: (String) -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onApprovePatch: () -> Unit,
    onRejectPatch: () -> Unit
) {
    var showSymbolsOutline by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Tab Header Row
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberSurface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(state.openTabs.indices.toList()) { index ->
                val tab = state.openTabs[index]
                val isActive = tab == state.activeTab

                Surface(
                    shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                    color = if (isActive) CyberCanvas else CyberSurfaceVariant,
                    border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, CyberBorder) else null,
                    modifier = Modifier.clickable { onSelectTab(index) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = tab.fileName + if (tab.isDirty) " *" else "",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                            color = if (isActive) CyberPrimary else CyberOnSurfaceVariant
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Tab",
                            tint = CyberOnSurfaceVariant,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onCloseTab(index) }
                        )
                    }
                }
            }
        }

        // Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberSurfaceVariant)
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = onSave,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberOnPrimary),
                    modifier = Modifier.height(34.dp).testTag("save_file_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save", fontSize = 12.sp)
                }
                IconButton(onClick = onUndo, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Undo, contentDescription = "Undo", tint = CyberOnSurface)
                }
                IconButton(onClick = onRedo, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Redo, contentDescription = "Redo", tint = CyberOnSurface)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                FilterChip(
                    selected = showSymbolsOutline,
                    onClick = { showSymbolsOutline = !showSymbolsOutline },
                    label = { Text("Symbols (${state.symbols.size})", fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CyberSecondary.copy(alpha = 0.2f),
                        selectedLabelColor = CyberSecondary
                    ),
                    modifier = Modifier.height(32.dp)
                )
            }
        }

        // Main Editor Area + Optional Symbol Outline
        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            val activeTab = state.activeTab
            if (activeTab != null) {
                OutlinedTextField(
                    value = activeTab.content,
                    onValueChange = onContentChange,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(8.dp)
                        .testTag("code_editor_field"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = Color(0xFFE2E8F0)
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CyberCanvas,
                        unfocusedContainerColor = CyberCanvas,
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberBorder
                    )
                )
            } else {
                Box(modifier = Modifier.weight(1f).fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No file currently open", color = CyberOnSurfaceVariant)
                }
            }

            // Symbol Outline Drawer
            AnimatedVisibility(visible = showSymbolsOutline) {
                Surface(
                    color = CyberSurface,
                    modifier = Modifier
                        .width(180.dp)
                        .fillMaxHeight()
                        .border(1.dp, CyberBorder)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("Symbol Outline", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = CyberPrimary)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(state.symbols) { sym ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = sym.kind.take(1).uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberSecondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${sym.name} (L${sym.line})",
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        color = CyberOnSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Pending Unified Diff Review Card (with REAL Apply Patch action!)
        if (state.pendingDiffLines.isNotEmpty() && state.pendingDiffFile != null) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 240.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Unified Patch Review: ${File(state.pendingDiffFile ?: "").name}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onRejectPatch,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Text("Reject", fontSize = 11.sp, color = CyberError)
                            }
                            Button(
                                onClick = onApprovePatch,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CyberSuccess),
                                modifier = Modifier.height(30.dp).testTag("approve_patch_button")
                            ) {
                                Text("Approve & Apply", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .background(CyberCanvas)
                            .padding(6.dp)
                    ) {
                        items(state.pendingDiffLines) { diff ->
                            val (bgColor, textColor, prefix) = when (diff.type) {
                                DiffType.ADDITION -> Triple(Color(0xFF064E3B), Color(0xFF6EE7B7), "+ ")
                                DiffType.DELETION -> Triple(Color(0xFF7F1D1D), Color(0xFFFCA5A5), "- ")
                                DiffType.CONTEXT -> Triple(Color.Transparent, Color(0xFF94A3B8), "  ")
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(bgColor)
                                    .padding(vertical = 1.dp)
                            ) {
                                Text(
                                    text = "$prefix${diff.text}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    color = textColor,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 3: SANDBOXED TERMINAL
// -------------------------------------------------------------
@Composable
fun TerminalScreen(
    state: WorkstationUiState,
    onRunCommand: (String) -> Unit,
    onClear: () -> Unit
) {
    var commandInput by remember { mutableStateOf("") }
    val quickCommands = listOf("ls -la", "pwd", "git status", "find . -maxdepth 2", "cat MainActivity.kt")

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Sandboxed Notice
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = CyberSurfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        ) {
            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = CyberSuccess, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sandbox Confinement Active: Canonical path validated to workspace root.",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberSuccess
                )
            }
        }

        // Quick Command Chips
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(quickCommands) { cmd ->
                SuggestionChip(
                    onClick = {
                        commandInput = cmd
                        onRunCommand(cmd)
                    },
                    label = { Text(cmd, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    colors = SuggestionChipDefaults.suggestionChipColors(containerColor = CyberSurface)
                )
            }
        }

        // Output Console
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF030712),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Box(modifier = Modifier.padding(12.dp)) {
                val scrollState = rememberScrollState()
                LaunchedEffect(state.terminalOutput) {
                    scrollState.animateScrollTo(scrollState.maxValue)
                }

                Text(
                    text = state.terminalOutput,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                    color = Color(0xFF4ADE80), // Terminal green
                    fontSize = 12.sp,
                    modifier = Modifier.verticalScroll(scrollState)
                )

                if (state.isTerminalRunning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp).align(Alignment.TopEnd),
                        color = CyberPrimary,
                        strokeWidth = 2.dp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Command Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = commandInput,
                onValueChange = { commandInput = it },
                placeholder = { Text("Enter command (e.g., ls, git status)...", fontSize = 12.sp) },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
                modifier = Modifier.weight(1f).testTag("terminal_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = CyberSurface,
                    unfocusedContainerColor = CyberSurface
                )
            )

            Button(
                onClick = {
                    onRunCommand(commandInput)
                    commandInput = ""
                },
                enabled = !state.isTerminalRunning && commandInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberOnPrimary),
                modifier = Modifier.testTag("terminal_run_button")
            ) {
                Text("Run")
            }

            IconButton(onClick = onClear) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Clear", tint = CyberOnSurfaceVariant)
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 4: AUTONOMOUS ReAct AGENT & MCP
// -------------------------------------------------------------
@Composable
fun AgentScreen(
    state: WorkstationUiState,
    onStartAgent: (String) -> Unit
) {
    var objectiveInput by remember { mutableStateOf("Audit workspace for security vulnerabilities and optimize code") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Objective Bar
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Autonomous ReAct Agent Loop", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CyberPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = objectiveInput,
                    onValueChange = { objectiveInput = it },
                    label = { Text("Task Objective") },
                    modifier = Modifier.fillMaxWidth().testTag("agent_objective_field")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onStartAgent(objectiveInput) },
                    enabled = !state.agentState.isRunning && objectiveInput.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                    modifier = Modifier.align(Alignment.End).testTag("start_agent_button")
                ) {
                    if (state.agentState.isRunning) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reasoning...")
                    } else {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Launch Agent Loop")
                    }
                }
            }
        }

        // ReAct Steps Timeline
        Text("ReAct Iteration Breakdown (${state.agentState.steps.size} steps)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.agentState.steps) { step ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Step ${step.stepIndex}: ${step.selectedTool}", fontWeight = FontWeight.Bold, color = CyberPrimary, fontSize = 12.sp)
                            Surface(shape = RoundedCornerShape(6.dp), color = CyberCanvas) {
                                Text(step.selectedTool, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, color = CyberSecondary)
                            }
                        }
                        Text("Thought: ${step.thought}", style = MaterialTheme.typography.bodySmall, color = CyberOnSurface)
                        Text("Observation: ${step.observation}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), fontSize = 11.sp, color = CyberTertiary)
                    }
                }
            }

            if (state.agentState.finalOutput != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberCanvas),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberSuccess),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Execution Synthesis", fontWeight = FontWeight.Bold, color = CyberSuccess)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(state.agentState.finalOutput ?: "", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 5: SECURITY AUDIT & PATCH REVIEW
// -------------------------------------------------------------
@Composable
fun AuditScreen(
    state: WorkstationUiState,
    onRunAudit: () -> Unit,
    onReviewPatch: (AuditFinding) -> Unit
) {
    val report = state.auditReport

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        // Audit Header Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Repository Security Scanner", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (report != null) "Health Score: ${report.healthScore}/100 • Scanned ${report.scannedFilesCount} files in ${report.scanDurationMs}ms" else "Ready to scan project workspace files",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberOnSurfaceVariant
                    )
                }

                Button(
                    onClick = onRunAudit,
                    enabled = !state.isAuditing,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberWarning),
                    modifier = Modifier.testTag("run_audit_button")
                ) {
                    if (state.isAuditing) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(16.dp))
                    } else {
                        Text("Run Audit")
                    }
                }
            }
        }

        // Findings List
        if (report != null) {
            Text("Vulnerability Findings (${report.findings.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(report.findings) { finding ->
                    val badgeColor = when (finding.severity) {
                        FindingSeverity.CRITICAL -> CyberError
                        FindingSeverity.HIGH -> Color(0xFFF97316)
                        FindingSeverity.MEDIUM -> CyberWarning
                        else -> CyberTertiary
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = CyberSurface),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(finding.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                Surface(shape = RoundedCornerShape(6.dp), color = badgeColor.copy(alpha = 0.2f)) {
                                    Text(finding.severity.name, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = badgeColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(finding.description, style = MaterialTheme.typography.bodySmall, color = CyberOnSurfaceVariant)
                            Text("Location: ${File(finding.filePath).name}:${finding.lineNumber}", style = MaterialTheme.typography.labelSmall, color = CyberTertiary)

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = { onReviewPatch(finding) },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberOnPrimary),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Generate & Review Patch", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 6: MODELS HUB & INFERENCE
// -------------------------------------------------------------
@Composable
fun ModelsHubScreen(
    state: WorkstationUiState,
    onSelectModel: (ModelDescriptor) -> Unit,
    onRunInference: (String) -> Unit,
    onCancelInference: () -> Unit,
    onSelectBackend: (InferenceBackendType) -> Unit
) {
    var promptInput by remember { mutableStateOf("Write a high-performance Kotlin coroutine channel routine for background telemetry.") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Local GGUF Models & Acceleration", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        // Models List
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.availableModels) { model ->
                val isSelected = model.id == state.activeLoadedModel?.id
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) CyberSurfaceVariant else CyberSurface,
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, CyberPrimary) else androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier.width(220.dp).clickable { onSelectModel(model) }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(model.name, fontWeight = FontWeight.Bold, color = if (isSelected) CyberPrimary else CyberOnSurface)
                        Text("${model.parameters} • ${model.quantization.name}", style = MaterialTheme.typography.labelSmall, color = CyberSecondary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Size: ${model.sizeMb}MB", style = MaterialTheme.typography.labelSmall, color = CyberOnSurfaceVariant)
                        Text("Min Tier: ${model.requiredMinTier.label}", style = MaterialTheme.typography.labelSmall, color = CyberTertiary)
                    }
                }
            }
        }

        // Test Inference Console
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Inference Stream Console", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    if (state.isInferenceRunning) {
                        Text("${"%.1f".format(state.tokensPerSec)} tok/s", style = MaterialTheme.typography.labelSmall, color = CyberSuccess, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(CyberCanvas, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    val scroll = rememberScrollState()
                    LaunchedEffect(state.inferenceOutput) {
                        scroll.animateScrollTo(scroll.maxValue)
                    }
                    Text(
                        text = if (state.inferenceOutput.isBlank()) "Ready. Model loaded: ${state.activeLoadedModel?.name}." else state.inferenceOutput,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = CyberOnSurface,
                        modifier = Modifier.verticalScroll(scroll)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    label = { Text("Prompt") },
                    maxLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("inference_prompt_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    if (state.isInferenceRunning) {
                        Button(
                            onClick = onCancelInference,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberError)
                        ) {
                            Text("Cancel")
                        }
                    } else {
                        Button(
                            onClick = { onRunInference(promptInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary, contentColor = CyberOnPrimary),
                            modifier = Modifier.testTag("run_inference_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Generate")
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 7: PROJECT MEMORY
// -------------------------------------------------------------
@Composable
fun MemoryScreen(
    state: WorkstationUiState,
    onAddMemory: (String, String, String) -> Unit
) {
    var newTitle by remember { mutableStateOf("") }
    var newContent by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("ARCHITECTURE") }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Persistent Project Knowledge & Memory", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(8.dp))

        // New Memory Input
        Card(
            colors = CardDefaults.cardColors(containerColor = CyberSurface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Add Architectural Decision / Snippet", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = CyberPrimary)
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newContent,
                    onValueChange = { newContent = it },
                    label = { Text("Decision / Knowledge Details") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            onAddMemory(newCategory, newTitle, newContent)
                            newTitle = ""
                            newContent = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberSecondary),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Store Memory")
                }
            }
        }

        // Memory Records List
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(state.memories) { mem ->
                Card(colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(mem.title, fontWeight = FontWeight.Bold, color = CyberPrimary)
                            Text(mem.category, style = MaterialTheme.typography.labelSmall, color = CyberSecondary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(mem.content, style = MaterialTheme.typography.bodySmall, color = CyberOnSurface)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// SCREEN 8: SETTINGS & SECURITY
// -------------------------------------------------------------
@Composable
fun SettingsScreen(
    state: WorkstationUiState,
    onSetTierOverride: (DeviceHardwareTier?) -> Unit,
    onSetPowerPreference: (PowerPreference) -> Unit
) {
    val profile = state.hardwareProfile

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Workstation Configuration & Security", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = CyberPrimary)

        // Hardware Profile Override
        Card(colors = CardDefaults.cardColors(containerColor = CyberSurface), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Hardware Performance Tier", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Measured Tier: ${profile?.calculatedTier?.label ?: "Unknown"}", color = CyberTertiary, style = MaterialTheme.typography.bodySmall)

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    DeviceHardwareTier.values().forEach { tier ->
                        val isSelected = profile?.effectiveTier == tier
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSetTierOverride(if (profile?.userOverrideTier == tier) null else tier) },
                            label = { Text(tier.name.take(4), fontSize = 10.sp) },
                            modifier = Modifier.height(30.dp)
                        )
                    }
                }
            }
        }

        // Power Profile Mode
        Card(colors = CardDefaults.cardColors(containerColor = CyberSurface), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Power & Thermal Policy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PowerPreference.values().forEach { pref ->
                        Button(
                            onClick = { onSetPowerPreference(pref) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberSurfaceVariant
                            ),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(pref.name.replace("_", " "), fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Security Subsystem Status
        Card(colors = CardDefaults.cardColors(containerColor = CyberSurface), shape = RoundedCornerShape(12.dp)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Enterprise Security Architecture", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                HorizontalDivider(color = CyberBorder)
                DetailRow("Android Keystore Key Wrapping", "AES-256-GCM Hardware-Backed", CyberSuccess)
                DetailRow("Database Protection", "Encrypted SQLCipher Architecture", CyberSuccess)
                DetailRow("Terminal Confinement", "Canonical Path Enforced", CyberSuccess)
                DetailRow("Network SSRF Defense", "Private IP / Loopback Blocked", CyberSuccess)
                DetailRow("Process Sanitization", "Secret Environment Scrubbing Active", CyberSuccess)
            }
        }
    }
}
