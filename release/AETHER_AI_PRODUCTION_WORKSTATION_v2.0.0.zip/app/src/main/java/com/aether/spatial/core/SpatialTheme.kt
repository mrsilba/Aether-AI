package com.aether.spatial.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// -------------------------------------------------------------------------
// 1. REFERENCE PALETTE & NEON GLASS TOKENS
// -------------------------------------------------------------------------
object SpatialColors {
    // Deep Cosmic Canvas & Backgrounds
    val CanvasBase = Color(0xFF030511)
    val CanvasNebula = Color(0xFF070B1E)
    val SurfaceDeep = Color(0xFF0A1024)
    val SurfaceWindow = Color(0xE80C142B)      // 91% translucent dark blue glass
    val SurfaceElevated = Color(0xF2121D3A)    // 95% elevated glass
    val SurfaceOverlay = Color(0xF818274B)     // 97% dialogs & command bars

    // Holographic Accents (Matching Reference)
    val HoloCyan = Color(0xFF00F0FF)           // Electric Cyan
    val HoloViolet = Color(0xFF9333EA)         // Neon Violet
    val HoloBlue = Color(0xFF2563EB)           // Royal Electric Blue
    val HoloSky = Color(0xFF38BDF8)            // Cyan Sky
    val HoloEmerald = Color(0xFF10B981)        // Live Green / Online
    val HoloAmber = Color(0xFFF59E0B)          // Star Favorite / Warning
    val HoloRose = Color(0xFFEF4444)           // Hazard / Close

    val GlassBorder = Color(0x3338BDF8)
    val GlassBorderGlow = Color(0x669333EA)
    val SpecularHighlight = Color(0x44FFFFFF)
    val SpecularBorderTop = Color(0x669333EA)
    val SpecularBorderBase = Color(0x3338BDF8)
    val MetallicSubtle = Color(0x33475569)

    // Typography Tokens
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF64748B)

    // Cosmic Gradients
    val GlassGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xEE121E3D),
            Color(0xDD090F24)
        )
    )

    val NeonRimGradient = Brush.linearGradient(
        colors = listOf(
            Color(0x889333EA),
            Color(0x4400F0FF),
            Color(0x221E293B)
        )
    )

    val CoreAuraGradient = Brush.radialGradient(
        colors = listOf(
            HoloViolet.copy(alpha = 0.45f),
            HoloCyan.copy(alpha = 0.25f),
            HoloBlue.copy(alpha = 0.10f),
            Color.Transparent
        )
    )

    val ActivePillGradient = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF6366F1),
            Color(0xFF9333EA)
        )
    )
}

// -------------------------------------------------------------------------
// 2. ADAPTIVE RENDERING QUALITY PROFILES
// -------------------------------------------------------------------------
enum class SpatialRenderQuality(
    val label: String,
    val particleCount: Int,
    val enableDynamicLighting: Boolean,
    val maxConcurrentWindows: Int,
    val targetFps: Int
) {
    BALANCED("Balanced", particleCount = 20, enableDynamicLighting = false, maxConcurrentWindows = 2, targetFps = 30),
    PERFORMANCE("Performance", particleCount = 45, enableDynamicLighting = true, maxConcurrentWindows = 3, targetFps = 60),
    HIGH_QUALITY("High Quality", particleCount = 75, enableDynamicLighting = true, maxConcurrentWindows = 4, targetFps = 60),
    ULTRA_QUALITY("Ultra 3D Quality", particleCount = 120, enableDynamicLighting = true, maxConcurrentWindows = 6, targetFps = 120)
}

// -------------------------------------------------------------------------
// 3. SPATIAL ELEVATION MODIFIERS & MATERIAL PRIMITIVES
// -------------------------------------------------------------------------
fun Modifier.spatialGlassPanel(
    shapeRadius: Dp = 16.dp,
    elevation: Dp = 10.dp,
    isActive: Boolean = false
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = RoundedCornerShape(shapeRadius),
        ambientColor = if (isActive) SpatialColors.HoloViolet.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.6f),
        spotColor = if (isActive) SpatialColors.HoloCyan.copy(alpha = 0.45f) else Color.Black.copy(alpha = 0.7f)
    )
    .clip(RoundedCornerShape(shapeRadius))
    .background(SpatialColors.SurfaceWindow)
    .border(
        width = 1.2.dp,
        brush = if (isActive) Brush.linearGradient(
            listOf(SpatialColors.HoloViolet.copy(alpha = 0.9f), SpatialColors.HoloCyan.copy(alpha = 0.8f))
        ) else SpatialColors.NeonRimGradient,
        shape = RoundedCornerShape(shapeRadius)
    )

val SpatialColorScheme = darkColorScheme(
    primary = SpatialColors.HoloCyan,
    onPrimary = Color(0xFF001E26),
    secondary = SpatialColors.HoloViolet,
    onSecondary = Color.White,
    tertiary = SpatialColors.HoloSky,
    background = SpatialColors.CanvasBase,
    onBackground = SpatialColors.TextPrimary,
    surface = SpatialColors.SurfaceDeep,
    onSurface = SpatialColors.TextPrimary,
    surfaceVariant = SpatialColors.SurfaceWindow,
    onSurfaceVariant = SpatialColors.TextSecondary,
    outline = SpatialColors.GlassBorder,
    error = SpatialColors.HoloRose
)

@Composable
fun AetherSpatialTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SpatialColorScheme,
        content = content
    )
}
