package com.aether.spatial.window

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.aether.spatial.core.SpatialColors
import com.aether.spatial.core.spatialGlassPanel
import kotlin.math.roundToInt

@Composable
fun SpatialWindow(
    windowState: SpatialWindowState,
    modifier: Modifier = Modifier,
    onMove: (Offset) -> Unit,
    onResize: (androidx.compose.ui.unit.Dp, androidx.compose.ui.unit.Dp) -> Unit,
    onFocus: () -> Unit,
    onClose: () -> Unit,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onTogglePin: () -> Unit,
    content: @Composable BoxScope.() -> Unit
) {
    if (!windowState.isVisible) return

    val density = LocalDensity.current

    if (windowState.isMinimized) {
        // Minimized Dock Pill
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = SpatialColors.SurfaceElevated,
            border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.HoloCyan.copy(alpha = 0.6f)),
            modifier = Modifier
                .offset { IntOffset(windowState.position.x.roundToInt(), windowState.position.y.roundToInt()) }
                .clickable { onFocus() }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(SpatialColors.HoloCyan))
                Spacer(modifier = Modifier.width(6.dp))
                Text(windowState.type.title, style = MaterialTheme.typography.labelSmall, color = SpatialColors.TextPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.OpenInFull,
                    contentDescription = "Restore",
                    tint = SpatialColors.HoloCyan,
                    modifier = Modifier.size(14.dp).clickable { onFocus() }
                )
            }
        }
        return
    }

    val windowModifier = if (windowState.isMaximized) {
        Modifier
            .fillMaxSize()
            .zIndex(100f)
            .padding(top = 48.dp, bottom = 64.dp, start = 8.dp, end = 8.dp)
    } else {
        Modifier
            .offset { IntOffset(windowState.position.x.roundToInt(), windowState.position.y.roundToInt()) }
            .size(windowState.size)
            .zIndex(windowState.zIndex)
    }

    Box(
        modifier = windowModifier
            .spatialGlassPanel(shapeRadius = 14.dp, elevation = 10.dp, isActive = true)
            .clickable { onFocus() }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Generous 38dp Window Header Bar with Tactile Drag Grip Area
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .background(SpatialColors.SurfaceElevated)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Drag Grip Area (Title + Tactile dots)
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                onMove(dragAmount)
                            }
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⋮⋮", color = SpatialColors.HoloSky.copy(alpha = 0.5f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(SpatialColors.HoloCyan))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = windowState.type.title,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SpatialColors.TextPrimary,
                        maxLines = 1
                    )
                    if (windowState.isPinned) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.PushPin,
                            contentDescription = "Pinned",
                            tint = SpatialColors.HoloAmber,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }

                // Window Controls Bar
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    WindowHeaderAction(
                        icon = if (windowState.isPinned) Icons.Default.PushPin else Icons.Default.PinEnd,
                        contentDescription = "Pin",
                        tint = if (windowState.isPinned) SpatialColors.HoloAmber else SpatialColors.TextMuted,
                        onClick = onTogglePin
                    )
                    WindowHeaderAction(
                        icon = Icons.Default.Minimize,
                        contentDescription = "Minimize",
                        tint = SpatialColors.TextMuted,
                        onClick = onMinimize
                    )
                    WindowHeaderAction(
                        icon = if (windowState.isMaximized) Icons.Default.CloseFullscreen else Icons.Default.OpenInFull,
                        contentDescription = "Maximize",
                        tint = SpatialColors.TextMuted,
                        onClick = onToggleMaximize
                    )
                    WindowHeaderAction(
                        icon = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = SpatialColors.HoloRose,
                        onClick = onClose
                    )
                }
            }

            // Window Content Body
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(SpatialColors.CanvasBase.copy(alpha = 0.75f))
            ) {
                content()
            }
        }

        // Bottom-Right Corner Resize Grip Handle
        if (!windowState.isMaximized) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .align(Alignment.BottomEnd)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            with(density) {
                                val dW = dragAmount.x.toDp()
                                val dH = dragAmount.y.toDp()
                                onResize(dW, dH)
                            }
                        }
                    },
                contentAlignment = Alignment.BottomEnd
            ) {
                Icon(
                    imageVector = Icons.Default.NorthWest,
                    contentDescription = "Resize",
                    tint = SpatialColors.HoloCyan.copy(alpha = 0.6f),
                    modifier = Modifier.size(14.dp).padding(end = 4.dp, bottom = 4.dp)
                )
            }
        }
    }
}

@Composable
fun WindowHeaderAction(
    icon: ImageVector,
    contentDescription: String,
    tint: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(24.dp)
            .clip(CircleShape)
            .background(SpatialColors.SurfaceDeep)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(12.dp)
        )
    }
}
