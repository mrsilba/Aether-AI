package com.aether.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val CyberCanvas = Color(0xFF070B14)
val CyberSurface = Color(0xFF0F172A)
val CyberSurfaceVariant = Color(0xFF1E293B)
val CyberBorder = Color(0xFF334155)

val CyberPrimary = Color(0xFF00E5FF)       // Electric Cyan
val CyberSecondary = Color(0xFFA855F7)     // Neon Violet
val CyberTertiary = Color(0xFF38BDF8)      // Sky Blue
val CyberSuccess = Color(0xFF10B981)       // Emerald Green
val CyberWarning = Color(0xFFF59E0B)       // Amber
val CyberError = Color(0xFFEF4444)         // Coral Red

val CyberOnPrimary = Color(0xFF001F29)
val CyberOnSurface = Color(0xFFF1F5F9)
val CyberOnSurfaceVariant = Color(0xFF94A3B8)

private val DarkColorScheme = darkColorScheme(
    primary = CyberPrimary,
    onPrimary = CyberOnPrimary,
    secondary = CyberSecondary,
    onSecondary = Color.White,
    tertiary = CyberTertiary,
    background = CyberCanvas,
    onBackground = CyberOnSurface,
    surface = CyberSurface,
    onSurface = CyberOnSurface,
    surfaceVariant = CyberSurfaceVariant,
    onSurfaceVariant = CyberOnSurfaceVariant,
    error = CyberError,
    outline = CyberBorder
)

@Composable
fun AetherWorkstationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
