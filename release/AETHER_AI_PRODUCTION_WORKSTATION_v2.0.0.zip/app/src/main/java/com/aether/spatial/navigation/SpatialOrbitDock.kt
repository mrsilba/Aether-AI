package com.aether.spatial.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.spatial.core.CompanionRole
import com.aether.spatial.core.SpatialColors
import com.aether.spatial.window.WindowType
import com.aether.spatial.window.WorkspacePreset

@Composable
fun SpatialOrbitDock(
    activeWindows: List<WindowType>,
    currentPreset: WorkspacePreset,
    activeCompanion: CompanionRole,
    modifier: Modifier = Modifier,
    onOpenWindow: (WindowType) -> Unit,
    onApplyPreset: (WorkspacePreset) -> Unit,
    onSelectCompanion: (CompanionRole) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Expandable Presets & Companion Selector Drawer
        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically(animationSpec = tween(240, easing = FastOutSlowInEasing)),
            exit = shrinkVertically(animationSpec = tween(180, easing = FastOutSlowInEasing))
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = SpatialColors.SurfaceElevated,
                border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.SpecularBorderTop),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Presets Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Workspace Presets", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SpatialColors.HoloCyan)
                        Text(currentPreset.label, style = MaterialTheme.typography.labelSmall, color = SpatialColors.HoloViolet)
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(WorkspacePreset.values()) { preset ->
                            val isSelected = currentPreset == preset
                            FilterChip(
                                selected = isSelected,
                                onClick = { onApplyPreset(preset) },
                                label = { Text(preset.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SpatialColors.HoloCyan.copy(alpha = 0.25f),
                                    selectedLabelColor = SpatialColors.HoloCyan
                                )
                            )
                        }
                    }

                    HorizontalDivider(color = SpatialColors.MetallicSubtle)

                    // Companion Switcher
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active 3D AI Companion", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SpatialColors.HoloViolet)
                        Text(activeCompanion.title, style = MaterialTheme.typography.labelSmall, color = activeCompanion.primaryColor)
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(CompanionRole.values()) { role ->
                            val isSelected = activeCompanion == role
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) role.primaryColor.copy(alpha = 0.2f) else SpatialColors.SurfaceDeep,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) role.primaryColor else SpatialColors.MetallicSubtle),
                                modifier = Modifier.clickable { onSelectCompanion(role) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(role.primaryColor))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(role.title, fontSize = 11.sp, color = SpatialColors.TextPrimary)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Floating Spatial Summoning Dock Bar
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = SpatialColors.SurfaceOverlay,
            border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.SpecularBorderTop),
            modifier = Modifier.wrapContentWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Expand / Collapse Drawer Toggle
                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.Tune,
                        contentDescription = "Presets",
                        tint = SpatialColors.HoloCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(modifier = Modifier.width(1.dp).height(24.dp).background(SpatialColors.SpecularBorderBase))

                // Floating Module Quick Summon Orbs
                DockModuleOrb(WindowType.EDITOR, Icons.Default.Code, SpatialColors.HoloCyan, activeWindows.contains(WindowType.EDITOR)) { onOpenWindow(WindowType.EDITOR) }
                DockModuleOrb(WindowType.TERMINAL, Icons.Default.Terminal, SpatialColors.HoloEmerald, activeWindows.contains(WindowType.TERMINAL)) { onOpenWindow(WindowType.TERMINAL) }
                DockModuleOrb(WindowType.AGENT, Icons.Default.SmartToy, SpatialColors.HoloViolet, activeWindows.contains(WindowType.AGENT)) { onOpenWindow(WindowType.AGENT) }
                DockModuleOrb(WindowType.AUDIT, Icons.Default.Security, SpatialColors.HoloAmber, activeWindows.contains(WindowType.AUDIT)) { onOpenWindow(WindowType.AUDIT) }
                DockModuleOrb(WindowType.MODELS, Icons.Default.Psychology, SpatialColors.HoloSky, activeWindows.contains(WindowType.MODELS)) { onOpenWindow(WindowType.MODELS) }
                DockModuleOrb(WindowType.DEVICE_MONITOR, Icons.Default.Speed, Color(0xFFE879F9), activeWindows.contains(WindowType.DEVICE_MONITOR)) { onOpenWindow(WindowType.DEVICE_MONITOR) }
                DockModuleOrb(WindowType.MEMORY, Icons.Default.Storage, Color(0xFFFBBF24), activeWindows.contains(WindowType.MEMORY)) { onOpenWindow(WindowType.MEMORY) }
                DockModuleOrb(WindowType.SETTINGS, Icons.Default.Settings, SpatialColors.TextSecondary, activeWindows.contains(WindowType.SETTINGS)) { onOpenWindow(WindowType.SETTINGS) }
            }
        }
    }
}

@Composable
fun DockModuleOrb(
    type: WindowType,
    icon: ImageVector,
    color: Color,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(if (isActive) color.copy(alpha = 0.25f) else SpatialColors.SurfaceDeep)
            .border(
                width = if (isActive) 1.5.dp else 1.dp,
                color = if (isActive) color else SpatialColors.MetallicSubtle,
                shape = CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = type.title,
            tint = if (isActive) color else SpatialColors.TextSecondary,
            modifier = Modifier.size(18.dp)
        )
    }
}
