package com.aether.spatial.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.editor.DiffType
import com.aether.hardware.HardwareCapabilityProfile
import com.aether.inference.InferenceBackendType
import com.aether.project.AuditFinding
import com.aether.spatial.core.*
import com.aether.ui.WorkstationUiState
import com.aether.ui.WorkstationViewModel
import java.io.File

@Composable
fun ReferenceMasterWorkstationScreen(
    viewModel: WorkstationViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    var activeNavTab by remember { mutableStateOf("Workspace") }
    var activePreset by remember { mutableStateOf("Developer") }
    var activeCompanionRole by remember { mutableStateOf(CompanionRole.CODER) }
    var searchQuery by remember { mutableStateOf("") }
    var terminalInput by remember { mutableStateOf("") }

    LaunchedEffect(state.statusMessage) {
        state.statusMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearStatusMessage()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        SpatialColors.CanvasBase,
                        SpatialColors.CanvasNebula,
                        Color(0xFF040817)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            // -------------------------------------------------------------
            // 1. TOP HEADER (Reference App Bar)
            // -------------------------------------------------------------
            ReferenceTopHeader(
                searchQuery = searchQuery,
                onSearchChange = { searchQuery = it },
                batteryPct = state.hardwareProfile?.batteryPercent ?: 92,
                timeString = "12:45"
            )

            // -------------------------------------------------------------
            // 2. MAIN WORKSPACE WITH LEFT DOCK + CENTER STAGE
            // -------------------------------------------------------------
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                // Left Vertical Navigation Dock
                Surface(
                    shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
                    color = SpatialColors.SurfaceWindow,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpatialColors.GlassBorder),
                    modifier = Modifier
                        .width(62.dp)
                        .fillMaxHeight()
                        .padding(vertical = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            LeftRailItem(Icons.Default.Home, "Home", activeNavTab == "Home") { activeNavTab = "Home" }
                            LeftRailItem(Icons.Default.Folder, "Projects", activeNavTab == "Projects") { activeNavTab = "Projects" }
                            LeftRailItem(Icons.Default.SmartToy, "Agents", activeNavTab == "Agents") {
                                activeNavTab = "Agents"
                                activeCompanionRole = CompanionRole.PROJECT_MANAGER
                            }
                            LeftRailItem(Icons.Default.Handyman, "Tools", activeNavTab == "Tools") { activeNavTab = "Tools" }
                            LeftRailItem(Icons.Default.Psychology, "Models", activeNavTab == "Models") { activeNavTab = "Models" }
                            LeftRailItem(Icons.Default.Terminal, "Terminal", activeNavTab == "Terminal") { activeNavTab = "Terminal" }
                            LeftRailItem(Icons.Default.Settings, "Settings", activeNavTab == "Settings") { activeNavTab = "Settings" }
                        }

                        // Bottom Grid Icon
                        IconButton(onClick = {}, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Apps, contentDescription = "Menu", tint = SpatialColors.TextMuted, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                // Workspace Center Stage (Scrollable Responsive Canvas)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // UPPER ROW: Active Project + AETHER CORE + Companions Showcase
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        // Left Column: Active Project + System Monitor
                        Column(
                            modifier = Modifier.width(260.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            ReferenceActiveProjectCard(
                                projectName = "Quantum-Dev",
                                projectPath = "/storage/emulated/0/Quantum-Dev",
                                onOpenProject = { viewModel.selectEditorTab(0) }
                            )

                            ReferenceSystemMonitorCard(profile = state.hardwareProfile)
                        }

                        // Center: 3D AETHER CORE Armillary Sphere
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            AetherCoreArmillary3D(
                                systemStatus = if (state.isInferenceRunning) "Inference Active" else "Optimal Performance",
                                onToolCubeClicked = { tool ->
                                    when (tool) {
                                        "CODE" -> viewModel.selectEditorTab(0)
                                        "TERMINAL" -> terminalInput = "git status"
                                        "AGENT" -> activeNavTab = "Agents"
                                        "EXPLORER" -> activeNavTab = "Projects"
                                    }
                                }
                            )
                        }

                        // Right Column: Companions Showcase + Hologram Pedestal
                        Column(
                            modifier = Modifier.width(280.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CompanionsShowcaseCard(
                                activeRole = activeCompanionRole,
                                onRoleSelected = { activeCompanionRole = it }
                            )

                            HologramPedestalCompanion(
                                activeRole = activeCompanionRole,
                                speechText = when (activeCompanionRole) {
                                    CompanionRole.CODER -> "Syntax highlighting and buffers loaded."
                                    CompanionRole.DEBUGGER -> "Sandbox terminal ready for commands."
                                    CompanionRole.SECURITY_GUARDIAN -> "Zero-trust path security verified."
                                    CompanionRole.ARCHITECT -> "Modular workstation active."
                                    else -> "Everything is under control!"
                                },
                                onCompanionClicked = {
                                    val all = CompanionRole.values()
                                    val next = all[(activeCompanionRole.ordinal + 1) % all.size]
                                    activeCompanionRole = next
                                }
                            )
                        }
                    }

                    // MIDDLE ROW: Floating Tools + Code Editor + Terminal + Project Tree + Quick Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Floating Tools Grid Card
                        ReferenceFloatingToolsCard(
                            modifier = Modifier.width(260.dp),
                            onToolClicked = { toolName ->
                                when (toolName.lowercase()) {
                                    "code" -> viewModel.selectEditorTab(0)
                                    "terminal" -> terminalInput = "ls -la"
                                    "build" -> viewModel.runTerminalCommand("gradle build")
                                    "security" -> viewModel.runProjectAudit()
                                }
                            }
                        )

                        // Real Code Editor Window (Matching Reference main.kt card)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SpatialColors.SurfaceWindow,
                            border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
                            modifier = Modifier
                                .weight(1.1f)
                                .height(260.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Editor Window Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(SpatialColors.SurfaceElevated)
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(16.dp)
                                                .clip(RoundedCornerShape(3.dp))
                                                .background(Color(0xFF7C3AED)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("K", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = state.activeTab?.fileName ?: "main.kt",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = SpatialColors.TextPrimary
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(12.dp))
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Default.Save, contentDescription = "Save", tint = SpatialColors.HoloCyan, modifier = Modifier.size(14.dp).clickable { viewModel.saveActiveFile() })
                                        Icon(Icons.Default.Undo, contentDescription = "Undo", tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp).clickable { viewModel.undoEditor() })
                                        Icon(Icons.Default.Redo, contentDescription = "Redo", tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp).clickable { viewModel.redoEditor() })
                                        Icon(Icons.Default.OpenInFull, contentDescription = "Max", tint = SpatialColors.TextMuted, modifier = Modifier.size(14.dp))
                                        Icon(Icons.Default.Close, contentDescription = "Close", tint = SpatialColors.HoloRose, modifier = Modifier.size(14.dp))
                                    }
                                }

                                // Code Buffer with Line Numbers Gutter
                                val activeTab = state.activeTab
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .background(SpatialColors.CanvasBase)
                                ) {
                                    // Line Numbers Gutter
                                    Column(
                                        modifier = Modifier
                                            .width(28.dp)
                                            .fillMaxHeight()
                                            .background(SpatialColors.SurfaceDeep)
                                            .padding(top = 8.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("1", color = SpatialColors.HoloViolet, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("2", color = SpatialColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("3", color = SpatialColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("4", color = SpatialColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("58", color = SpatialColors.TextMuted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }

                                    OutlinedTextField(
                                        value = activeTab?.content ?: "fun main() {\n    println(\"Hello, AETHER!\")\n    launchAI()\n}",
                                        onValueChange = { viewModel.updateEditorContent(it) },
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .testTag("code_editor_field"),
                                        textStyle = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            lineHeight = 16.sp,
                                            color = SpatialColors.TextPrimary
                                        ),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = SpatialColors.CanvasBase,
                                            unfocusedContainerColor = SpatialColors.CanvasBase,
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent
                                        )
                                    )
                                }

                                // Editor Bottom Action Bar (matching reference image)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(SpatialColors.SurfaceElevated)
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("λ.", color = SpatialColors.HoloViolet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("${state.symbols.size} symbols", fontSize = 10.sp, color = SpatialColors.TextMuted)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF3B82F6))
                                                .clickable { viewModel.runTerminalCommand("kotlinc -script main.kt") },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(SpatialColors.HoloViolet),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Splitscreen, contentDescription = "Split", tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }
                            }
                        }

                        // Real Terminal Window (Matching Reference Terminal Card)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = SpatialColors.SurfaceWindow,
                            border = androidx.compose.foundation.BorderStroke(1.2.dp, SpatialColors.GlassBorderGlow),
                            modifier = Modifier
                                .weight(1f)
                                .height(260.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxSize()) {
                                // Header
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(SpatialColors.SurfaceElevated)
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Terminal, contentDescription = null, tint = SpatialColors.HoloEmerald, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Terminal", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SpatialColors.TextPrimary)
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Icon(Icons.Default.Minimize, contentDescription = null, tint = SpatialColors.TextMuted, modifier = Modifier.size(13.dp))
                                        Icon(Icons.Default.Close, contentDescription = null, tint = SpatialColors.HoloRose, modifier = Modifier.size(13.dp))
                                    }
                                }

                                // Console Output
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth()
                                        .background(Color(0xFF03050C))
                                        .padding(8.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text("▶ build successful!", color = SpatialColors.HoloEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                        Text("> Installing...", color = SpatialColors.TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Text("▶ App running on device ✓", color = SpatialColors.HoloEmerald, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("A:\\>] ${state.terminalOutput.takeLast(160)}", color = Color(0xFF6EE7B7), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                // Input Row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(SpatialColors.SurfaceDeep)
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("A:\\>", color = SpatialColors.HoloCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    OutlinedTextField(
                                        value = terminalInput,
                                        onValueChange = { terminalInput = it },
                                        singleLine = true,
                                        placeholder = { Text("enter command...", fontSize = 10.sp) },
                                        textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp),
                                        modifier = Modifier.weight(1f),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = Color.Transparent,
                                            unfocusedContainerColor = Color.Transparent,
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent
                                        )
                                    )
                                    IconButton(
                                        onClick = {
                                            viewModel.runTerminalCommand(terminalInput)
                                            terminalInput = ""
                                        },
                                        modifier = Modifier.size(26.dp).testTag("terminal_run_button")
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = SpatialColors.HoloCyan)
                                    }
                                }
                            }
                        }

                        // Right Column: Project Tree + Quick Actions
                        Column(
                            modifier = Modifier.width(220.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            ReferenceProjectTreeCard(
                                onFileSelected = { fileName ->
                                    // Switch or open tab
                                    val idx = state.openTabs.indexOfFirst { it.fileName == fileName }
                                    if (idx >= 0) viewModel.selectEditorTab(idx)
                                }
                            )

                            ReferenceQuickActionsCard(
                                onNewProject = { viewModel.addMemory("ARCHITECTURE", "New Project Workspace", "Project scaffolding initialized.") },
                                onRunBuild = { viewModel.runTerminalCommand("gradle build") },
                                onScanSecurity = { viewModel.runProjectAudit() },
                                onOpenSecurity = { activeNavTab = "Settings" }
                            )
                        }
                    }

                    // LOWER ROW: Toast Notification + Workspace Presets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ReferenceBuildNotificationToast(
                            title = "Build Completed Successfully!",
                            subtitle = "Your app is ready to run.",
                            timeAgo = "2m ago"
                        )

                        ReferenceWorkspacePresetsBar(
                            currentPreset = activePreset,
                            onPresetSelect = { activePreset = it }
                        )
                    }
                }
            }

            // -------------------------------------------------------------
            // 3. BOTTOM NAVIGATION DOCK (Matching Reference Image)
            // -------------------------------------------------------------
            ReferenceBottomNavDock(
                currentTab = activeNavTab,
                onTabSelect = { activeNavTab = it },
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 6.dp)
                    .windowInsetsPadding(WindowInsets.navigationBars)
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 70.dp)
        )
    }
}

@Composable
fun LeftRailItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isSelected) Color(0xFF6366F1).copy(alpha = 0.4f) else Color.Transparent
                )
                .border(
                    width = if (isSelected) 1.2.dp else 0.dp,
                    color = if (isSelected) SpatialColors.HoloCyan else Color.Transparent,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) SpatialColors.HoloCyan else SpatialColors.TextSecondary,
                modifier = Modifier.size(19.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 9.sp,
            color = if (isSelected) SpatialColors.HoloCyan else SpatialColors.TextMuted,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
