package com.aether.local.inference

import android.util.Log

/**
 * Native JNI bridge connecting AETHER AI with the optimized C++ GGUF inference engine
 * (aether_llama_jni.cpp) and polyglot code indexer (aether_polyglot_indexer_jni.cpp).
 *
 * Provides safe dynamic binding with graceful fallback when the native shared library
 * is not compiled or present in the current target runtime (e.g. JVM unit tests or
 * pure Android runtimes without precompiled NDK binaries).
 */
object LlamaCppNativeBridge {
    private const val TAG = "LlamaCppNativeBridge"

    @Volatile
    private var isNativeLibraryLoaded = false

    init {
        try {
            System.loadLibrary("aether_llama")
            isNativeLibraryLoaded = true
            Log.i(TAG, "Native library 'libaether_llama.so' successfully loaded.")
        } catch (e: UnsatisfiedLinkError) {
            Log.d(TAG, "Native library 'libaether_llama.so' not found on library path; operating in high-performance runtime fallback mode.")
            isNativeLibraryLoaded = false
        } catch (e: Exception) {
            Log.w(TAG, "Initialization of native bridge encountered exception: ${e.message}")
            isNativeLibraryLoaded = false
        }
    }

    val isAvailable: Boolean get() = isNativeLibraryLoaded

    external fun nativeLoadModel(
        modelPath: String,
        contextLength: Int,
        threads: Int
    ): Long

    external fun nativeGenerateStream(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        outBuffer: ByteArray,
        outBufferCapacity: Int
    ): Int

    external fun nativeClearKvCache(handle: Long)

    external fun nativeCancel(handle: Long)

    external fun nativeUnloadModel(handle: Long): Boolean

    external fun nativeIndexSymbols(
        sourceCode: String,
        outBuffer: ByteArray,
        outBufferCapacity: Int
    ): Int
}
