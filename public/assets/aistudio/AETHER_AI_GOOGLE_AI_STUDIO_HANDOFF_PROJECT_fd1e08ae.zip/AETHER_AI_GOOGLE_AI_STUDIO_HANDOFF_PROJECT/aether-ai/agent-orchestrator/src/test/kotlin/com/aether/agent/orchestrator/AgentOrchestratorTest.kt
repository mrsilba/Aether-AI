package com.aether.agent.orchestrator

import com.aether.agent.runtime.AgentRole
import com.aether.agent.runtime.CoreAgentsRegistry
import com.aether.core.common.AetherResult
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentOrchestratorTest {
    private val orchestrator = SupervisorOrchestrator()
    private val loopEngine = AutonomousAgentLoopEngine()

    @Test
    fun `detects cyclic dependencies in task DAG`() {
        val cyclic = listOf(
            AgentSubTask("a", "Task A", AgentRole.ARCHITECT, dependsOn = setOf("b")),
            AgentSubTask("b", "Task B", AgentRole.SENIOR_DEVELOPER, dependsOn = setOf("a"))
        )
        val res = orchestrator.buildParallelWaves(cyclic)
        assertTrue(res is AetherResult.Error)
        assertEquals("DAG_CYCLE_DETECTED", (res as AetherResult.Error).code)
    }

    @Test
    fun `executes ReAct loop for authorized tools and blocks unauthorized tools`() = runTest {
        val architect = CoreAgentsRegistry.defaultAgents.first { it.role == AgentRole.ARCHITECT }
        val validPlan = listOf(
            Triple("read_file", "Read settings.gradle.kts") { AetherResult.Success("24 modules") }
        )
        val okRes = loopEngine.executeReActLoop(architect, "Inspect modules", validPlan)
        assertTrue(okRes is AetherResult.Success)
        assertEquals(1, (okRes as AetherResult.Success).data.size)

        // Architect is read-only and not allowed to call write_file
        val unauthorizedPlan = listOf(
            Triple("write_file", "Mutate build.gradle.kts") { AetherResult.Success("written") }
        )
        val deniedRes = loopEngine.executeReActLoop(architect, "Mutate build", unauthorizedPlan)
        assertTrue(deniedRes is AetherResult.Error)
        assertEquals("AGENT_TOOL_UNAUTHORIZED", (deniedRes as AetherResult.Error).code)
    }
}
