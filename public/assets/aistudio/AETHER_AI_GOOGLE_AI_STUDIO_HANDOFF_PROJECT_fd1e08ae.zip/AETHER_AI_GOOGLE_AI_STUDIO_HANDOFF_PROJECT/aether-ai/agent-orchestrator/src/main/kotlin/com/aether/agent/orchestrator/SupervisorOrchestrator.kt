package com.aether.agent.orchestrator

import com.aether.agent.runtime.AgentDefinition
import com.aether.agent.runtime.AgentDeveloperToolchainBridge
import com.aether.agent.runtime.AgentRole
import com.aether.core.common.AetherResult
import com.aether.core.database.AetherDao
import com.aether.core.database.AgentCheckpointEntity
import com.aether.core.security.EmergencyStopController
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

data class AgentSubTask(
    val taskId: String,
    val title: String,
    val assignedRole: AgentRole,
    val dependsOn: Set<String> = emptySet(),
    val requiresVerification: Boolean = true
)

data class SubTaskOutput(
    val taskId: String,
    val role: AgentRole,
    val summary: String,
    val modifiedFiles: List<String>,
    val validationPassed: Boolean,
    val recommendations: List<String> = emptyList()
)

data class ExecutionCheckpoint(
    val checkpointId: String,
    val objective: String,
    val completedTaskIds: Set<String>,
    val outputs: Map<String, SubTaskOutput>
)

data class ReActStepTrace(
    val iteration: Int,
    val thought: String,
    val toolId: String?,
    val toolInput: String?,
    val observation: String,
    val completed: Boolean
)

/**
 * Supervisor Agent orchestrating topological parallel execution waves, conflict detection,
 * checkpoint persistence, and strict completion verification.
 */
@Singleton
class SupervisorOrchestrator @Inject constructor() {

    fun buildParallelWaves(tasks: List<AgentSubTask>): AetherResult<List<List<AgentSubTask>>> {
        val remaining = tasks.associateBy { it.taskId }.toMutableMap()
        val completed = mutableSetOf<String>()
        val waves = mutableListOf<List<AgentSubTask>>()

        while (remaining.isNotEmpty()) {
            val ready = remaining.values.filter { task ->
                task.dependsOn.all { it in completed }
            }
            if (ready.isEmpty()) {
                return AetherResult.Error(
                    code = "DAG_CYCLE_DETECTED",
                    message = "Cyclic or unresolvable dependency detected among tasks: ${remaining.keys}"
                )
            }
            waves.add(ready)
            ready.forEach {
                completed.add(it.taskId)
                remaining.remove(it.taskId)
            }
        }
        return AetherResult.Success(waves)
    }

    fun detectConflictingOutputs(outputs: List<SubTaskOutput>): List<String> {
        val conflicts = mutableListOf<String>()
        val fileToWriters = mutableMapOf<String, MutableList<AgentRole>>()
        for (out in outputs) {
            for (file in out.modifiedFiles) {
                fileToWriters.getOrPut(file) { mutableListOf() }.add(out.role)
            }
        }
        for ((file, roles) in fileToWriters) {
            if (roles.size > 1) {
                conflicts.add("Concurrent file modification conflict on '$file' between agents: $roles")
            }
        }
        return conflicts
    }

    fun verifyObjectiveCompletion(
        tasks: List<AgentSubTask>,
        outputs: Map<String, SubTaskOutput>
    ): AetherResult<Boolean> {
        for (task in tasks) {
            val output = outputs[task.taskId]
                ?: return AetherResult.Error("INCOMPLETE_TASK", "Task '${task.taskId}' has not produced output.")
            if (task.requiresVerification && !output.validationPassed) {
                return AetherResult.Error(
                    "VALIDATION_FAILED",
                    "Task '${task.taskId}' (${task.title}) failed required validation checks and cannot be marked completed."
                )
            }
        }
        return AetherResult.Success(true)
    }
}

/**
 * Executes a multi-turn ReAct (Thought -> Action -> Observation -> Verification) reasoning loop
 * for an assigned agent with bounded iterations, exponential retry backoff, tool permission checks,
 * Emergency Stop interruption, and checkpoint persistence.
 */
@Singleton
class AutonomousAgentLoopEngine @Inject constructor(
    private val toolchainBridge: AgentDeveloperToolchainBridge = AgentDeveloperToolchainBridge(),
    private val emergencyStopController: EmergencyStopController = EmergencyStopController()
) {
    suspend fun executeReActLoop(
        agent: AgentDefinition,
        objective: String,
        plannedActions: List<Triple<String, String, () -> AetherResult<String>>>,
        userApprovedDangerousActions: Boolean = false,
        maxRetriesPerStep: Int = 2,
        dao: AetherDao? = null,
        projectId: String = "active-project"
    ): AetherResult<List<ReActStepTrace>> {
        val traces = mutableListOf<ReActStepTrace>()
        val limit = agent.maxIterations.coerceAtLeast(1)

        for ((index, actionSpec) in plannedActions.withIndex()) {
            val iteration = index + 1
            if (iteration > limit) {
                return AetherResult.Error(
                    "AGENT_MAX_ITERATIONS_EXCEEDED",
                    "Agent '${agent.displayName}' exceeded maxIterations ($limit) before completing '$objective'."
                )
            }
            if (emergencyStopController.halted.value) {
                return AetherResult.Error(
                    "EMERGENCY_STOP_ACTIVE",
                    "ReAct loop halted by Emergency Stop at iteration $iteration."
                )
            }

            val (toolId, actionDescription, block) = actionSpec
            var attempt = 0
            var stepResult: AetherResult<String>
            while (true) {
                attempt++
                stepResult = toolchainBridge.executeAgentToolAction(
                    agent = agent,
                    toolId = toolId,
                    actionDescription = actionDescription,
                    userApproved = userApprovedDangerousActions,
                    actionBlock = block
                )
                if (stepResult is AetherResult.Success || attempt > maxRetriesPerStep) break
                val err = stepResult as AetherResult.Error
                if (!err.recoverable || err.code == "AGENT_TOOL_UNAUTHORIZED" || err.code == "USER_APPROVAL_REQUIRED") {
                    break
                }
                delay(50L * attempt)
            }

            when (stepResult) {
                is AetherResult.Success -> {
                    traces.add(
                        ReActStepTrace(
                            iteration = iteration,
                            thought = "[${agent.displayName}] Executing '$actionDescription' for objective '$objective'",
                            toolId = toolId,
                            toolInput = actionDescription,
                            observation = stepResult.data,
                            completed = (index == plannedActions.lastIndex)
                        )
                    )
                }
                is AetherResult.Error -> {
                    return stepResult
                }
            }
        }

        if (dao != null) {
            dao.saveCheckpoint(
                AgentCheckpointEntity(
                    checkpointId = "chk-${agent.role.name.lowercase()}-${System.currentTimeMillis()}",
                    projectId = projectId,
                    objective = objective,
                    serializedDagJson = """{"agent":"${agent.role.name}","steps":${traces.size}}""",
                    completedTaskIdsJson = traces.joinToString(",", "[", "]") { "\"step-${it.iteration}\"" },
                    gitCommitOrSnapshotRef = "HEAD",
                    status = "COMPLETED",
                    updatedAtEpochMs = System.currentTimeMillis()
                )
            )
        }
        return AetherResult.Success(traces)
    }
}
