package com.aether.semantic.search

import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.sqrt

data class IndexedCodeChunk(
    val chunkId: String,
    val projectId: String,
    val filePath: String,
    val startLine: Int,
    val endLine: Int,
    val content: String,
    val embedding: FloatArray
)

/**
 * Generates deterministic, normalized N-gram/token feature embeddings on-device when a neural GGUF
 * embedding model is not loaded, enabling immediate offline cosine similarity + BM25 hybrid ranking.
 */
@Singleton
class DeterministicCodeEmbedder @Inject constructor() {
    companion object {
        const val EMBEDDING_DIM = 64
    }

    fun embedText(text: String): FloatArray {
        val vec = FloatArray(EMBEDDING_DIM)
        val tokens = text.lowercase().split(Regex("\\W+")).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return vec
        for ((idx, tok) in tokens.withIndex()) {
            val h1 = (tok.hashCode() and 0x7FFFFFFF) % EMBEDDING_DIM
            val h2 = ((tok.hashCode() * 31 + idx) and 0x7FFFFFFF) % EMBEDDING_DIM
            vec[h1] += 1.0f
            vec[h2] += 0.5f
        }
        var norm = 0.0f
        for (v in vec) norm += v * v
        val inv = if (norm > 0.0f) (1.0f / sqrt(norm)) else 1.0f
        for (i in vec.indices) vec[i] *= inv
        return vec
    }
}

/**
 * Hybrid BM25 keyword + Cosine Semantic Vector Ranker with strict project isolation.
 */
@Singleton
class HybridSemanticSearchEngine @Inject constructor(
    private val embedder: DeterministicCodeEmbedder = DeterministicCodeEmbedder()
) {
    fun cosineSimilarity(a: FloatArray, b: FloatArray): Double {
        require(a.size == b.size && a.isNotEmpty()) { "Embedding dimensions must match" }
        var dot = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        return if (denom == 0.0) 0.0 else dot / denom
    }

    fun chunkSourceFile(
        projectId: String,
        filePath: String,
        content: String,
        windowLines: Int = 40,
        overlapLines: Int = 10
    ): List<IndexedCodeChunk> {
        val lines = content.lines()
        if (lines.isEmpty()) return emptyList()
        val chunks = mutableListOf<IndexedCodeChunk>()
        val step = (windowLines - overlapLines).coerceAtLeast(1)
        var start = 0
        var seq = 1
        while (start < lines.size) {
            val end = (start + windowLines).coerceAtMost(lines.size)
            val slice = lines.subList(start, end).joinToString("\n")
            chunks.add(
                IndexedCodeChunk(
                    chunkId = "$projectId:$filePath:${seq++}",
                    projectId = projectId,
                    filePath = filePath,
                    startLine = start + 1,
                    endLine = end,
                    content = slice,
                    embedding = embedder.embedText(slice)
                )
            )
            if (end == lines.size) break
            start += step
        }
        return chunks
    }

    fun rankChunks(
        projectId: String,
        query: String,
        queryEmbedding: FloatArray = embedder.embedText(query),
        chunks: List<IndexedCodeChunk>,
        topK: Int = 5
    ): List<IndexedCodeChunk> {
        val terms = query.lowercase().split(Regex("\\W+")).filter { it.length > 2 }
        return chunks
            .filter { it.projectId == projectId }
            .map { chunk ->
                val semanticScore = cosineSimilarity(queryEmbedding, chunk.embedding)
                val lowerContent = chunk.content.lowercase()
                val keywordHits = terms.count { lowerContent.contains(it) }
                val lexicalScore = if (terms.isEmpty()) 0.0 else keywordHits.toDouble() / terms.size
                val combinedScore = 0.65 * semanticScore + 0.35 * lexicalScore
                chunk to combinedScore
            }
            .sortedByDescending { it.second }
            .take(topK)
            .map { it.first }
    }
}
