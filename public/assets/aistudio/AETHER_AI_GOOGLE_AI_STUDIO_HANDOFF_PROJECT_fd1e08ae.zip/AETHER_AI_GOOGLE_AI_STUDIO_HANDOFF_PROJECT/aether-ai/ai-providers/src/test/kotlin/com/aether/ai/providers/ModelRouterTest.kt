package com.aether.ai.providers

import com.aether.core.common.AetherResult
import com.aether.observability.HardwareCapabilityAssessor
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelRouterTest {
    private val router = ModelRouter()
    private val assessor = HardwareCapabilityAssessor()

    @Test
    fun `never silently downgrades tier 3 architecture task to tier 1 model`() {
        val hw = assessor.assessRuntimeHardware(
            buildModel = "SM-S908U",
            socHardware = "sm8450",
            gpuRenderer = "Adreno (TM) 730",
            totalRamMb = 12288,
            availableRamMb = 6800,
            availableStorageMb = 45000,
            androidSdkInt = 35,
            cpuFlags = setOf("asimddp", "i8mm", "fphp"),
            thermalStatusCode = 0,
            batteryPercent = 85,
            isCharging = true
        )
        val weakLocalOnly = listOf(
            ModelDescriptor(
                providerId = "local",
                vendor = ProviderVendor.LOCAL_RUNTIME,
                modelId = "qwen2.5-coder-1.5b-q4",
                displayName = "Qwen 2.5 Coder 1.5B",
                contextWindow = 8192,
                maxOutputTokens = 2048,
                supportsTools = true,
                supportsVision = false,
                supportsStreaming = true,
                capabilityTier = 1,
                inputCostPerMillionUsd = 0.0,
                outputCostPerMillionUsd = 0.0,
                isLocal = true
            )
        )
        val res = router.selectModel(
            taskComplexity = TaskComplexity.COMPLEX_ARCHITECTURE_OR_SECURITY,
            requiresTools = true,
            availableModels = weakLocalOnly,
            isNetworkOnline = false,
            preferOffline = true,
            maxCostPerMillionUsd = null,
            hardwareProfile = hw
        )
        assertTrue(res is AetherResult.Error)
        assertEquals("MODEL_DOWNGRADE_BLOCKED", (res as AetherResult.Error).code)
    }
}
