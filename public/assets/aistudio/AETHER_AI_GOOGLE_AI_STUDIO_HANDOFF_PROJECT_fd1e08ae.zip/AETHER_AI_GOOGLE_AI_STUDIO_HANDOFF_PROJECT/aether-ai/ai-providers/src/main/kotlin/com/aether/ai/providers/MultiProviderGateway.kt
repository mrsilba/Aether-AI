package com.aether.ai.providers

import com.aether.core.common.AetherResult
import com.aether.core.network.NetworkSecurityValidator
import com.aether.core.network.SseStreamParser
import com.aether.observability.HardwareProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

enum class ProviderVendor {
    OPENAI,
    ANTHROPIC_CLAUDE,
    GOOGLE_GEMINI,
    DEEPSEEK,
    OPENROUTER,
    CUSTOM_OPENAI_COMPATIBLE,
    LOCAL_RUNTIME
}

enum class TaskComplexity {
    TRIVIAL_AUTOCOMPLETE,
    STANDARD_CODING,
    COMPLEX_ARCHITECTURE_OR_SECURITY,
    EMBEDDING_INDEXING
}

data class ModelDescriptor(
    val providerId: String,
    val vendor: ProviderVendor,
    val modelId: String,
    val displayName: String,
    val contextWindow: Int,
    val maxOutputTokens: Int,
    val supportsTools: Boolean,
    val supportsVision: Boolean,
    val supportsStreaming: Boolean,
    val capabilityTier: Int,
    val inputCostPerMillionUsd: Double,
    val outputCostPerMillionUsd: Double,
    val isLocal: Boolean
)

data class ChatMessage(
    val role: String,
    val content: String,
    val toolCallId: String? = null
)

data class ToolDefinition(
    val name: String,
    val description: String,
    val jsonSchema: String
)

data class CompletionRequest(
    val model: ModelDescriptor,
    val messages: List<ChatMessage>,
    val tools: List<ToolDefinition> = emptyList(),
    val temperature: Double = 0.2,
    val maxTokens: Int = 4096,
    val stream: Boolean = true
)

data class StreamDelta(
    val textDelta: String = "",
    val toolName: String? = null,
    val toolArgumentsJson: String? = null,
    val isDone: Boolean = false,
    val error: String? = null
)

private fun escapeJson(value: String): String =
    value.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")

interface ProviderProtocolAdapter {
    val vendor: ProviderVendor
    fun buildEndpointUrl(baseUrl: String, modelId: String, stream: Boolean): String
    fun buildHeaders(apiKey: String, customHeaders: Map<String, String> = emptyMap()): Map<String, String>
    fun serializePayload(request: CompletionRequest): String
}

class OpenAiCompatibleAdapter(
    override val vendor: ProviderVendor = ProviderVendor.OPENAI
) : ProviderProtocolAdapter {
    override fun buildEndpointUrl(baseUrl: String, modelId: String, stream: Boolean): String =
        "${baseUrl.trimEnd('/')}/chat/completions"

    override fun buildHeaders(apiKey: String, customHeaders: Map<String, String>): Map<String, String> =
        buildMap {
            put("Authorization", "Bearer $apiKey")
            put("Content-Type", "application/json")
            putAll(customHeaders)
        }

    override fun serializePayload(request: CompletionRequest): String {
        val msgsJson = request.messages.joinToString(",") { msg ->
            """{"role":"${escapeJson(msg.role)}","content":"${escapeJson(msg.content)}"}"""
        }
        val toolsPart = if (request.tools.isNotEmpty()) {
            val toolsJson = request.tools.joinToString(",") { t ->
                """{"type":"function","function":{"name":"${escapeJson(t.name)}","description":"${escapeJson(t.description)}","parameters":${t.jsonSchema}}}"""
            }
            ""","tools":[$toolsJson]"""
        } else ""
        return """{"model":"${escapeJson(request.model.modelId)}","messages":[$msgsJson],"stream":${request.stream},"temperature":${request.temperature},"max_tokens":${request.maxTokens}$toolsPart}"""
    }
}

class AnthropicClaudeAdapter : ProviderProtocolAdapter {
    override val vendor: ProviderVendor = ProviderVendor.ANTHROPIC_CLAUDE

    override fun buildEndpointUrl(baseUrl: String, modelId: String, stream: Boolean): String =
        "${baseUrl.trimEnd('/')}/v1/messages"

    override fun buildHeaders(apiKey: String, customHeaders: Map<String, String>): Map<String, String> =
        buildMap {
            put("x-api-key", apiKey)
            put("anthropic-version", "2023-06-01")
            put("Content-Type", "application/json")
            putAll(customHeaders)
        }

    override fun serializePayload(request: CompletionRequest): String {
        val systemMsg = request.messages.firstOrNull { it.role == "system" }?.content
        val systemPart = if (!systemMsg.isNullOrBlank()) {
            ",\"system\":\"${escapeJson(systemMsg)}\""
        } else ""
        val msgsJson = request.messages.filter { it.role != "system" }.joinToString(",") { msg ->
            """{"role":"${escapeJson(msg.role)}","content":"${escapeJson(msg.content)}"}"""
        }
        return """{"model":"${escapeJson(request.model.modelId)}","messages":[$msgsJson],"max_tokens":${request.maxTokens},"stream":${request.stream}$systemPart}"""
    }
}

class GoogleGeminiAdapter : ProviderProtocolAdapter {
    override val vendor: ProviderVendor = ProviderVendor.GOOGLE_GEMINI

    override fun buildEndpointUrl(baseUrl: String, modelId: String, stream: Boolean): String {
        val method = if (stream) "streamGenerateContent?alt=sse" else "generateContent"
        return "${baseUrl.trimEnd('/')}/v1beta/models/$modelId:$method"
    }

    override fun buildHeaders(apiKey: String, customHeaders: Map<String, String>): Map<String, String> =
        buildMap {
            put("x-goog-api-key", apiKey)
            put("Content-Type", "application/json")
            putAll(customHeaders)
        }

    override fun serializePayload(request: CompletionRequest): String {
        val contentsJson = request.messages.joinToString(",") { msg ->
            val geminiRole = if (msg.role == "assistant") "model" else "user"
            """{"role":"$geminiRole","parts":[{"text":"${escapeJson(msg.content)}"}]}"""
        }
        return """{"contents":[$contentsJson],"generationConfig":{"temperature":${request.temperature},"maxOutputTokens":${request.maxTokens}}}"""
    }
}

/**
 * Extracts structured text deltas and tool calls from OpenAI, Anthropic, and Gemini SSE payloads.
 */
@Singleton
class ProviderDeltaParser @Inject constructor() {
    private val openAiContentRegex = Regex("\"content\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")
    private val anthropicTextRegex = Regex("\"type\"\\s*:\\s*\"text_delta\"[^}]*\"text\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")
    private val geminiTextRegex = Regex("\"text\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")

    fun parseEvent(vendor: ProviderVendor, event: SseStreamParser.SseEvent): StreamDelta {
        if (event.eventType == "done" || event.data == "[DONE]") {
            return StreamDelta(isDone = true)
        }
        if (event.eventType == "error") {
            return StreamDelta(error = event.data)
        }
        val match = when (vendor) {
            ProviderVendor.ANTHROPIC_CLAUDE -> anthropicTextRegex.find(event.data) ?: openAiContentRegex.find(event.data)
            ProviderVendor.GOOGLE_GEMINI -> geminiTextRegex.find(event.data)
            else -> openAiContentRegex.find(event.data)
        }
        val unescaped = match?.groupValues?.get(1)
            ?.replace("\\n", "\n")
            ?.replace("\\\"", "\"")
            ?.replace("\\\\", "\\")
            .orEmpty()
        return StreamDelta(textDelta = unescaped)
    }
}

/**
 * Executes live HTTP POST and SSE streaming completions using OkHttpClient with SSRF validation.
 */
@Singleton
class CloudAiExecutionClient @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient(),
    private val networkValidator: NetworkSecurityValidator = NetworkSecurityValidator()
) {
    fun streamCompletion(
        adapter: ProviderProtocolAdapter,
        baseUrl: String,
        apiKey: String,
        request: CompletionRequest
    ): Flow<SseStreamParser.SseEvent> = flow {
        val url = adapter.buildEndpointUrl(baseUrl, request.model.modelId, stream = true)
        when (val check = networkValidator.validateExternalEndpoint(url)) {
            is AetherResult.Error -> {
                emit(SseStreamParser.SseEvent("error", "${check.code}: ${check.message}"))
                return@flow
            }
            is AetherResult.Success -> Unit
        }
        val headers = adapter.buildHeaders(apiKey)
        val payload = adapter.serializePayload(request)
        val reqBuilder = Request.Builder()
            .url(url)
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
        headers.forEach { (k, v) -> reqBuilder.header(k, v) }

        httpClient.newCall(reqBuilder.build()).execute().use { response ->
            if (!response.isSuccessful) {
                emit(SseStreamParser.SseEvent("error", "HTTP ${response.code}: ${response.message}"))
                return@use
            }
            val reader = response.body?.charStream()?.buffered() ?: return@use
            reader.useLines { lineSeq ->
                for (evt in SseStreamParser.parseLines(lineSeq)) {
                    emit(evt)
                }
            }
        }
    }.flowOn(Dispatchers.IO)
}

@Singleton
class ModelRouter @Inject constructor() {
    fun selectModel(
        taskComplexity: TaskComplexity,
        requiresTools: Boolean,
        availableModels: List<ModelDescriptor>,
        isNetworkOnline: Boolean,
        preferOffline: Boolean,
        maxCostPerMillionUsd: Double?,
        hardwareProfile: HardwareProfile
    ): AetherResult<ModelDescriptor> {
        val minRequiredTier = when (taskComplexity) {
            TaskComplexity.COMPLEX_ARCHITECTURE_OR_SECURITY -> 3
            TaskComplexity.STANDARD_CODING -> 2
            TaskComplexity.TRIVIAL_AUTOCOMPLETE, TaskComplexity.EMBEDDING_INDEXING -> 1
        }

        val candidates = availableModels.filter { model ->
            val networkOk = if (model.isLocal) {
                hardwareProfile.maxSafeLocalModelRamMb >= 1200
            } else {
                isNetworkOnline && !preferOffline
            }
            val toolsOk = !requiresTools || model.supportsTools
            val costOk = maxCostPerMillionUsd == null || model.outputCostPerMillionUsd <= maxCostPerMillionUsd
            networkOk && toolsOk && costOk
        }

        val tierMatched = candidates.filter { it.capabilityTier >= minRequiredTier }
        if (tierMatched.isEmpty()) {
            val hasWeakerCandidate = candidates.any { it.capabilityTier < minRequiredTier }
            return if (hasWeakerCandidate) {
                AetherResult.Error(
                    code = "MODEL_DOWNGRADE_BLOCKED",
                    message = "Task requires capability tier $minRequiredTier ($taskComplexity), but only weaker tier models are currently reachable. Explicit user confirmation is required before downgrading.",
                    recoverable = true
                )
            } else {
                AetherResult.Error(
                    code = "NO_COMPATIBLE_MODEL",
                    message = "No compatible cloud or local model is available for $taskComplexity (online=$isNetworkOnline).",
                    recoverable = true
                )
            }
        }

        val selected = tierMatched.sortedWith(
            compareByDescending<ModelDescriptor> { if (preferOffline) it.isLocal else !it.isLocal }
                .thenByDescending { it.capabilityTier }
                .thenBy { it.outputCostPerMillionUsd }
        ).first()

        return AetherResult.Success(selected)
    }
}
