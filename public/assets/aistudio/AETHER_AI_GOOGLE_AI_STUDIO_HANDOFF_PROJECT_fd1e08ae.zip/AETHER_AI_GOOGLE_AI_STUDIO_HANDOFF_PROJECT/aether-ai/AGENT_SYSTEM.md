# AETHER AI — Autonomous Multi-Agent System

## The 12 Core Engineering Agents

| # | Agent Role | Mutates Files? | Allowed Tool Scope | Primary Responsibility |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `ARCHITECT` | No | `read_file`, `list_dir`, `search_repo`, `analyze_dependencies`, `memory_read` | Modular boundaries & dependency validation |
| 2 | `SENIOR_DEVELOPER` | **Yes** | `read_file`, `write_file`, `apply_patch`, `search_repo`, `format_code` | Production code implementation |
| 3 | `CODE_REVIEWER` | No | `git_diff`, `read_file`, `search_repo` | Defect, nullability, and concurrency review |
| 4 | `DEBUGGER` | No | `read_file`, `search_repo`, `inspect_build_logs`, `run_unit_test` | Root-cause stack trace & logcat analysis |
| 5 | `SECURITY_AUDITOR` | No | `read_file`, `search_repo`, `scan_secrets`, `inspect_manifest` | Vulnerability & secret scanning |
| 6 | `QA_ENGINEER` | **Yes** | `read_file`, `write_test_file`, `run_unit_test`, `inspect_coverage` | Automated unit & edge-case test authoring |
| 7 | `UI_UX_ANALYST` | No | `read_file`, `inspect_compose_tree`, `capture_preview` | WCAG contrast, RTL/LTR layout, adaptive UI |
| 8 | `DATABASE_ENGINEER` | No | `read_file`, `inspect_schema`, `analyze_query_plan` | Room schema, indices, and migration audits |
| 9 | `DEVOPS_ENGINEER` | **Yes** | `read_file`, `write_file`, `run_build_check` | Gradle version catalogs & CI configuration |
| 10 | `RESEARCHER` | No | `memory_search`, `mcp_read_resource`, `search_repo` | Documentation & MCP grounding |
| 11 | `DOCUMENTATION_WRITER` | **Yes** | `read_file`, `write_doc_file`, `git_log` | Architecture docs & changelog sync |
| 12 | `PROJECT_MANAGER` | No | `read_file`, `memory_read`, `memory_write`, `checkpoint_status` | DAG task decomposition & milestone tracking |

## Supervisor Orchestration & Checkpointing

- `SupervisorOrchestrator.buildParallelWaves()` topologically sorts subtasks into dependency-free waves that execute concurrently via Kotlin Coroutines, rejecting cyclic graphs (`DAG_CYCLE_DETECTED`).
- `detectConflictingOutputs()` flags any two agents attempting concurrent edits to the same file in the same wave.
- `verifyObjectiveCompletion()` refuses to mark any objective complete unless every subtask with `requiresVerification = true` has passed validation (`VALIDATION_FAILED`).
