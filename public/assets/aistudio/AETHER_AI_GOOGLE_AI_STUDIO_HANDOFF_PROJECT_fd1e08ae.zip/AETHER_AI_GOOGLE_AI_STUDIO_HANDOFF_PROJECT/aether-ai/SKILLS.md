# AETHER AI — Extensible Skills & Model Context Protocol (MCP) Ecosystem

## Skill Manifest Schema (`skill.json`)

Every installable skill (imported from a Git repository or local directory) defines:
- `name`, `version`, `description`, `instructions`
- `inputSchemaJson` and `outputSchemaJson` (JSON Schema Draft 2020-12)
- `requiredTools` and `requiredPermissions`
- `maxExecutionTimeMs`

## Untrusted Input & MCP Security Enforcement

1. **Skill Validation (`SkillManager.validateAndSanitizeSkill`)**: Rejects skills containing prompt-injection patterns (`ignore previous instructions`, `override security policy`, `disable secret scanner`, `exfiltrate api key`).
2. **MCP Client (`McpClientRuntime`)**: Implements [Model Context Protocol (MCP)](https://modelcontextprotocol.io/specification/2026-07-28) over JSON-RPC 2.0 (`initialize`, `tools/list`, `tools/call`, `resources/read`).
3. **Tool Allowlist & Secret Redaction**: Outgoing `tools/call` arguments are scanned by `SecretScanner` to block accidental secret exfiltration (`MCP_SECRET_EXFILTRATION_BLOCKED`), and incoming responses are wrapped in `<untrusted_mcp_output>` tags.
