package com.aether.core.network

import com.aether.core.common.AetherResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkSecurityValidatorTest {
    private val validator = NetworkSecurityValidator()

    @Test
    fun `blocks cloud metadata and loopback SSRF endpoints`() {
        val metaRes = validator.validateExternalEndpoint("http://169.254.169.254/latest/meta-data/")
        assertTrue(metaRes is AetherResult.Error)
        assertEquals("SSRF_METADATA_ENDPOINT_BLOCKED", (metaRes as AetherResult.Error).code)

        val loopRes = validator.validateExternalEndpoint("https://127.0.0.1:8080/mcp")
        assertTrue(loopRes is AetherResult.Error)
        assertEquals("SSRF_PRIVATE_NETWORK_BLOCKED", (loopRes as AetherResult.Error).code)

        val rfc1918Res = validator.validateExternalEndpoint("https://192.168.1.50/rpc")
        assertTrue(rfc1918Res is AetherResult.Error)
        assertEquals("SSRF_PRIVATE_NETWORK_BLOCKED", (rfc1918Res as AetherResult.Error).code)
    }

    @Test
    fun `blocks cleartext HTTP and permits valid external HTTPS endpoints`() {
        val httpRes = validator.validateExternalEndpoint("http://api.github.com/user")
        assertTrue(httpRes is AetherResult.Error)
        assertEquals("INSECURE_TRANSPORT_SCHEME_BLOCKED", (httpRes as AetherResult.Error).code)

        val httpsRes = validator.validateExternalEndpoint("https://api.github.com/user")
        assertTrue(httpsRes is AetherResult.Success)
    }
}
