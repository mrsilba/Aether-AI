package com.aether.core.network

/**
 * Parses Server-Sent Events (SSE) lines from OpenAI, Anthropic, Gemini, and OpenRouter streams.
 */
object SseStreamParser {
    data class SseEvent(val eventType: String?, val data: String)

    fun parseLines(lines: Sequence<String>): Sequence<SseEvent> = sequence {
        var currentEvent: String? = null
        val dataBuffer = StringBuilder()

        for (rawLine in lines) {
            val line = rawLine.trimEnd('\r')
            when {
                line.isEmpty() -> {
                    if (dataBuffer.isNotEmpty()) {
                        yield(SseEvent(currentEvent, dataBuffer.toString().trimEnd('\n')))
                        dataBuffer.clear()
                        currentEvent = null
                    }
                }
                line.startsWith("event:") -> {
                    currentEvent = line.removePrefix("event:").trim()
                }
                line.startsWith("data:") -> {
                    val payload = line.removePrefix("data:").trimStart()
                    if (payload == "[DONE]") {
                        yield(SseEvent("done", "[DONE]"))
                    } else {
                        dataBuffer.append(payload).append('\n')
                    }
                }
            }
        }
        if (dataBuffer.isNotEmpty()) {
            yield(SseEvent(currentEvent, dataBuffer.toString().trimEnd('\n')))
        }
    }
}
