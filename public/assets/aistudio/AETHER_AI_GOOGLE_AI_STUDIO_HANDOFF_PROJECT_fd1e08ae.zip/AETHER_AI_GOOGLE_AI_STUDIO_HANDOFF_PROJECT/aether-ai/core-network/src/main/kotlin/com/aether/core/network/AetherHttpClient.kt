package com.aether.core.network

import com.aether.core.common.AetherResult
import okhttp3.OkHttpClient
import java.net.URI
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

object AetherHttpClient {
    fun createConfiguredClient(timeoutMs: Long = 30_000L): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .readTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .writeTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
    }
}

/**
 * Enforces HTTPS transport and blocks Server-Side Request Forgery (SSRF) against loopback,
 * link-local cloud metadata (169.254.169.254), and RFC1918 private networks unless explicitly approved.
 */
@Singleton
class NetworkSecurityValidator @Inject constructor() {
    private val blockedHosts = setOf(
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
        "::1",
        "[::1]",
        "169.254.169.254",
        "metadata.google.internal"
    )

    fun validateExternalEndpoint(
        url: String,
        allowExplicitLocalDevHttp: Boolean = false
    ): AetherResult<URI> {
        val uri = try {
            URI(url.trim())
        } catch (e: Exception) {
            return AetherResult.Error("INVALID_ENDPOINT_URI", "Malformed URL: $url", e)
        }
        val scheme = uri.scheme?.lowercase().orEmpty()
        val host = uri.host?.lowercase().orEmpty()
        if (host.isEmpty()) {
            return AetherResult.Error("INVALID_ENDPOINT_HOST", "URL is missing a valid host: $url")
        }
        if (host == "169.254.169.254" || host == "metadata.google.internal" || host.startsWith("169.254.")) {
            return AetherResult.Error(
                "SSRF_METADATA_ENDPOINT_BLOCKED",
                "Access to link-local/cloud metadata address '$host' is strictly prohibited."
            )
        }
        val isLoopbackOrPrivate = host in blockedHosts ||
            host.startsWith("127.") ||
            host.startsWith("10.") ||
            host.startsWith("192.168.") ||
            Regex("^172\\.(1[6-9]|2[0-9]|3[0-1])\\..*").matches(host)

        if (isLoopbackOrPrivate && !allowExplicitLocalDevHttp) {
            return AetherResult.Error(
                "SSRF_PRIVATE_NETWORK_BLOCKED",
                "Endpoint '$host' resolves to a loopback or RFC1918 private network address. Explicit user approval is required."
            )
        }
        if (scheme != "https" && !(allowExplicitLocalDevHttp && scheme == "http")) {
            return AetherResult.Error(
                "INSECURE_TRANSPORT_SCHEME_BLOCKED",
                "Endpoint '$url' must use HTTPS (found scheme '$scheme')."
            )
        }
        return AetherResult.Success(uri)
    }
}
