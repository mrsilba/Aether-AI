# AETHER AI — System Architecture & Feasibility Assessment

## 1. Feasibility Assessment & Target Hardware Constraints (Samsung Galaxy S22 Ultra)

AETHER AI targets the **Samsung Galaxy S22 Ultra** across both regional SoC variants without assuming fixed hardware:
- **Snapdragon 8 Gen 1 (`SM8450` / `SM-S908U`, `SM-S908W`, `SM-S908E`, `SM-S908N`, `SM-S9080`)**: 1x Cortex-X2 @ 3.00 GHz + 3x Cortex-A710 @ 2.50 GHz + 4x Cortex-A510 @ 1.80 GHz, Qualcomm Adreno 730 GPU (OpenCL 2.0 / Vulkan 1.1), Hexagon Tensor Processor.
- **Exynos 2200 (`S5E9925` / `SM-S908B`)**: 1x Cortex-X2 @ 2.80 GHz + 3x Cortex-A710 @ 2.52 GHz + 4x Cortex-A510 @ 1.82 GHz, Samsung Xclipse 920 GPU (AMD RDNA2 architecture with Vulkan 1.3 hardware acceleration).
- **RAM Tiers**: 8 GB LPDDR5 (128 GB storage tier) and 12 GB LPDDR5 (256 GB / 512 GB / 1 TB tiers).
- **Thermal Envelope**: Sustained 5W–6W passive dissipation before [PowerManager.OnThermalStatusChangedListener](https://developer.android.com/reference/android/os/PowerManager.OnThermalStatusChangedListener) reports `THERMAL_STATUS_MODERATE` (2) or `THERMAL_STATUS_SEVERE` (3).

## 2. On-Device vs. Optional External Worker Execution Matrix

| Capability | Execution Location | Technical Rationale |
| :--- | :--- | :--- |
| Multi-provider Cloud AI streaming, routing, cost tracking | **100% On-Device** | Direct HTTPS/SSE via OkHttp with hardware-backed Keystore credentials. |
| Local LLM Inference (1B–3B Q4_K_M on 8 GB RAM; up to 7B–8B Q4_K_M on 12 GB RAM) | **100% On-Device** | [LiteRT-LM](https://developers.google.com/edge/litert-lm/android) and [llama.cpp NDK](https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md) (`arm64-v8a` `dotprod`/`i8mm`/Vulkan). |
| Local Embeddings & Hybrid BM25 + Vector Search | **100% On-Device** | Quantized embedding models (e.g., `EmbeddingGemma` / `nomic-embed-text-v1.5` Q4) + SQLite/Room vector blobs. |
| Multi-tab Code Editing, AST Highlighting, Myers Diff, Git (`init`/`clone`/`commit`/`branch`/`diff`/`merge`/`push`) | **100% On-Device** | [Sora Editor](https://github.com/Rosemoe/sora-editor) + pure-Java [Eclipse JGit](https://github.com/eclipse-jgit/jgit). |
| 13-Step Repository Static Audit & Secret Scanning | **100% On-Device** | Kotlin AST/regex analyzers, manifest inspectors, and dependency graph evaluators. |
| HTML/CSS/JS Live Web Preview & APK Installation | **100% On-Device** | Embedded WebView with console bridge and Android `PackageInstaller` intent. |
| Full Multi-Module Android Gradle / AAPT2 / NDK Compilation & Instrumentation Tests | **Optional External Build Worker** (or connected host daemon) | Android's SELinux `W^X` policy and RAM ceiling restrict full multi-daemon Gradle + Android SDK builds inside an unrooted phone sandbox; AETHER AI runs fast syntax/lint/diff checks locally and dispatches heavy Gradle builds to a paired Remote Build Worker or GitHub Actions runner. |

## 3. Dependency & License Matrix

| Dependency | Artifact | Version | License | Compatibility |
| :--- | :--- | :--- | :--- | :--- |
| Jetpack Compose BOM | `androidx.compose:compose-bom` | `2025.02.00` | Apache-2.0 | Official Android UI toolkit |
| Compose Material 3 Adaptive | `androidx.compose.material3.adaptive:adaptive` | `1.1.0` | Apache-2.0 | Split-screen & foldable/DEX support |
| AndroidX Room | `androidx.room:room-ktx` | `2.6.1` | Apache-2.0 | SQLite ORM with Flow/Coroutines |
| SQLCipher for Android | `net.zetetic:android-database-sqlcipher` | `4.5.4` | BSD-style | Full database encryption |
| AndroidX WorkManager | `androidx.work:work-runtime-ktx` | `2.10.0` | Apache-2.0 | Doze-compliant background execution |
| Google AI Edge LiteRT-LM | `com.google.ai.edge:litert-lm` | `0.6.0` | Apache-2.0 | Official GPU/NPU local LLM runtime |
| llama.cpp (NDK JNI) | Native C++17 submodule | `b4800+` | MIT | GGUF local model inference |
| Sora Editor | `io.github.rosemoe.sora-editor:editor` | `0.23.4` | LGPL-2.1 | Dynamically linked Android code editor |
| Eclipse JGit | `org.eclipse.jgit:org.eclipse.jgit` | `6.10.0` | EDL-1.0 (BSD-3) | Pure Java Git implementation |
| OkHttp & OkHttp-SSE | `com.squareup.okhttp3:okhttp-sse` | `4.12.0` | Apache-2.0 | HTTP/2 + Server-Sent Events |
