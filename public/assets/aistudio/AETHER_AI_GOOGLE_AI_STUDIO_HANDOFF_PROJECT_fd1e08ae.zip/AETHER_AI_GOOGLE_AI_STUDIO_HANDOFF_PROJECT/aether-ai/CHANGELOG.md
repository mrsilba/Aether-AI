# AETHER AI — Changelog

## [1.0.0] — 2026-11-02

### Added
- **Phase 0–1 (Foundation & Hardware Profiling)**: Initialized 24-module Clean Architecture Gradle repository, `AndroidKeystoreVault` (`AES/GCM/NoPadding`), `AetherDatabase` (Room + SQLCipher), `HardwareCapabilityAssessor` for Samsung Galaxy S22 Ultra (`SM-S908U` Snapdragon 8 Gen 1 & `SM-S908B` Exynos 2200), and bilingual English LTR / Persian RTL Material 3 Dark UI.
- **Phase 2 (Multi-Provider Cloud AI)**: Implemented `OpenAiCompatibleAdapter`, `AnthropicClaudeAdapter`, `GoogleGeminiAdapter`, `SseStreamParser`, and `ModelRouter` with anti-downgrade protection.
- **Phase 3 (Local AI Runtime)**: Implemented `LocalModelLifecycleManager`, native C++17 `aether_llama_jni.cpp` GGUF inspector & KV-cache calculator, LiteRT-LM integration, and `ResumableModelDownloader` with 1.5 GB free-space reserve and SHA-256 verification.
- **Phase 4 (Autonomous Agents, Skills & MCP)**: Implemented 12 specialized agents in `CoreAgentsRegistry`, `SupervisorOrchestrator` parallel wave planner, `SkillManager` prompt-injection sanitizer, and `McpClientRuntime` JSON-RPC 2.0 client.
- **Phase 5–7 (Workspace, Audit/Repair, Build & Preview)**: Implemented `CodeEditorController` (14 languages + diff/undo), `GitConflictInspector`, 13-step `ProjectAuditAndRepairEngine` with 10-step rollback workflow and anti-test-tampering enforcement, `CompilerDiagnosticParser`, and explicit preview fidelity badges.
- **Phase 8–10 (Cloud Hub, Memory, Semantic Search, Hardening)**: Implemented `VerifiedDriveBackupService`, `ProjectMemoryIsolationEngine`, `HybridSemanticSearchEngine`, `EmergencyStopController`, and the 13-scenario automated test suite.
