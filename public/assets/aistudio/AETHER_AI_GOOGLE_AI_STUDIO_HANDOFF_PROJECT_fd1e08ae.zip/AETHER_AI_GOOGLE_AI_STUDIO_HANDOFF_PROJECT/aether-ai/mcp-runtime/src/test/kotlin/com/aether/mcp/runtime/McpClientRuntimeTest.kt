package com.aether.mcp.runtime

import com.aether.core.common.AetherResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class McpClientRuntimeTest {
    private val runtime = McpClientRuntime()
    private val server = McpServerConfig(
        serverId = "test-mcp",
        displayName = "Test MCP",
        transportType = "HTTP_SSE",
        endpointOrCommand = "https://mcp.example.com/rpc",
        allowedTools = setOf("search_docs")
    )

    @Test
    fun `blocks unpermitted MCP tools and outgoing API key leaks`() {
        val deniedTool = runtime.buildToolCallRequest(1, server, "delete_repo", "{}")
        assertTrue(deniedTool is AetherResult.Error)
        assertEquals("MCP_TOOL_PERMISSION_DENIED", (deniedTool as AetherResult.Error).code)

        val leakedKey = runtime.buildToolCallRequest(
            2,
            server,
            "search_docs",
            """{"query":"sk-proj-AbCdEfGhIjKlMnOpQrStUvWxYz123456"}"""
        )
        assertTrue(leakedKey is AetherResult.Error)
        assertEquals("MCP_SECRET_EXFILTRATION_BLOCKED", (leakedKey as AetherResult.Error).code)
    }

    @Test
    fun `validates JSON-RPC 2_0 response id and wraps untrusted output`() {
        val validResp = runtime.validateJsonRpcResponse(
            7,
            """{"jsonrpc":"2.0","id":7,"result":{"content":"ok"}}"""
        )
        assertTrue(validResp is AetherResult.Success)
        assertTrue((validResp as AetherResult.Success).data.startsWith("<untrusted_mcp_output>"))

        val wrongId = runtime.validateJsonRpcResponse(
            7,
            """{"jsonrpc":"2.0","id":99,"result":{}}"""
        )
        assertTrue(wrongId is AetherResult.Error)
        assertEquals("MCP_ID_MISMATCH", (wrongId as AetherResult.Error).code)
    }
}
