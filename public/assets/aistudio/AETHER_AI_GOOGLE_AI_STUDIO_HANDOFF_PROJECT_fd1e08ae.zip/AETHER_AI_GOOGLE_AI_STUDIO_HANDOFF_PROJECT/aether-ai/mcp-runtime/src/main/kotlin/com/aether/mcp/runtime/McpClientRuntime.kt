package com.aether.mcp.runtime

import com.aether.core.common.AetherResult
import com.aether.core.security.SecretScanner
import javax.inject.Inject
import javax.inject.Singleton

data class McpServerConfig(
    val serverId: String,
    val displayName: String,
    val transportType: String, // HTTP_SSE or STDIO_LOCAL
    val endpointOrCommand: String,
    val allowedTools: Set<String>,
    val allowLocalDevHttp: Boolean = false
)

data class McpToolSchema(
    val serverId: String,
    val name: String,
    val description: String,
    val inputSchemaJson: String
)

/**
 * Model Context Protocol (MCP) JSON-RPC 2.0 Client with protocol validation,
 * tool/resource discovery, outgoing secret scanning, and untrusted response sanitization.
 */
@Singleton
class McpClientRuntime @Inject constructor() {
    fun buildInitializeRequest(requestId: Int): String =
        """{"jsonrpc":"2.0","id":$requestId,"method":"initialize","params":{"protocolVersion":"2025-03-26","capabilities":{"roots":{"listChanged":true}},"clientInfo":{"name":"AetherAI-Android","version":"1.0.0"}}}"""

    fun buildToolsListRequest(requestId: Int): String =
        """{"jsonrpc":"2.0","id":$requestId,"method":"tools/list","params":{}}"""

    fun buildResourcesListRequest(requestId: Int): String =
        """{"jsonrpc":"2.0","id":$requestId,"method":"resources/list","params":{}}"""

    fun buildResourceReadRequest(requestId: Int, resourceUri: String): AetherResult<String> {
        if (resourceUri.contains("..") || resourceUri.startsWith("file:///etc") || resourceUri.startsWith("file:///proc")) {
            return AetherResult.Error("MCP_RESOURCE_URI_DENIED", "Forbidden MCP resource URI: $resourceUri")
        }
        return AetherResult.Success(
            """{"jsonrpc":"2.0","id":$requestId,"method":"resources/read","params":{"uri":"$resourceUri"}}"""
        )
    }

    fun buildToolCallRequest(
        requestId: Int,
        server: McpServerConfig,
        toolName: String,
        argumentsJson: String
    ): AetherResult<String> {
        if (toolName !in server.allowedTools) {
            return AetherResult.Error(
                code = "MCP_TOOL_PERMISSION_DENIED",
                message = "Tool '$toolName' is not permitted by MCP server policy for '${server.displayName}'."
            )
        }
        val leaks = SecretScanner.scanText(argumentsJson)
        if (leaks.isNotEmpty()) {
            return AetherResult.Error(
                code = "MCP_SECRET_EXFILTRATION_BLOCKED",
                message = "Blocked outgoing MCP tool call containing sensitive secret: ${leaks.first().ruleId}"
            )
        }
        return AetherResult.Success(
            """{"jsonrpc":"2.0","id":$requestId,"method":"tools/call","params":{"name":"$toolName","arguments":$argumentsJson}}"""
        )
    }

    fun validateJsonRpcResponse(expectedId: Int, rawJson: String): AetherResult<String> {
        val trimmed = rawJson.trim()
        if (!trimmed.contains("\"jsonrpc\"") || !trimmed.contains("\"2.0\"")) {
            return AetherResult.Error("MCP_INVALID_JSONRPC", "Response is missing jsonrpc 2.0 envelope.")
        }
        val idRegex = Regex("\"id\"\\s*:\\s*$expectedId\\b")
        if (!idRegex.containsMatchIn(trimmed)) {
            return AetherResult.Error("MCP_ID_MISMATCH", "JSON-RPC response id does not match expected request id $expectedId.")
        }
        if (Regex("\"error\"\\s*:\\s*\\{").containsMatchIn(trimmed)) {
            return AetherResult.Error("MCP_REMOTE_RPC_ERROR", SecretScanner.redactSecrets(trimmed))
        }
        return AetherResult.Success(sanitizeUntrustedMcpResponse(trimmed))
    }

    fun sanitizeUntrustedMcpResponse(rawResponse: String): String {
        val redacted = SecretScanner.redactSecrets(rawResponse)
        return "<untrusted_mcp_output>\n$redacted\n</untrusted_mcp_output>"
    }
}
