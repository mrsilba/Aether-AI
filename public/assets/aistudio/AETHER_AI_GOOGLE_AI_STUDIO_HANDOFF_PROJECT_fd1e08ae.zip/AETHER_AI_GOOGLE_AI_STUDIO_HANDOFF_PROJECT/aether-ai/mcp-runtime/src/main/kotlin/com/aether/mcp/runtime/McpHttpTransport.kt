package com.aether.mcp.runtime

import com.aether.core.common.AetherResult
import com.aether.core.network.NetworkSecurityValidator
import com.aether.terminal.engine.SandboxedTerminalSession
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Executes MCP JSON-RPC 2.0 calls over HTTPS with strict SSRF protection,
 * or over local sandboxed stdio processes when transportType == "STDIO_LOCAL".
 */
@Singleton
class McpHttpTransport @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient(),
    private val runtime: McpClientRuntime = McpClientRuntime(),
    private val networkValidator: NetworkSecurityValidator = NetworkSecurityValidator(),
    private val terminalSession: SandboxedTerminalSession = SandboxedTerminalSession()
) {
    fun executeRpcCall(server: McpServerConfig, jsonRpcPayload: String): AetherResult<String> = runCatching {
        when (val check = networkValidator.validateExternalEndpoint(server.endpointOrCommand, server.allowLocalDevHttp)) {
            is AetherResult.Error -> return check
            is AetherResult.Success -> Unit
        }
        val req = Request.Builder()
            .url(server.endpointOrCommand)
            .post(jsonRpcPayload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("MCP_HTTP_${resp.code}", resp.message)
            }
            val raw = resp.body?.string().orEmpty()
            runtime.sanitizeUntrustedMcpResponse(raw)
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("MCP_TRANSPORT_ERROR", it.message ?: "RPC failed", it) }
    )

    fun executeStdioRpcCall(
        server: McpServerConfig,
        workingDir: File,
        userApproved: Boolean = false
    ): AetherResult<String> {
        if (server.transportType != "STDIO_LOCAL") {
            return AetherResult.Error("MCP_INVALID_TRANSPORT", "Server '${server.serverId}' is not configured for STDIO_LOCAL.")
        }
        return when (
            val res = terminalSession.executeCommand(
                commandLine = server.endpointOrCommand,
                workingDirectory = workingDir,
                timeoutSeconds = 15L,
                explicitlyApprovedByUser = userApproved
            )
        ) {
            is AetherResult.Success -> AetherResult.Success(runtime.sanitizeUntrustedMcpResponse(res.data.stdout))
            is AetherResult.Error -> res
        }
    }
}
