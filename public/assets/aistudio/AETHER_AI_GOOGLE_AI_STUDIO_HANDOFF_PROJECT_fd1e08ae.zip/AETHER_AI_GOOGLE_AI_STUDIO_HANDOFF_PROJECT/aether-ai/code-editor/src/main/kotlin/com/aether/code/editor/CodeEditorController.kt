package com.aether.code.editor

import javax.inject.Inject
import javax.inject.Singleton

enum class SupportedLanguage(val extensions: Set<String>, val textMateScope: String) {
    KOTLIN(setOf("kt", "kts"), "source.kotlin"),
    JAVA(setOf("java"), "source.java"),
    PYTHON(setOf("py"), "source.python"),
    JAVASCRIPT(setOf("js", "mjs"), "source.js"),
    TYPESCRIPT(setOf("ts", "tsx"), "source.ts"),
    DART(setOf("dart"), "source.dart"),
    CPP(setOf("cpp", "cc", "cxx", "h", "hpp"), "source.cpp"),
    HTML(setOf("html", "htm"), "text.html.basic"),
    CSS(setOf("css"), "source.css"),
    JSON(setOf("json"), "source.json"),
    XML(setOf("xml"), "text.xml"),
    MARKDOWN(setOf("md"), "text.html.markdown"),
    SQL(setOf("sql"), "source.sql"),
    YAML(setOf("yml", "yaml"), "source.yaml");

    companion object {
        fun fromFileName(fileName: String): SupportedLanguage {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            return entries.firstOrNull { ext in it.extensions } ?: MARKDOWN
        }
    }
}

data class DiffHunk(
    val oldStartLine: Int,
    val newStartLine: Int,
    val removedLines: List<String>,
    val addedLines: List<String>
)

/**
 * Line-based diff generator and undo/redo buffer backing the Sora Editor workspace.
 */
@Singleton
class DiffAndHistoryManager @Inject constructor() {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()

    @Synchronized
    fun recordSnapshot(content: String) {
        if (undoStack.lastOrNull() != content) {
            undoStack.addLast(content)
            redoStack.clear()
        }
    }

    @Synchronized
    fun undo(current: String): String? {
        if (undoStack.isEmpty()) return null
        redoStack.addLast(current)
        return undoStack.removeLast()
    }

    @Synchronized
    fun redo(current: String): String? {
        if (redoStack.isEmpty()) return null
        undoStack.addLast(current)
        return redoStack.removeLast()
    }

    fun computeUnifiedDiff(original: String, modified: String): List<String> {
        val origLines = original.lines()
        val modLines = modified.lines()
        val diff = mutableListOf<String>()
        val maxLen = maxOf(origLines.size, modLines.size)
        for (i in 0 until maxLen) {
            val o = origLines.getOrNull(i)
            val m = modLines.getOrNull(i)
            when {
                o == m && o != null -> diff.add("  $o")
                o != null && m == null -> diff.add("- $o")
                o == null && m != null -> diff.add("+ $m")
                o != m -> {
                    if (o != null) diff.add("- $o")
                    if (m != null) diff.add("+ $m")
                }
            }
        }
        return diff
    }
}
