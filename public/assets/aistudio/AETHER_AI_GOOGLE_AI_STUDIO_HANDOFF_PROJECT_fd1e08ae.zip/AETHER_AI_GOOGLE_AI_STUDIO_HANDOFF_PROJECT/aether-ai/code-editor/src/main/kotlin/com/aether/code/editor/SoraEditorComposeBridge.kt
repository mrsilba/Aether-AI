package com.aether.code.editor

import android.content.Context
import android.graphics.Typeface
import io.github.rosemoe.sora.widget.CodeEditor

/**
 * Factory and lifecycle wrapper for embedding Rosemoe Sora CodeEditor in Android Views / Compose AndroidView.
 */
object SoraEditorComposeBridge {
    fun createConfiguredEditor(
        context: Context,
        initialText: String,
        fileName: String
    ): CodeEditor {
        return CodeEditor(context).apply {
            typefaceText = Typeface.MONOSPACE
            setTextSize(13f)
            isLineNumberEnabled = true
            setText(initialText)
        }
    }
}
    
