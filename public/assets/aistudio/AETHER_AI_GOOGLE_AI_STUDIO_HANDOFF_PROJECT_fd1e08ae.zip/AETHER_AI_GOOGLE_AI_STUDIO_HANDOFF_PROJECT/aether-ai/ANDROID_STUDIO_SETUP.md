# AETHER AI — Android Studio (Windows / macOS / Linux) Build & Setup Guide

## 1. Pre-Build Audit Fixes Applied for Android Studio Compatibility

During the post-recovery build readiness inspection, five build-breaking configuration issues were identified and fixed in the repository:
1. **Google AI Edge LiteRT-LM Maven Coordinate (`gradle/libs.versions.toml`)**: Corrected from `com.google.ai.edge:litert-lm:0.6.0` to the official Google Maven artifact `com.google.ai.edge.litertlm:litertlm-android:0.18.0`.
2. **Rosemoe Sora Editor Maven Group ID (`gradle/libs.versions.toml`)**: Corrected from `io.github.rosemoe.sora-editor:editor:0.23.4` to the official Maven Central coordinates `io.github.rosemoe:editor:0.24.5`, `io.github.rosemoe:language-textmate:0.24.5`, and `io.github.rosemoe:language-treesitter:0.24.5`.
3. **Missing `androidx.activity:activity-compose` (`app/build.gradle.kts`)**: Added `androidx.activity:activity-compose:1.9.3` required by `setContent` in `MainActivity.kt`.
4. **JVM 17 Target Consistency Across All 24 Modules**: Added `compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }` and `kotlinOptions { jvmTarget = "17" }` across all Android modules (and `JvmTarget.JVM_17` in `:core-common`) so Android Gradle Plugin `8.7.2` does not fail with JVM target mismatch (`1.8` vs `17`).
5. **JNI `jstring` / `jbyteArray` Marshaling (`aether_llama_jni.cpp`) & ProGuard/R8 Rules (`app/proguard-rules.pro`)**: Fixed JNI signatures to use `env->GetStringUTFChars` and `env->SetByteArrayRegion` when `<jni.h>` is present, and added `app/proguard-rules.pro` preserving JNI methods, Room entities, Kotlinx Serialization, JGit, and SQLCipher classes.

## 2. Required Host Workstation Toolchain Checklist (Windows 10/11, macOS, or Linux)

| Component | Required Version | Verification / Installation Location |
| :--- | :--- | :--- |
| **Android Studio** | Ladybug (`2024.2.1+`) or Meerkat (`2024.3.1+`) | Includes bundled JetBrains Runtime (JBR 17/21) |
| **JDK** | JDK 17 (`17.0.10+`) | Set in *File -> Settings -> Build, Execution, Deployment -> Build Tools -> Gradle -> Gradle JDK* |
| **Android SDK Platform** | API Level 35 (Android 15) | *SDK Manager -> SDK Platforms -> Android 15.0 (API 35)* |
| **Android SDK Build-Tools** | `35.0.0` | *SDK Manager -> SDK Tools -> Android SDK Build-Tools 35* |
| **Android NDK** | `26.1.10909125` or `27.0.12077973` | *SDK Manager -> SDK Tools -> NDK (Side by side)* |
| **CMake** | `3.22.1` | *SDK Manager -> SDK Tools -> CMake 3.22.1* |
| **Gradle Distribution** | `8.10.2` | Configured in `gradle/wrapper/gradle-wrapper.properties` |

## 3. Step-by-Step Build Instructions on Windows (PowerShell / Command Prompt)

> **Important Note on `gradle-wrapper.jar`**: Because the sandbox environment where this ZIP was generated has no internet access and no pre-installed `gradle` binary, `gradle/wrapper/gradle-wrapper.properties`, `gradlew`, and `gradlew.bat` are included, while `gradle/wrapper/gradle-wrapper.jar` is bootstrapped automatically by Android Studio on first open (or via a single `gradle wrapper` command).

### Option A: Open Directly in Android Studio on Windows
1. Extract `aether_ai_recovered_source.zip` to `C:\projects\aether-ai`.
2. Launch Android Studio and select **Open** -> `C:\projects\aether-ai`.
3. Android Studio reads `gradle/wrapper/gradle-wrapper.properties`, downloads Gradle `8.10.2` automatically, syncs all 24 modules, and configures CMake `3.22.1` for `:local-inference`.
4. Select the `:app` run configuration and click **Run** (or **Build -> Make Project**).

### Option B: Command-Line Build on Windows (PowerShell)
```powershell
cd C:\projects\aether-ai

# 1. Point to your Windows Android SDK installation
$env:ANDROID_HOME = "$env:LOCALAPPDATA\Android\Sdk"

# 2. If gradle-wrapper.jar is not yet present, bootstrap it once using local Gradle or Android Studio:
gradle wrapper --gradle-version 8.10.2

# 3. Run all JVM unit tests across the 24 modules
.\gradlew.bat testDebugUnitTest

# 4. Compile native C++17 JNI library (arm64-v8a & x86_64) and assemble Debug APK
.\gradlew.bat :app:assembleDebug

# 5. Install Debug APK onto a connected Samsung Galaxy S22 Ultra via ADB
& "$env:ANDROID_HOME\platform-tools\adb.exe" install -r app\build\outputs\apk\debug\app-debug.apk
```

## 4. Honest APK Status Statement

**No `.apk` file is included in this delivery** because the generation environment lacks the Android SDK (`aapt2`, `d8`, `kotlinc`, Android NDK cross-compiler). The repository is configured so that running `.\gradlew.bat :app:assembleDebug` on a Windows/macOS/Linux host with the Android SDK produces `app/build/outputs/apk/debug/app-debug.apk`.
    
