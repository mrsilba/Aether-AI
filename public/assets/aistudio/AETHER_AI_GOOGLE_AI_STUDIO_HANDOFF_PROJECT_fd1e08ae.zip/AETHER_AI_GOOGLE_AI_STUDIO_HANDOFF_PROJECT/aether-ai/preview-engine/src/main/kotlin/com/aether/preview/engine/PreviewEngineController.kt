package com.aether.preview.engine

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class PreviewMode(val badgeText: String, val isCompiledApplication: Boolean) {
    STATIC_MOCKUP("STATIC MOCKUP", false),
    DEVELOPMENT_WEB_PREVIEW("LIVE DEV PREVIEW", false),
    COMPILED_ANDROID_APK("RUNNING COMPILED APK", true)
}

data class PreviewSessionState(
    val mode: PreviewMode,
    val entryUrlOrPath: String,
    val consoleLogs: List<String> = emptyList(),
    val verifiedApkSha256: String? = null
)

/**
 * Manages WebView live HTML/JS previews and Android APK PackageInstaller intents while
 * strictly distinguishing static mockups, development previews, and compiled APKs.
 */
@Singleton
class PreviewEngineController @Inject constructor() {
    fun createWebPreviewSession(htmlFile: File): AetherResult<PreviewSessionState> {
        if (!htmlFile.exists()) {
            return AetherResult.Error("PREVIEW_FILE_NOT_FOUND", "HTML preview file does not exist: ${htmlFile.path}")
        }
        return AetherResult.Success(
            PreviewSessionState(
                mode = PreviewMode.DEVELOPMENT_WEB_PREVIEW,
                entryUrlOrPath = "file://${htmlFile.absolutePath}"
            )
        )
    }

    fun createCompiledApkSession(apkFile: File): AetherResult<PreviewSessionState> {
        if (!apkFile.exists() || !apkFile.name.endsWith(".apk")) {
            return AetherResult.Error("INVALID_APK_ARTIFACT", "Valid compiled .apk file required: ${apkFile.path}")
        }
        val sha = ChecksumVerifier.sha256Hex(apkFile.readBytes())
        return AetherResult.Success(
            PreviewSessionState(
                mode = PreviewMode.COMPILED_ANDROID_APK,
                entryUrlOrPath = apkFile.absolutePath,
                verifiedApkSha256 = sha
            )
        )
    }

    fun createApkInstallIntent(context: Context, apkFile: File, fileProviderUri: Uri): AetherResult<Intent> {
        if (!apkFile.exists() || !apkFile.name.endsWith(".apk")) {
            return AetherResult.Error("INVALID_APK_ARTIFACT", "Valid compiled .apk file required: ${apkFile.path}")
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(fileProviderUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return AetherResult.Success(intent)
    }
}
