# AETHER AI — Security Architecture & Threat Model

## 1. Hardware-Backed Credential Storage (`AndroidKeystoreVault`)

- All cloud provider API keys, GitHub OAuth tokens, Google Drive refresh tokens, and Hugging Face access tokens are encrypted using `AES/GCM/NoPadding` (256-bit key, 128-bit authentication tag, 96-bit randomized IV) backed by the [Android Keystore system](https://developer.android.com/privacy-and-security/keystore).
- Database tables containing project memories and checkpoints use SQLCipher (`net.zetetic:android-database-sqlcipher`).

## 2. Outgoing Secret Detection & Redaction (`SecretScanner`)

Every outgoing prompt, MCP tool call payload, crash report, and audit log passes through `SecretScanner`, which scans and redacts:
- OpenAI API keys (`sk-proj-...`, `sk-...`)
- Anthropic Claude keys (`sk-ant-api03-...`)
- Google AI / Cloud keys (`AIza...`)
- GitHub Personal Access & OAuth tokens (`ghp_...`, `gho_...`, `ghs_...`)
- Hugging Face tokens (`hf_...`)
- AWS Access Key IDs (`AKIA...`)
- PEM-encoded RSA/EC/OpenSSH private keys

## 3. Command Guardrails & Explicit User Approval (`CommandGuardrailEngine`)

Explicit user approval via a modal confirmation dialog (with pre-operation checkpoint creation) is mandatory for:
1. Deleting project directories (`DELETE_PROJECT_DIRECTORY`)
2. Replacing more than 5 files in a single batch (`REPLACE_LARGE_FILE_SET`)
3. Publishing GitHub releases (`PUBLISH_RELEASE`)
4. Executing `git push --force` (`GIT_FORCE_PUSH`)
5. Modifying Android keystore/signing configs (`MODIFY_SIGNING_CREDENTIALS`)
6. Executing shell binaries outside the sandbox allowlist (`UNRESTRICTED_SHELL_EXECUTION`)
7. Uploading sensitive project files to external providers (`EXTERNAL_SENSITIVE_UPLOAD`)

## 4. Untrusted Input Sandboxing & Emergency Stop

- All external skills, repository instructions, and MCP responses are wrapped in `<untrusted_mcp_output>` isolation tags and scanned for prompt-injection directives (`ignore previous instructions`, `override security policy`, `disable secret scanner`).
- A persistent **EMERGENCY STOP** button in the top app bar triggers `EmergencyStopController.triggerEmergencyStop()`, immediately cancelling active coroutine scopes, closing OkHttp SSE streams, aborting local JNI inference loops, and halting WorkManager jobs.
