package com.aether.model.manager

import com.aether.core.common.AetherResult
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class HuggingFaceRegistryClient @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient(),
    private val downloader: ResumableModelDownloader = ResumableModelDownloader()
) {
    fun searchGgufModels(query: String, limit: Int = 10): AetherResult<String> = runCatching {
        val url = "https://huggingface.co/api/models?search=${java.net.URLEncoder.encode(query, "UTF-8")}&filter=gguf&limit=$limit"
        val req = Request.Builder().url(url).get().build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("HF_SEARCH_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("HF_NETWORK_ERROR", it.message ?: "Search failed", it) }
    )

    fun downloadModelResumable(
        request: DownloadRequest,
        destinationFile: File,
        availableStorageBytes: Long
    ): AetherResult<String> = runCatching {
        val existingLen = if (destinationFile.exists()) destinationFile.length() else 0L
        when (val preflight = downloader.verifyStoragePreFlight(request, existingLen, availableStorageBytes)) {
            is AetherResult.Error -> return preflight
            is AetherResult.Success -> Unit
        }
        val reqBuilder = Request.Builder().url(request.downloadUrl).get()
        downloader.buildRangeHeader(existingLen)?.let { reqBuilder.header("Range", it) }

        httpClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 206) {
                return AetherResult.Error("HF_DOWNLOAD_HTTP_${resp.code}", resp.message)
            }
            val stream = resp.body?.byteStream() ?: return AetherResult.Error("HF_EMPTY_STREAM", "No body stream")
            destinationFile.parentFile?.mkdirs()
            RandomAccessFile(destinationFile, "rw").use { raf ->
                if (resp.code == 206 && existingLen > 0L) {
                    raf.seek(existingLen)
                } else {
                    raf.setLength(0L)
                }
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val read = stream.read(buffer)
                    if (read <= 0) break
                    raf.write(buffer, 0, read)
                }
            }
        }
        downloader.finalizeDownload(destinationFile.readBytes(), request.expectedSha256)
    }.fold(
        onSuccess = { it },
        onFailure = { AetherResult.Error("HF_DOWNLOAD_EXCEPTION", it.message ?: "Download failed", it) }
    )
}
