package com.aether.model.manager

import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import javax.inject.Inject
import javax.inject.Singleton

data class DownloadRequest(
    val modelId: String,
    val downloadUrl: String,
    val expectedSizeBytes: Long,
    val expectedSha256: String
)

/**
 * Manages Hugging Face GGUF / LiteRT-LM downloads with pre-flight storage reserve checks,
 * HTTP Range resume support, and post-download SHA-256 verification.
 */
@Singleton
class ResumableModelDownloader @Inject constructor() {
    private val minimumFreeStorageReserveBytes: Long = 1_500L * 1024L * 1024L // 1.5 GB safety reserve

    fun verifyStoragePreFlight(
        request: DownloadRequest,
        alreadyDownloadedBytes: Long,
        availableStorageBytes: Long
    ): AetherResult<Long> {
        val remainingBytes = (request.expectedSizeBytes - alreadyDownloadedBytes).coerceAtLeast(0L)
        val requiredWithReserve = remainingBytes + minimumFreeStorageReserveBytes
        if (availableStorageBytes < requiredWithReserve) {
            return AetherResult.Error(
                code = "INSUFFICIENT_STORAGE",
                message = "Need ${requiredWithReserve / (1024 * 1024)}MB (including 1.5GB OS reserve), but only ${availableStorageBytes / (1024 * 1024)}MB is free."
            )
        }
        return AetherResult.Success(alreadyDownloadedBytes)
    }

    fun buildRangeHeader(existingBytes: Long): String? =
        if (existingBytes > 0L) "bytes=$existingBytes-" else null

    fun finalizeDownload(fileBytes: ByteArray, expectedSha256: String): AetherResult<String> {
        val actualHash = ChecksumVerifier.sha256Hex(fileBytes)
        return if (actualHash.equals(expectedSha256, ignoreCase = true)) {
            AetherResult.Success(actualHash)
        } else {
            AetherResult.Error(
                code = "CHECKSUM_MISMATCH",
                message = "SHA-256 verification failed: expected $expectedSha256, got $actualHash",
                recoverable = true
            )
        }
    }
}
