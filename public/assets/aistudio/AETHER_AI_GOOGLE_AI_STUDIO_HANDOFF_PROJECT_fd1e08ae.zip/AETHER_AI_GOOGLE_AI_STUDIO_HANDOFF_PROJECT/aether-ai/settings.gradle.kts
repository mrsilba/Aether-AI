pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}
rootProject.name = "AetherAI"

include(
    ":app",
    ":core-common",
    ":core-database",
    ":core-security",
    ":core-network",
    ":ai-providers",
    ":local-inference",
    ":model-manager",
    ":agent-runtime",
    ":agent-orchestrator",
    ":skills-engine",
    ":mcp-runtime",
    ":project-manager",
    ":code-editor",
    ":git-integration",
    ":cloud-integrations",
    ":memory-engine",
    ":semantic-search",
    ":terminal-engine",
    ":build-engine",
    ":preview-engine",
    ":automation-engine",
    ":observability",
    ":ui-components"
)
