package com.aether.memory.engine

import com.aether.core.database.AetherDao
import com.aether.core.database.ProjectMemoryEntity
import javax.inject.Inject
import javax.inject.Singleton

enum class MemoryCategory {
    PROJECT_ARCHITECTURE,
    DEVELOPMENT_DECISIONS,
    TECHNICAL_CONSTRAINTS,
    USER_PREFERENCES,
    COMPLETED_MILESTONES,
    PENDING_TASKS,
    KNOWN_DEFECTS,
    PREVIOUS_REPAIRS,
    TEST_RESULTS,
    DOCUMENTATION
}

data class MemoryRecord(
    val id: String,
    val projectId: String,
    val category: MemoryCategory,
    val title: String,
    val statement: String,
    val isVerifiedCurrentState: Boolean,
    val sourceCommitHash: String?,
    val timestampMs: Long
)

/**
 * Project-isolated knowledge store backed by both fast in-memory lookup and encrypted Room persistence.
 * Never silently treats an unverified historical statement as current project state.
 */
@Singleton
class ProjectMemoryIsolationEngine @Inject constructor() {
    private val store = mutableMapOf<String, MutableList<MemoryRecord>>()

    @Synchronized
    fun storeMemory(record: MemoryRecord) {
        val list = store.getOrPut(record.projectId) { mutableListOf() }
        list.removeAll { it.id == record.id }
        list.add(record)
    }

    suspend fun storeAndPersistMemory(record: MemoryRecord, dao: AetherDao) {
        storeMemory(record)
        dao.upsertProjectMemory(
            ProjectMemoryEntity(
                memoryId = record.id,
                projectId = record.projectId,
                category = record.category.name,
                title = record.title,
                content = record.statement,
                verifiedState = record.isVerifiedCurrentState,
                embeddingBlobJson = record.sourceCommitHash,
                updatedAtEpochMs = record.timestampMs
            )
        )
    }

    suspend fun syncFromDatabase(projectId: String, dao: AetherDao): List<MemoryRecord> {
        val entities = dao.getProjectMemoriesSnapshot(projectId)
        val mapped = entities.map { ent ->
            val cat = runCatching { MemoryCategory.valueOf(ent.category) }
                .getOrDefault(MemoryCategory.DOCUMENTATION)
            MemoryRecord(
                id = ent.memoryId,
                projectId = ent.projectId,
                category = cat,
                title = ent.title,
                statement = ent.content,
                isVerifiedCurrentState = ent.verifiedState,
                sourceCommitHash = ent.embeddingBlobJson,
                timestampMs = ent.updatedAtEpochMs
            )
        }
        synchronized(this) {
            store[projectId] = mapped.toMutableList()
        }
        return mapped
    }

    @Synchronized
    fun retrieveForProject(
        projectId: String,
        onlyVerifiedCurrent: Boolean = false
    ): List<MemoryRecord> {
        val records = store[projectId].orEmpty().toList()
        return if (onlyVerifiedCurrent) records.filter { it.isVerifiedCurrentState } else records
    }

    @Synchronized
    fun formatForPromptContext(projectId: String): String {
        val records = store[projectId].orEmpty()
        return records.joinToString("\n") { rec ->
            val tag = if (rec.isVerifiedCurrentState) "[VERIFIED_CURRENT]" else "[HISTORICAL_UNVERIFIED]"
            "$tag [${rec.category}] ${rec.title}: ${rec.statement}"
        }
    }
}
