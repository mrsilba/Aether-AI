package com.aether.project.manager

import com.aether.core.common.AetherResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AuditAndRepairTest {
    private val engine = ProjectAuditAndRepairEngine()

    @Test
    fun `blocks autonomous repair that weakens or deletes unit test assertions`() {
        val snapshot = mapOf(
            "app/src/test/AuthTest.kt" to RepositoryFileSnapshot(
                relativePath = "app/src/test/AuthTest.kt",
                content = "@Test fun testAuth() { assertEquals(200, code); assertTrue(valid) }"
            )
        )
        val badEdit = mapOf(
            "app/src/test/AuthTest.kt" to "@Test fun testAuth() { assertEquals(200, code) }"
        )
        val check = engine.verifyRepairDoesNotTamperWithTests(snapshot, badEdit)
        assertTrue(check is AetherResult.Error)
        assertEquals("TEST_TAMPERING_BLOCKED", (check as AetherResult.Error).code)
    }
}
