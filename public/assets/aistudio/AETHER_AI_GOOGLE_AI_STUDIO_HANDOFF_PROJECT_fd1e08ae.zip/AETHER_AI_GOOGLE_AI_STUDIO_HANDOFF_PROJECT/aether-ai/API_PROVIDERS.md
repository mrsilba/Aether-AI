# AETHER AI — Multi-Provider Cloud AI Gateway

## Supported Providers & Wire Adapters

| Provider | Adapter Class | Default Base Endpoint | Auth Header | Streaming Format | Tool Calling |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **OpenAI** | `OpenAiCompatibleAdapter` | `https://api.openai.com/v1` | `Authorization: Bearer` | SSE (`data: {...}`) | Native `tools` array |
| **Anthropic Claude** | `AnthropicClaudeAdapter` | `https://api.anthropic.com` | `x-api-key` + `anthropic-version: 2023-06-01` | SSE (`event: content_block_delta`) | `input_schema` tools |
| **Google Gemini** | `GoogleGeminiAdapter` | `https://generativelanguage.googleapis.com` | `x-goog-api-key` | SSE (`streamGenerateContent?alt=sse`) | `functionDeclarations` |
| **DeepSeek** | `OpenAiCompatibleAdapter` | `https://api.deepseek.com/v1` | `Authorization: Bearer` | SSE (`reasoning_content` + `content`) | Native `tools` array |
| **OpenRouter** | `OpenAiCompatibleAdapter` | `https://openrouter.ai/api/v1` | `Authorization: Bearer` + `HTTP-Referer` | SSE | Unified tool routing |
| **Custom / Self-Hosted** | `OpenAiCompatibleAdapter` | User-configured (vLLM, Ollama, llama-server) | Configurable Bearer / Custom Headers | SSE | Configurable |

## Model Router Policy & Anti-Downgrade Guarantee

`ModelRouter.selectModel()` evaluates:
1. **Task Complexity Tier**:
   - Tier 3 (`COMPLEX_ARCHITECTURE_OR_SECURITY`): Requires Frontier reasoning models (e.g., Claude Sonnet 4.5 / Opus, Gemini 2.5 Pro, GPT-4.1, DeepSeek-R1).
   - Tier 2 (`STANDARD_CODING`): Supports mid-tier cloud or 7B–8B Q4 local coding models.
   - Tier 1 (`TRIVIAL_AUTOCOMPLETE` / `EMBEDDING_INDEXING`): Supports fast 1.5B–3B local models.
2. **Anti-Silent-Downgrade Rule**: If a Tier 3 task is requested while offline (or under cost limits) and only Tier 1/2 models are reachable, `ModelRouter` returns `AetherResult.Error("MODEL_DOWNGRADE_BLOCKED")` and prompts the user for explicit approval rather than silently degrading quality.
