#!/usr/bin/env bash
set -euo pipefail
# Restores gradle/wrapper/gradle-wrapper.jar on a connected build host if missing
if [ ! -f "gradle/wrapper/gradle-wrapper.jar" ]; then
    echo "[AETHER] Restoring Gradle 8.10.2 wrapper JAR..."
    if command -v gradle >/dev/null 2>&1; then
        gradle wrapper --gradle-version 8.10.2
    else
        echo "[AETHER] System 'gradle' CLI not found. Open project in Android Studio Ladybug+ to sync Gradle 8.10.2 automatically."
        exit 1
    fi
fi
./gradlew --version
