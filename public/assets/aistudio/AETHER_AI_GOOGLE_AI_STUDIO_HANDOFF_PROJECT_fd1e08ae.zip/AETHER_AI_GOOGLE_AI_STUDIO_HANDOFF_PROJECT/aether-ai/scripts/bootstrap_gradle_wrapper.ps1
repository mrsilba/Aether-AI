$ErrorActionPreference = "Stop"
if (-not (Test-Path "gradle/wrapper/gradle-wrapper.jar")) {
    Write-Host "[AETHER] Restoring Gradle 8.10.2 wrapper JAR..."
    if (Get-Command gradle -ErrorAction SilentlyContinue) {
        gradle wrapper --gradle-version 8.10.2
    } else {
        Write-Error "[AETHER] System 'gradle' CLI not found. Open project in Android Studio Ladybug+ to sync Gradle 8.10.2 automatically."
    }
}
.\gradlew.bat --version
