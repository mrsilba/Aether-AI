package com.aether.observability

import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class SocVendor { QUALCOMM_SNAPDRAGON, SAMSUNG_EXYNOS, MEDIATEK_DIMENSITY, GOOGLE_TENSOR, UNKNOWN }
enum class ThermalState { NONE, LIGHT, MODERATE, SEVERE, CRITICAL, EMERGENCY }
enum class InferenceBackendRecommendation { LITERT_GPU_NPU, LLAMA_CPP_VULKAN, LLAMA_CPP_ARM64_NEON_DOTPROD, CLOUD_ONLY }
enum class PowerProfileMode { MAX_PERFORMANCE, BALANCED, BATTERY_SAVER }

data class HardwareProfile(
    val deviceModel: String,
    val socModel: String,
    val socVendor: SocVendor,
    val gpuRenderer: String,
    val totalRamMb: Int,
    val availableRamMb: Int,
    val availableStorageMb: Long,
    val androidSdkInt: Int,
    val cpuAbis: List<String>,
    val supportsArmDotProd: Boolean,
    val supportsArmI8mm: Boolean,
    val supportsFp16: Boolean,
    val thermalState: ThermalState,
    val batteryPercent: Int,
    val isCharging: Boolean,
    val recommendedBackend: InferenceBackendRecommendation,
    val maxSafeLocalModelRamMb: Int
)

/**
 * Runtime hardware detector engineered for flagship Android devices with specific
 * profiling for Samsung Galaxy S22 Ultra variants:
 * - SM-S908U / SM-S908W / SM-S908E / SM-S908N / SM-S9080 (Snapdragon 8 Gen 1 SM8450 + Adreno 730)
 * - SM-S908B (Exynos 2200 S5E9925 + Xclipse 920 RDNA2)
 * - 8 GB LPDDR5 vs 12 GB LPDDR5 RAM configurations
 */
@Singleton
class HardwareCapabilityAssessor @Inject constructor() {

    fun assessRuntimeHardware(
        buildModel: String,
        socHardware: String,
        gpuRenderer: String,
        totalRamMb: Int,
        availableRamMb: Int,
        availableStorageMb: Long,
        androidSdkInt: Int,
        cpuFlags: Set<String>,
        thermalStatusCode: Int,
        batteryPercent: Int,
        isCharging: Boolean,
        powerMode: PowerProfileMode = PowerProfileMode.BALANCED
    ): HardwareProfile {
        val normalizedSoc = socHardware.lowercase()
        val socVendor = when {
            normalizedSoc.contains("sm8450") || normalizedSoc.contains("taro") ||
                normalizedSoc.contains("qcom") || normalizedSoc.contains("snapdragon") -> SocVendor.QUALCOMM_SNAPDRAGON
            normalizedSoc.contains("s5e9925") || normalizedSoc.contains("exynos") -> SocVendor.SAMSUNG_EXYNOS
            normalizedSoc.contains("mt") || normalizedSoc.contains("dimensity") -> SocVendor.MEDIATEK_DIMENSITY
            normalizedSoc.contains("tensor") || normalizedSoc.contains("gs") -> SocVendor.GOOGLE_TENSOR
            else -> SocVendor.UNKNOWN
        }

        val thermalState = when (thermalStatusCode) {
            0 -> ThermalState.NONE
            1 -> ThermalState.LIGHT
            2 -> ThermalState.MODERATE
            3 -> ThermalState.SEVERE
            4 -> ThermalState.CRITICAL
            else -> ThermalState.EMERGENCY
        }

        val supportsDotProd = "asimddp" in cpuFlags || "dotprod" in cpuFlags
        val supportsI8mm = "i8mm" in cpuFlags
        val supportsFp16 = "fphp" in cpuFlags || "asimdhp" in cpuFlags

        // Reserve 2.2 GB for Android OS + Compose UI + LSP/Git workspace
        val osReserveMb = 2200
        val rawSafeBudget = (availableRamMb - osReserveMb / 2).coerceAtMost((totalRamMb * 0.55).toInt())
        val thermalMultiplier = when (thermalState) {
            ThermalState.NONE, ThermalState.LIGHT -> 1.0
            ThermalState.MODERATE -> 0.85
            ThermalState.SEVERE -> 0.60
            ThermalState.CRITICAL, ThermalState.EMERGENCY -> 0.0
        }
        val maxSafeLocalModelRamMb = (rawSafeBudget * thermalMultiplier).toInt().coerceAtLeast(0)

        val recommendedBackend = when {
            thermalState >= ThermalState.CRITICAL || maxSafeLocalModelRamMb < 900 ->
                InferenceBackendRecommendation.CLOUD_ONLY
            powerMode == PowerProfileMode.BATTERY_SAVER ->
                InferenceBackendRecommendation.LLAMA_CPP_ARM64_NEON_DOTPROD
            socVendor == SocVendor.QUALCOMM_SNAPDRAGON && gpuRenderer.contains("Adreno", ignoreCase = true) ->
                InferenceBackendRecommendation.LITERT_GPU_NPU
            socVendor == SocVendor.SAMSUNG_EXYNOS && gpuRenderer.contains("Xclipse", ignoreCase = true) ->
                InferenceBackendRecommendation.LLAMA_CPP_VULKAN
            else ->
                InferenceBackendRecommendation.LLAMA_CPP_ARM64_NEON_DOTPROD
        }

        return HardwareProfile(
            deviceModel = buildModel,
            socModel = socHardware,
            socVendor = socVendor,
            gpuRenderer = gpuRenderer,
            totalRamMb = totalRamMb,
            availableRamMb = availableRamMb,
            availableStorageMb = availableStorageMb,
            androidSdkInt = androidSdkInt,
            cpuAbis = listOf("arm64-v8a"),
            supportsArmDotProd = supportsDotProd,
            supportsArmI8mm = supportsI8mm,
            supportsFp16 = supportsFp16,
            thermalState = thermalState,
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            recommendedBackend = recommendedBackend,
            maxSafeLocalModelRamMb = maxSafeLocalModelRamMb
        )
    }

    fun recommendThreadCount(profile: HardwareProfile, mode: PowerProfileMode): Int {
        if (profile.thermalState >= ThermalState.SEVERE) return 2
        return when (mode) {
            PowerProfileMode.MAX_PERFORMANCE -> 6 // Prime Cortex-X2 + 3x Cortex-A710 + 2x A510
            PowerProfileMode.BALANCED -> 4        // 1x Cortex-X2 + 3x Cortex-A710 performance cores
            PowerProfileMode.BATTERY_SAVER -> 2
        }
    }
}
