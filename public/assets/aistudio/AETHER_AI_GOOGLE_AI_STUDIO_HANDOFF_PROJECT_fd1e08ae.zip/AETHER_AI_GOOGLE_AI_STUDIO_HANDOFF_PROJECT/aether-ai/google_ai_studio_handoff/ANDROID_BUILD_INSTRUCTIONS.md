# AETHER AI — Android Studio & Gradle Build Instructions

## 1. Required Toolchain
- **JDK**: OpenJDK 17 (`17.0.10+`)
- **Gradle**: Gradle `8.10.2` (configured in `gradle/wrapper/gradle-wrapper.properties`)
- **Android Gradle Plugin (AGP)**: `8.7.2`
- **Kotlin / KSP**: Kotlin `2.1.0` / KSP `2.1.0-1.0.29`
- **Android SDK**: Platform `android-35` (API 35), Build-Tools `35.0.0`
- **Android NDK & CMake**: NDK `26.1.10909125`, CMake `3.22.1`

## 2. Step-by-Step Build Procedure

### Step 1: Restore `gradle/wrapper/gradle-wrapper.jar`
If building from the command line before opening in Android Studio:
```bash
./scripts/bootstrap_gradle_wrapper.sh
# Or directly:
gradle wrapper --gradle-version 8.10.2
```
*(If opening directly in Android Studio Ladybug 2024.2.1+, Android Studio automatically downloads Gradle `8.10.2` from `gradle-wrapper.properties`.)*

### Step 2: Configure `local.properties` (Not Committed to Git)
Create `local.properties` at the repository root pointing to your local Android SDK:
```properties
sdk.dir=/path/to/Android/Sdk
```

### Step 3: Validate Project Graph & Run JVM Unit Tests
```bash
./gradlew --version
./gradlew projects
./gradlew testDebugUnitTest
```
This executes all 9 JVM JUnit test classes (`17` `@Test` methods across `:ai-providers`, `:app`, `:core-database`, `:core-security`, `:core-network`, `:project-manager`, `:agent-orchestrator`, `:mcp-runtime`, and `:cloud-integrations`).

### Step 4: Assemble Debug APK (Including Native C++17 `libaether_llama_jni.so`)
```bash
./gradlew :app:assembleDebug
```
Verify the generated APK at:
`app/build/outputs/apk/debug/app-debug.apk`

### Step 5: Inspect Packaged Native Libraries & Assets
```bash
unzip -l app/build/outputs/apk/debug/app-debug.apk | grep -E "libaether_llama_jni\.so|libsqlcipher\.so|tmLanguage\.json"
```
Confirm that:
1. `lib/arm64-v8a/libaether_llama_jni.so` and `lib/x86_64/libaether_llama_jni.so` are present.
2. `lib/arm64-v8a/libsqlcipher.so` and `lib/x86_64/libsqlcipher.so` are present.
3. `assets/textmate/languages.json` and `.tmLanguage.json` files are present.
