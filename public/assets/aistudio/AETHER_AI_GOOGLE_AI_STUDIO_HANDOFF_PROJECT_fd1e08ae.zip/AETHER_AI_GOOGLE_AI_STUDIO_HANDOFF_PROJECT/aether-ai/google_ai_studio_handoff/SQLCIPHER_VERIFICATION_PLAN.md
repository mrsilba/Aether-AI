# AETHER AI — SQLCipher & AndroidKeyStore Verification Plan

## 1. Architecture Under Test
- **Database Initializer**: `core-database/src/main/kotlin/com/aether/core/database/EncryptedDatabaseInitializer.kt`
- **Key Manager**: `core-database/src/main/kotlin/com/aether/core/database/SqlCipherKeyManager.kt`
- **Migration Engine**: `core-database/src/main/kotlin/com/aether/core/database/SqlCipherMigrationEngine.kt`
- **Keystore Vault**: `core-security/src/main/kotlin/com/aether/core/security/SecurityEngine.kt` (`AndroidKeystoreVault`)

## 2. Mandatory Verification Tests (Tests A–G)

### Test A — First-Run Encrypted Database Creation
1. Clear app data (`adb shell pm clear com.aether.ai.workstation`) and launch the app.
2. Verify `files/no_backup/aether_sqlcipher_db_key.wrapped` and `databases/aether_encrypted.db` are created.
3. Verify `EncryptedDatabaseInitializer.state.value == FIRST_TIME_ENCRYPTED_CREATED`.

### Test B — Restart Key Recovery & Reopen
1. Force-stop and relaunch the app (`adb shell am force-stop com.aether.ai.workstation`).
2. Verify `SqlCipherKeyManager` unwraps `aether_sqlcipher_db_key.wrapped` via `AndroidKeyStore` (`KEY_RECOVERED_EXISTING`) and `EncryptedDatabaseInitializer.state.value == ENCRYPTED_OPENED_SUCCESSFULLY`.

### Test C — Raw On-Disk Header Inspection (Not Plaintext SQLite)
1. Pull or inspect the first 16 bytes of `/data/data/com.aether.ai.workstation/databases/aether_encrypted.db`:
   ```bash
   adb exec-out run-as com.aether.ai.workstation head -c 16 databases/aether_encrypted.db | xxd
   ```
2. Verify the header does **NOT** equal `5351 4c69 7465 2066 6f72 6d61 7420 3300` (`SQLite format 3\0`).
3. Verify `sqlite3 aether_encrypted.db "SELECT count(*) FROM sqlite_master;"` without a key fails immediately with `Error: file is not a database`.

### Test D — Wrong Key / Tampered Wrapped Key Rejection
1. Flip 1 byte in `files/no_backup/aether_sqlcipher_db_key.wrapped`.
2. Launch `initializeEncryptedDatabase(context)`.
3. Verify `AndroidKeystoreVault.decryptCredential` throws `AEADBadTagException`, `SqlCipherKeyManager` returns `KEY_INVALIDATED`, and `EncryptedDatabaseInitializer` throws `EncryptedDatabaseInitializationException(KEY_INVALIDATED)` without opening or overwriting `aether_encrypted.db`.

### Test E — Missing Wrapped Key When Encrypted Database Exists (No Plaintext Fallback)
1. Delete `files/no_backup/aether_sqlcipher_db_key.wrapped` while keeping `databases/aether_encrypted.db` intact.
2. Verify `SqlCipherKeyManager.getOrCreateDatabaseKey(..., encryptedDbFileExists = true)` returns `AetherResult.Error(code = "KEY_UNAVAILABLE")` (verified in JVM test `SqlCipherDatabaseSecurityTest.Test G`).

### Test F — Legacy Plaintext (`aether_workspace.db`) to Encrypted (`aether_encrypted.db`) Migration
1. Place a populated plaintext SQLite 3 database at `databases/aether_workspace.db`.
2. Call `EncryptedDatabaseInitializer.initializeEncryptedDatabase(context)`.
3. Verify:
   - `aether_workspace.db.pre_sqlcipher.bak` is created and SHA-256 verified.
   - `sqlcipher_export` migrates all tables and rows into `aether_encrypted.db.migration.tmp`.
   - Row counts across all user tables are verified before `aether_encrypted.db` is promoted and `aether_workspace.db` is deleted.
   - State transitions to `MIGRATION_COMPLETED`.

### Test G — Key Rotation (`commitRotatedDatabaseKey`)
1. Generate a new 32-byte key via `SqlCipherKeyManager.generateCandidateRotationKey()`.
2. Execute `PRAGMA rekey = "x'<newHex>'";` on the open SQLCipher database and call `commitRotatedDatabaseKey(...)`.
3. Verify `lastKeyFingerprintSha256` updates and subsequent opens succeed with the rotated key.
