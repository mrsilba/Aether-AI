# AETHER AI — Project Overview & 24-Module Architecture Guide

## 1. Executive Summary
**AETHER AI** (`com.aether.ai.workstation`) is a 24-module native Android AI engineering workstation built with Kotlin 2.1.0, Jetpack Compose (Material 3 Adaptive), Hilt 2.53.1, Room 2.6.1 + SQLCipher 4.5.4, Eclipse JGit 6.10.0, OkHttp 4.12.0, Rosemoe Sora Editor 0.24.5, and a custom C++17 JNI GGUF v3 Transformer inference and polyglot symbol-indexing engine (`libaether_llama_jni.so`).

- **Application ID**: `com.aether.ai.workstation`
- **Namespace**: `com.aether.ai`
- **Compile / Target SDK**: API 35 (Android 15)
- **Min SDK**: API 28 (Android 9.0)
- **Java / Kotlin Target**: JVM 17 (`JavaVersion.VERSION_17`)
- **NDK / CMake**: NDK `26.1.10909125` / CMake `3.22.1` (`arm64-v8a`, `x86_64`)

## 2. Complete 24-Module Architecture (`settings.gradle.kts`)

| # | Module | Namespace | Responsibility & Key Classes |
| :--- | :--- | :--- | :--- |
| 1 | `:app` | `com.aether.ai` | `@HiltAndroidApp AetherApplication`, `@AndroidEntryPoint MainActivity` (all 10 Compose screens), `OAuthRedirectActivity`, `@HiltViewModel WorkstationViewModel`. |
| 2 | `:core-common` | `com.aether.core.common` | Pure-JVM `AetherResult<T>` monad, `ChecksumVerifier` (`SHA-256`), and `javax.inject` API export. |
| 3 | `:core-database` | `com.aether.core.database` | `AetherDatabase` (8 Room entities, version 1, exported schema `schemas/.../1.json`), `AetherDao`, `EncryptedDatabaseInitializer` (SQLCipher `SupportFactory` + `cipher_memory_security = ON`), `SqlCipherKeyManager` (256-bit key wrapped via AndroidKeyStore + key rotation), `SqlCipherMigrationEngine` (`sqlcipher_export`), `DatabaseModule`. |
| 4 | `:core-security` | `com.aether.core.security` | `AndroidKeystoreVault` (`AES/GCM/NoPadding`, 256-bit key, 128-bit tag), `SecretScanner` (8 credential regexes + redaction), `CommandGuardrailEngine` (binary allowlist + shell metacharacter & path-traversal blocking), `EmergencyStopController`. |
| 5 | `:core-network` | `com.aether.core.network` | `AetherHttpClient`, `NetworkModule`, `SseStreamParser`, `NetworkSecurityValidator` (SSRF blocking for `169.254.169.254`, `127.0.0.0/8`, `10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, `::1`, and cleartext HTTP). |
| 6 | `:ai-providers` | `com.aether.ai.providers` | `OpenAiCompatibleAdapter`, `AnthropicClaudeAdapter`, `GoogleGeminiAdapter`, `ProviderDeltaParser`, `CloudAiExecutionClient`, `ModelRouter` (`MODEL_DOWNGRADE_BLOCKED` protection). |
| 7 | `:local-inference` | `com.aether.local.inference` | `aether_llama_jni.cpp` (GGUF v2/v3 parser, `F32`/`F16`/`Q4_0`/`Q8_0`/`Q4_K`/`Q6_K` dequantizer, multi-threaded RoPE+GQA+SwiGLU Transformer forward pass), `aether_polyglot_indexer_jni.cpp`, `LlamaCppNativeBridge`, `LocalModelLifecycleManager`, `IsolatedInferenceService` (`:inference_service` process). |
| 8 | `:model-manager` | `com.aether.model.manager` | `ResumableModelDownloader` (1.5 GB OS storage reserve + HTTP `Range` resume + SHA-256 verification), `HuggingFaceRegistryClient`. |
| 9 | `:agent-runtime` | `com.aether.agent.runtime` | `CoreAgentsRegistry` (12 specialized engineering agents with tool allowlists and iteration caps), `AgentDeveloperToolchainBridge`. |
| 10 | `:agent-orchestrator` | `com.aether.agent.orchestrator` | `SupervisorOrchestrator` (topological parallel DAG waves, cycle & file-conflict detection), `AutonomousAgentLoopEngine` (multi-turn ReAct loop with retries, permission gates, Emergency Stop, and Room checkpointing). |
| 11 | `:skills-engine` | `com.aether.skills.engine` | `SkillManager` (manifest validation, prompt-injection & secret-exfiltration blocking, Markdown skill loader). |
| 12 | `:mcp-runtime` | `com.aether.mcp.runtime` | `McpClientRuntime` (JSON-RPC 2.0 `initialize`, `tools/list`, `tools/call`, `resources/list`, `resources/read`, response ID/envelope validation, `<untrusted_mcp_output>` tagging), `McpHttpTransport` (HTTPS + SSRF check + `STDIO_LOCAL` process bridge). |
| 13 | `:project-manager` | `com.aether.project.manager` | `ProjectAuditAndRepairEngine` (recursive disk scanner, 13-step forensic audit, `verifyRepairDoesNotTamperWithTests`, checkpoint backup, patch application, rollback). |
| 14 | `:code-editor` | `com.aether.code.editor` | `DiffAndHistoryManager`, `PolyglotLanguageEngine` (14-language capability matrix, symbol indexing, go-to-definition, find-references), `LspJsonRpcEngine`, `SoraEditorComposeBridge`, bundled TextMate `.tmLanguage.json` grammars (`src/main/assets/textmate/`). |
| 15 | `:git-integration` | `com.aether.git.integration` | `JGitRepositoryController` (`init`, `clone`, `status`, `diff`, `listBranches`, `stageAndCommit`, `createAndCheckoutBranch`, `pull`, `push`, `stash`), `GitConflictInspector` (conflict parser & resolver). |
| 16 | `:cloud-integrations` | `com.aether.cloud.integrations` | `OAuth2PkceManager` (`S256` challenge, CSRF `state` verification, authorization code exchange, token refresh), `GitHubRestClient` (`/user`, `/user/repos`, `/issues`, `/pulls`, `/actions/runs`), `GoogleDriveRestClient` (list, createFolder, multipart upload, verified SHA-256 download), `VerifiedDriveBackupService`. |
| 17 | `:memory-engine` | `com.aether.memory.engine` | `ProjectMemoryIsolationEngine` (`[VERIFIED_CURRENT]` vs `[HISTORICAL_UNVERIFIED]` tagging + `AetherDao` Room persistence sync). |
| 18 | `:semantic-search` | `com.aether.semantic.search` | `DeterministicCodeEmbedder` (64-dim normalized token/n-gram embeddings), `HybridSemanticSearchEngine` (sliding-window chunker + 0.65 Cosine + 0.35 BM25 lexical ranker). |
| 19 | `:terminal-engine` | `com.aether.terminal.engine` | `SandboxedTerminalSession` (canonical workspace root confinement, `CommandGuardrailEngine` check, credential env var scrubbing, timeout enforcement). |
| 20 | `:build-engine` | `com.aether.build.engine` | `CompilerDiagnosticParser`, `ProjectBuildExecutor` (allowlisted Gradle tasks, streaming stdout/stderr `Flow<String>`, debug APK locator), `DeveloperLibraryManager`. |
| 21 | `:preview-engine` | `com.aether.preview.engine` | `PreviewEngineController` (`STATIC MOCKUP`, `LIVE DEV PREVIEW`, `RUNNING COMPILED APK` badges + `PackageInstaller` intent). |
| 22 | `:automation-engine` | `com.aether.automation.engine` | `AetherAutomationWorker` (`CoroutineWorker` writing execution journals to `noBackupFilesDir`), `AutomationTaskScheduler` (exponential backoff + battery/network constraints). |
| 23 | `:observability` | `com.aether.observability` | `HardwareCapabilityAssessor` (Samsung Galaxy S22 Ultra `SM-S908U` Snapdragon 8 Gen 1 / `SM-S908B` Exynos 2200 detection, thermal/RAM safe budget calculation, thread scaling). |
| 24 | `:ui-components` | `com.aether.ui.components` | `AetherWorkstationTheme` (Charcoal/Cyan/Violet dark/light schemes + RTL Persian / LTR English `LocalLayoutDirection`), `ResizableSplitPane` (interactive drag handle), `TelemetryMetricCard`, `UnifiedDiffReviewCard`. |
