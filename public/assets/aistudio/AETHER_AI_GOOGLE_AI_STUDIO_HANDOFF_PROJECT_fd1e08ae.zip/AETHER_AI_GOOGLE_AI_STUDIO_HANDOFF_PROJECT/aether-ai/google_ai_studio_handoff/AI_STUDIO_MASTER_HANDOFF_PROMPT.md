# AETHER AI — Master Handoff Prompt for Google AI Studio Engineering Agent

Copy and provide the following prompt to the Google AI Studio engineering agent when importing this repository:

---

```text
You are receiving the remediated 24-module AETHER AI Android Engineering Workstation repository (`com.aether.ai.workstation`).

A comprehensive source-level remediation pass has already been completed across all 24 Gradle modules, including:
- Complete Hilt dependency injection (`@HiltAndroidApp`, `@AndroidEntryPoint`, `@HiltViewModel WorkstationViewModel` injecting all 25 workstation subsystems, `@Singleton @Inject` constructors across all modules).
- SQLCipher 4.5.4 + Room 2.6.1 encrypted database architecture (`EncryptedDatabaseInitializer`, `SqlCipherKeyManager` with AndroidKeyStore AES-256-GCM wrapping and key rotation, `SqlCipherMigrationEngine` with `sqlcipher_export`, and exported Room schema `core-database/schemas/com.aether.core.database.AetherDatabase/1.json`).
- Native C++17 GGUF v3 inference and polyglot symbol-indexing engine (`local-inference/src/main/cpp/aether_llama_jni.cpp` and `aether_polyglot_indexer_jni.cpp`) supporting `F32`, `F16`, `Q4_0`, `Q8_0`, `Q4_K` (`Q4_K_M`), and `Q6_K` tensor dequantization, bounds checking, multi-threaded matmul, and `IsolatedInferenceService` (`:inference_service`), verified by `9/9` passing host C++17 tests in `local-inference/src/test/cpp/aether_native_test.cpp`.
- Multi-turn ReAct agent orchestration (`AutonomousAgentLoopEngine` + `SupervisorOrchestrator`), MCP JSON-RPC 2.0 HTTP/stdio client with SSRF and secret-exfiltration blocking (`McpClientRuntime`, `McpHttpTransport`, `NetworkSecurityValidator`), `GitHubRestClient`, `GoogleDriveRestClient`, `OAuth2PkceManager`, `OAuthRedirectActivity`, bundled TextMate `.tmLanguage.json` grammars, and dedicated Jetpack Compose screens for all 10 `WorkstationDestination` panes in `MainActivity.kt`.

YOUR MISSION IN GOOGLE AI STUDIO:

1. DO NOT rewrite or replace already-implemented modules with placeholders or scaffolds. Read `google_ai_studio_handoff/PROJECT_OVERVIEW.md`, `IMPLEMENTATION_COMPLETION_REPORT.md`, and `REMAINING_DEFECTS.md` first.
2. Restore `gradle/wrapper/gradle-wrapper.jar` for Gradle `8.10.2` (via `./scripts/bootstrap_gradle_wrapper.sh` or Android Studio Gradle Sync).
3. Run `./gradlew testDebugUnitTest` across all 24 modules and verify that all 9 JUnit test classes (`18` `@Test` methods) compile and pass. If any Kotlin/KSP compiler diagnostic surfaces during the real Gradle build, apply minimal, targeted fixes without weakening any test assertions or security checks.
4. Run `./gradlew :app:assembleDebug` to produce `app/build/outputs/apk/debug/app-debug.apk` and verify that `libaether_llama_jni.so`, `libsqlcipher.so`, and `assets/textmate/*.tmLanguage.json` are packaged inside the APK.
5. Execute `google_ai_studio_handoff/ANDROID_RUNTIME_VERIFICATION_PLAN.md` and `SQLCIPHER_VERIFICATION_PLAN.md` on an Android API 35 emulator or physical Samsung Galaxy S22 Ultra (`SM-S908U` / `SM-S908B`), capturing real `adb logcat` and on-device file header evidence.
6. Only after `./gradlew testDebugUnitTest`, `./gradlew :app:assembleDebug`, and on-device SQLCipher verification succeed with exit code `0`, create the verification tags `phase-1-build-bootstrap-verified` and `phase-2-di-encrypted-database-verified`.
```
