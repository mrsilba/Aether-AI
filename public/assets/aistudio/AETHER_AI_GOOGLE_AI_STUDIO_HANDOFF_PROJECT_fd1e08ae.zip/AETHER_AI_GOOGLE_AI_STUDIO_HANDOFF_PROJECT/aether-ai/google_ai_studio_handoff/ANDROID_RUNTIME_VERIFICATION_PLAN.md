# AETHER AI — Android Runtime & Device Verification Plan

## 1. Target Device / Emulator Matrix
- **Primary Physical Target**: Samsung Galaxy S22 Ultra (`SM-S908U` Snapdragon 8 Gen 1 / `SM-S908B` Exynos 2200, 12 GB RAM, Android 14/15).
- **Emulator Target**: Pixel 8 Pro / Medium Tablet AVD (API 35, `arm64-v8a` or `x86_64`, 8 GB RAM).

## 2. Runtime Verification Checklist

### Test RT-01: Cold Start, Hilt Graph Initialization & SQLCipher Database Creation
1. Install and launch `com.aether.ai.workstation`:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   adb shell am start -n com.aether.ai.workstation/com.aether.ai.MainActivity
   ```
2. Verify top bar displays `DB: FIRST_TIME_ENCRYPTED_CREATED` on first launch and `DB: ENCRYPTED_OPENED_SUCCESSFULLY` on subsequent launches.
3. Verify zero crashes in `adb logcat -s AndroidRuntime:E`.

### Test RT-02: All 10 Workstation Navigation Destinations
Click through destinations `1` through `10` in the left `NavigationRail` and verify each dedicated Compose screen renders and responds:
1. `1. Dashboard`: Verify hardware telemetry card, model routing card, and SQLCipher key fingerprint card.
2. `2. AI Workspace`: Edit source code in the left pane, verify live symbol count updates (`Indexed Symbols`), verify unified diff review card appears in the right pane, test `Undo`/`Redo`, and run `git status` in the guardrailed terminal box.
3. `3. Agents`: Tap `Verify DAG Waves` and verify wave plan (`Wave 1: ARCHITECT, SECURITY_AUDITOR -> Wave 2: SENIOR_DEVELOPER -> Wave 3: QA_ENGINEER`).
4. `4. Projects & Audit`: Tap `Run 13-Step Audit` and verify audit scan completes.
5. `5. Models`: Tap `Load Model` on `Qwen2.5-Coder-1.5B-Q8_0` and verify RAM budget calculation and status update.
6. `6. Skills & MCP`: Verify listed MCP servers (`STDIO_LOCAL` and `HTTP_SSE`).
7. `7. Integrations`: Verify JGit branch status, GitHub REST API v3 endpoints, OAuth PKCE S256 challenge preview, and Drive SHA-256 verification status.
8. `8. Automations`: Verify all 8 Developer Library tools render with version, SPDX license, and execution environment.
9. `9. Memory`: Enter `verifyReady` in Hybrid Cosine + BM25 Search and tap `Search`; verify matching code chunk `MainActivity.kt (L1–L4)` appears.
10. `10. Settings`: Toggle `Persian (فارسی RTL)` / `English (LTR)`, `Dark` / `Light`, and `EMERGENCY STOP` / `RESUME`.

### Test RT-03: Isolated Inference Service (`:inference_service`) Memory Pressure Handling
1. Verify `IsolatedInferenceService` is declared with `android:process=":inference_service"`.
2. Simulate critical memory pressure:
   ```bash
   adb shell am send-trim-memory com.aether.ai.workstation:inference_service RUNNING_CRITICAL
   ```
3. Verify service releases native GGUF weights and KV cache cleanly without crashing the main UI process.
