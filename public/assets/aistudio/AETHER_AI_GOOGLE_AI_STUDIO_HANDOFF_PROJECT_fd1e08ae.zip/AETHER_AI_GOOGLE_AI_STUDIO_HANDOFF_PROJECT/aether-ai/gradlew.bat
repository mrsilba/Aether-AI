@rem Gradle startup script for Windows
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
where gradle >nul 2>nul
if %ERRORLEVEL% equ 0 (
    gradle %*
    exit /b %ERRORLEVEL%
)
echo ERROR: System gradle not found in PATH and gradle-wrapper.jar not bootstrapped.
exit /b 1
    
