# AETHER AI — Phase 2: Plaintext-to-Encrypted Database Migration Report

- **File**: `core-database/src/main/kotlin/com/aether/core/database/SqlCipherMigrationEngine.kt`
- **Mechanism**: Official SQLCipher `sqlcipher_export('encrypted')` convenience function (`net.sqlcipher.database.SQLiteDatabase`).

---

## 1. Ten-Step Safe Migration Protocol

1. **Plaintext Header Detection (`isPlaintextSqliteFile`)**:
   - Inspects the first 16 bytes of `aether_workspace.db`. Unencrypted SQLite 3 files always begin with `"SQLite format 3\u0000"` (`53 51 4c 69 74 65 20 66 6f 72 6d 61 74 20 33 00`).
2. **Existing Encrypted Database Protection**:
   - Checks whether `aether_encrypted.db` already exists and has a non-plaintext header (`!isPlaintextSqliteFile(encryptedDbFile)`). If so, returns `ENCRYPTED_DB_ALREADY_ACTIVE` without touching it.
3. **Interrupted Migration Cleanup**:
   - If a stale `aether_encrypted.db.migration.tmp` file exists from a prior interrupted migration, deletes the `.tmp` file before starting.
4. **Recoverable Pre-Migration Backup**:
   - Copies `aether_workspace.db` to `aether_workspace.db.pre_sqlcipher.bak` and verifies matching SHA-256 digests (`ChecksumVerifier.sha256Hex`) before opening the database.
5. **Source Table & Record Inventory**:
   - Queries `SELECT name FROM sqlite_master WHERE type='table'` on the plaintext database and records `SELECT count(*) FROM <table>` for every user table.
6. **Encrypted Export (`sqlcipher_export`)**:
   - Executes:
     ```sql
     ATTACH DATABASE '<path>/aether_encrypted.db.migration.tmp' AS encrypted KEY "x'<64-hex-char-key>'";
     SELECT sqlcipher_export('encrypted');
     DETACH DATABASE encrypted;
     ```
7. **Post-Export Header Check**:
   - Verifies `aether_encrypted.db.migration.tmp` exists and does **not** begin with `"SQLite format 3\u0000"`.
8. **Post-Export Reopen & Row-Count Verification**:
   - Reopens `aether_encrypted.db.migration.tmp` using `SQLiteDatabase.openDatabase(..., keyBytes, ...)` in read-only mode and verifies that every table's `SELECT count(*)` matches `sourceRowCounts`.
9. **Atomic Promotion**:
   - Atomically renames `aether_encrypted.db.migration.tmp` to `aether_encrypted.db`.
10. **Plaintext Retirement & Backup Retention**:
    - Deletes `aether_workspace.db` only after Steps 7–9 succeed, while preserving `aether_workspace.db.pre_sqlcipher.bak` as a recoverable backup until explicit post-migration retention cleanup.
