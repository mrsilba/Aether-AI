# AETHER AI — Phase 2: Encrypted Database Architecture Report

- **Implementation Commit**: `security(phase-2): activate SQLCipher database encryption`
- **Room Version**: `androidx.room:room-runtime:2.6.1` & `androidx.room:room-ktx:2.6.1`
- **SQLCipher Artifact**: `net.zetetic:android-database-sqlcipher:4.5.4`
- **Authoritative `Room.databaseBuilder` Location**: `core-database/src/main/kotlin/com/aether/core/database/EncryptedDatabaseInitializer.kt` (Verified: `1` total occurrence across all `44` Kotlin files in the repository).

---

## 1. Exact SQLCipher 4.5.4 Integration Verification

1. **Verified Artifact & Classes**:
   - `net.zetetic:android-database-sqlcipher:4.5.4` provides:
     - `net.sqlcipher.database.SQLiteDatabase` (`SQLiteDatabase.loadLibs(context)` to load `libsqlcipher.so` for `arm64-v8a` / `x86_64`).
     - `net.sqlcipher.database.SupportFactory(byte[] passphrase)` implementing `androidx.sqlite.db.SupportSQLiteOpenHelper.Factory`.
2. **Authoritative Initialization Flow (`EncryptedDatabaseInitializer.initializeEncryptedDatabase`)**:
   - Invokes `SQLiteDatabase.loadLibs(context)`.
   - Verifies that `aether_encrypted.db` (if already present on disk) does **not** begin with the 16-byte plaintext header `"SQLite format 3\u0000"`.
   - Retrieves the 32-byte (256-bit) key via `SqlCipherKeyManager.getOrCreateDatabaseKey(context.noBackupFilesDir, encryptedDbFile.exists())`.
   - Runs `SqlCipherMigrationEngine.migrateIfPlaintextExists(...)` if legacy `aether_workspace.db` exists.
   - Instantiates `SupportFactory(passphraseCopy)` and passes it to `.openHelperFactory(supportFactory)` on `Room.databaseBuilder`.
   - Immediately calls `db.openHelper.writableDatabase.version` to force SQLCipher page-1 HMAC/key verification before returning the `AetherDatabase` instance.
   - Zeroizes temporary key buffers in the `finally` block (`unwrappedKey.zeroize()`).

---

## 2. Explicit Initialization State Machine (`EncryptedDatabaseState`)

`EncryptedDatabaseInitializer.state` exposes a reactive `StateFlow<EncryptedDatabaseState>` distinguishing all 8 required states:
1. `FIRST_TIME_ENCRYPTED_CREATED`
2. `ENCRYPTED_OPENED_SUCCESSFULLY`
3. `MIGRATION_IN_PROGRESS`
4. `MIGRATION_COMPLETED`
5. `KEY_UNAVAILABLE`
6. `KEY_INVALIDATED`
7. `DATABASE_CORRUPTION_DETECTED`
8. `ENCRYPTION_INITIALIZATION_FAILED`
