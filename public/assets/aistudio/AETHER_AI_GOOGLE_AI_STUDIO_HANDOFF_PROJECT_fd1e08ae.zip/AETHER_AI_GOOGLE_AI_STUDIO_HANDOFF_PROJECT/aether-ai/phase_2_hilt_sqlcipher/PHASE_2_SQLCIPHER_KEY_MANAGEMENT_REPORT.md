# AETHER AI — Phase 2: SQLCipher Encryption-Key Management Report

- **File**: `core-database/src/main/kotlin/com/aether/core/database/SqlCipherKeyManager.kt`
- **Root of Trust**: `AndroidKeystoreVault` (`core-security/.../SecurityEngine.kt`, alias `"aether_master_aes256_gcm_key"`, `AES/GCM/NoPadding`, 256-bit key, 128-bit GCM tag, 96-bit randomized IV).

---

## 1. Key Generation, Wrapping & Storage Lifecycle

1. **First-Run Creation (`DatabaseKeyState.KEY_CREATED_FIRST_RUN`)**:
   - When neither `aether_encrypted.db` nor `noBackupFilesDir/aether_sqlcipher_db_key.wrapped` exists:
   - Generates 32 bytes (256 bits) of cryptographically secure random key material via `java.security.SecureRandom().nextBytes(ByteArray(32))`.
   - Wraps the key material using `AndroidKeystoreVault.encryptCredential(...)` (`AES/GCM/NoPadding`).
   - Writes **only** the wrapped binary payload (`[iv_length (1B) || iv (12B) || ciphertext + 128-bit GCM tag]`) to `context.noBackupFilesDir/aether_sqlcipher_db_key.wrapped` (excluded from Android Auto Backup).
2. **Application Restart & Key Recovery (`DatabaseKeyState.KEY_RECOVERED_EXISTING`)**:
   - Reads `aether_sqlcipher_db_key.wrapped`, decrypts via `AndroidKeystoreVault.decryptCredential(...)`, verifies exact 32-byte key length, passes a copy to `SupportFactory`, and calls `unwrappedKey.zeroize()` (`keyBytes.fill(0)`) in `finally`.
3. **Key Unavailable Detection (`DatabaseKeyState.KEY_UNAVAILABLE`)**:
   - If `aether_encrypted.db` already exists on disk, but `aether_sqlcipher_db_key.wrapped` is missing, `SqlCipherKeyManager` **refuses to generate a new key** and returns `AetherResult.Error(code = "KEY_UNAVAILABLE")`, transitioning `EncryptedDatabaseInitializer` to `EncryptedDatabaseState.KEY_UNAVAILABLE`.
4. **Key Invalidation Detection (`DatabaseKeyState.KEY_INVALIDATED`)**:
   - If Android Keystore throws `AEADBadTagException`, `KeyPermanentlyInvalidatedException`, or any keystore decryption error, `SqlCipherKeyManager` returns `AetherResult.Error(code = "KEY_INVALIDATED")`, transitioning `EncryptedDatabaseInitializer` to `EncryptedDatabaseState.KEY_INVALIDATED`.

---

## 2. Hardware Security & Recovery Limitations

- **TEE vs. StrongBox**: `AndroidKeystoreVault` uses the platform `AndroidKeyStore` provider, which delegates to the device's Trusted Execution Environment (TEE, e.g., Qualcomm Secure Execution Environment on `SM-S908U` or Samsung Knox TEEgris on `SM-S908B`). StrongBox is not claimed unless explicitly configured and verified at runtime.
- **Recovery Limitation**: Because the 256-bit database key is wrapped by a non-exportable Android Keystore key inside `noBackupFilesDir`, factory-resetting the phone or clearing app data permanently destroys the key. Users must rely on Verified Google Drive Project Backups (`VerifiedDriveBackupService`) for cross-device restoration.
