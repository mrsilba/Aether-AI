# AETHER AI — Autonomous Android AI Engineering Workstation

AETHER AI is a native, modular Android engineering workstation designed for flagship ARM64 devices (primary target: **Samsung Galaxy S22 Ultra** `SM-S908U` Snapdragon 8 Gen 1 / `SM-S908B` Exynos 2200). It unifies multi-provider cloud AI gateways, on-device local LLM inference ([Google AI Edge LiteRT-LM](https://developers.google.com/edge/litert-lm/android) and [llama.cpp Android NDK](https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md)), a 12-agent DAG orchestrator, [Model Context Protocol (MCP)](https://modelcontextprotocol.io/specification/2026-07-28) tool integration, an embedded [Sora Editor](https://github.com/Rosemoe/sora-editor) IDE, [Eclipse JGit](https://github.com/eclipse-jgit/jgit) version control, a 13-step Project Audit & 10-step Autonomous Repair engine, and hardware-backed [Android Keystore](https://developer.android.com/privacy-and-security/keystore) security.

## Core Highlights

- **24 Modular Clean Architecture Modules**: Strictly separated Presentation (Jetpack Compose Material 3 Adaptive), Domain (Supervisor DAG, Model Router, Audit/Repair), and Infrastructure (OkHttp SSE, JNI `llama.cpp`, LiteRT-LM, Room + SQLCipher, JGit, WorkManager) layers.
- **Hybrid Cloud + Offline Local AI**: Seamless routing across OpenAI, Anthropic Claude, Google Gemini, DeepSeek, OpenRouter, custom OpenAI-compatible servers, and local GGUF / LiteRT-LM models with strict anti-downgrade protection.
- **Hardware-Aware Execution for Samsung Galaxy S22 Ultra**: Runtime profiling of Snapdragon 8 Gen 1 (`sm8450`, Adreno 730) and Exynos 2200 (`s5e9925`, Xclipse 920), 8 GB vs. 12 GB LPDDR5 memory budgets, and [Android PowerManager Thermal Status](https://developer.android.com/reference/android/os/PowerManager.OnThermalStatusChangedListener) throttling.
- **Bilingual LTR/RTL Interface**: Dark-first charcoal aesthetic (`#0B0E14`) with cyan (`#00E5FF`), violet (`#7C4DFF`), and blue (`#2979FF`) accents, supporting both English (LTR) and Persian (`fa`, RTL).

## Repository Structure

| Module | Responsibility | Key Technologies |
| :--- | :--- | :--- |
| `:app` | Application shell, 10 navigation destinations, RTL/LTR localization | Jetpack Compose, Hilt, Material 3 Adaptive |
| `:core-common` | Result monads, SHA-256 checksum verifier, coroutine dispatchers | Kotlin Coroutines, Serialization |
| `:core-security` | AES-256-GCM Keystore vault, secret scanner, command allowlist/denylist, emergency stop | [Android Keystore](https://developer.android.com/privacy-and-security/keystore) |
| `:core-database` | Encrypted persistence for providers, models, projects, checkpoints, memories, audit logs | [AndroidX Room](https://developer.android.com/jetpack/androidx/releases/room), SQLCipher |
| `:core-network` | Streaming Server-Sent Events (SSE) parser, TLS client, retry interceptors | OkHttp 4.12 |
| `:ai-providers` | Multi-provider gateway, native adapters (OpenAI, Anthropic, Gemini, DeepSeek, OpenRouter), ModelRouter | Custom Wire Adapters |
| `:local-inference` | On-device inference abstraction, C++17 GGUF header/KV-cache JNI bridge, LiteRT-LM adapter | [LiteRT-LM](https://developers.google.com/edge/litert-lm/android), [llama.cpp](https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md) |
| `:model-manager` | Hugging Face discovery, HTTP Range resumable downloader, SHA-256 verifier | OkHttp Range + SHA-256 |
| `:agent-runtime` | 12 specialized engineering agent definitions, tool schemas, execution sandboxes | Kotlin Coroutines |
| `:agent-orchestrator` | Supervisor DAG planner, parallel wave executor, conflict detector, checkpoint recovery | DAG Topological Scheduler |
| `:skills-engine` | Extensible skill manifest validator, prompt-injection sanitizer, Git/local skill installer | JSON Schema + Regex Guard |
| `:mcp-runtime` | JSON-RPC 2.0 MCP client, tool discovery, untrusted output isolation tags | [MCP 2026-07-28 Spec](https://modelcontextprotocol.io/specification/2026-07-28) |
| `:project-manager` | SAF bridge, 13-step Repository Audit Engine, 10-step Autonomous Repair with rollback | [Android SAF](https://developer.android.com/guide/topics/providers/document-provider) |
| `:code-editor` | Multi-tab syntax editor for 14 languages, unified diff engine, undo/redo stack | [Sora Editor](https://github.com/Rosemoe/sora-editor) |
| `:git-integration` | Clone, branch, commit, diff, pull, push, merge, stash, conflict parser | [Eclipse JGit](https://github.com/eclipse-jgit/jgit) |
| `:cloud-integrations` | GitHub, Google Drive versioned SHA-256 verified backup, Hugging Face, GitLab, Supabase, Notion, Figma | REST v3 + OAuth2 PKCE |
| `:memory-engine` | Project-isolated memory across 10 categories with `[VERIFIED_CURRENT]` vs `[HISTORICAL_UNVERIFIED]` tagging | Room + JSON Export |
| `:semantic-search` | Code chunker, hybrid BM25 + cosine vector similarity search | Local/Cloud Embeddings |
| `:terminal-engine` | Sandboxed process session manager with allowlist enforcement | `ProcessBuilder` |
| `:build-engine` | Compiler diagnostic parser, on-device validator, optional Remote Build Worker client | Gradle / Remote Worker API |
| `:preview-engine` | Web preview, UI preview, APK installer, explicit `STATIC MOCKUP` / `LIVE DEV PREVIEW` / `RUNNING COMPILED APK` badges | Android WebView + PackageInstaller |
| `:automation-engine` | Background task queue, commit/backup triggers, checkpoint resume | [AndroidX WorkManager](https://developer.android.com/jetpack/androidx/releases/work) |
| `:observability` | Galaxy S22 Ultra SoC/RAM/Thermal profiler, live resource dashboard, adaptive thread scaler | [PowerManager Thermal API](https://developer.android.com/reference/android/os/PowerManager.OnThermalStatusChangedListener) |
| `:ui-components` | Dark-first design system, resizable split-pane layout, telemetry widgets | [Compose Material 3 Adaptive](https://developer.android.com/jetpack/androidx/releases/compose-material3-adaptive) |
