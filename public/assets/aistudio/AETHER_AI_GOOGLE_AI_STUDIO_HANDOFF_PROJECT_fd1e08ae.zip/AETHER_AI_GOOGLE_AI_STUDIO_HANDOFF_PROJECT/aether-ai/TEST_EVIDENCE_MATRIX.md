# AETHER AI — Forensic Test Reclassification & Evidence Matrix

Every test artifact in the repository and verification harness has been reclassified into the 7 strict forensic categories:
1. `STATIC_SOURCE_INSPECTION`
2. `UNIT_TEST`
3. `MOCK_INTEGRATION_TEST`
4. `NATIVE_HOST_TEST`
5. `ANDROID_INSTRUMENTATION_TEST`
6. `REAL_EXTERNAL_SERVICE_INTEGRATION_TEST`
7. `PHYSICAL_DEVICE_VALIDATION`

## 1. Reclassification of Baseline Tests (`ab81048`)

| Test Artifact / ID | Previous Claim (`ab81048`) | True Forensic Category | Actual Execution Status in Baseline (`ab81048`) | Forensic Explanation |
| :--- | :--- | :--- | :--- | :--- |
| `local-inference/src/test/cpp/aether_native_test.cpp` | "Native C++17 Binary Verified" | **4. Native Host Test** | **Compiled as `.so` only; `main()` failed to run on `/tmp` (`noexec`)** | Compiled into `libaether_llama_jni.so`, but `/tmp/aether_native_test_runner` threw `PermissionError` because `/tmp` is mounted `noexec`. |
| `run_verification_suite.py` (`TST-01`..`TST-13`) | "13/13 Integration / Offline / Provider / Recovery Tests Passed" | **3. Mock Integration Test (Python Simulation)** | **Executed in Python (Did NOT execute Kotlin bytecode)** | Tested Python re-implementations of the formulas rather than compiling and running the Kotlin classes. |
| `core-security/.../SecurityEngineTest.kt` | "Unit Test Included" | **2. Unit Test (Kotlin JUnit)** | **`BLOCKED_BY_ENVIRONMENT` (Uncompiled in container)** | Valid JUnit4 source file, but `kotlinc` is not installed in the sandbox VM. |
| `ai-providers/.../ModelRouterTest.kt` | "Unit Test Included" | **2. Unit Test (Kotlin JUnit)** | **`BLOCKED_BY_ENVIRONMENT` (Uncompiled in container)** | Valid JUnit4 source file, but `kotlinc` is not installed in the sandbox VM. |
| `project-manager/.../AuditAndRepairTest.kt` | "Unit Test Included" | **2. Unit Test (Kotlin JUnit)** | **Would `FAIL_COMPILATION` in baseline (`ab81048`)** | Referenced `ProjectAuditAndRepairEngine.kt`, which had an unescaped string literal syntax error on line 102 in baseline `ab81048`. |
| Android UI / Espresso / Compose Tests | Not present | **5. Android Instrumentation Test** | **`NOT_IMPLEMENTED` / `BLOCKED_BY_ENVIRONMENT`** | No `src/androidTest` files existed in baseline; no Android emulator or physical device is attached. |
| Live Cloud AI / GitHub / Google Drive API Calls | "Connected" in UI preview | **6. Real External Service Integration Test** | **`BLOCKED_BY_ENVIRONMENT` (Sandbox has no internet)** | Outbound network access is disabled in the sandbox VM; cannot hit live `api.openai.com`, `api.github.com`, or `googleapis.com`. |
| Samsung Galaxy S22 Ultra Hardware Validation | "Profiled" | **7. Physical-Device Validation** | **`BLOCKED_BY_ENVIRONMENT` (No physical phone attached)** | `HardwareCapabilityAssessor` logic is implemented, but has not been run on a physical `SM-S908U` / `SM-S908B` handset. |

## 2. Post-Recovery Verification Evidence Matrix (`HEAD`)

| Verification ID | Forensic Category | Target Under Test | Execution Command & Environment | Verified Outcome |
| :--- | :--- | :--- | :--- | :--- |
| `VER-NAT-01` | **4. Native Host Test** | `local-inference/src/main/cpp/aether_llama_jni.cpp` (GGUF v3 parser, KV-cache sizing, BPE tokenizer, quantized forward pass, streaming generation, cancellation, JNI `extern "C"` symbols) | Compiled with `g++ -std=c++17 -O2 -Wall -Wextra -Werror` and executed directly from executable XFS `/working_dir` mount (`aether_native_test_bin` + Python `ctypes.CDLL` JNI call) | **PASSED (Real Native Execution)**: Verified GGUF v3 header, rejected corrupt header, tokenized prompt into token IDs, streamed generated tokens via callback, verified mid-stream atomic cancellation, and freed native context. |
| `VER-STC-01` | **1. Static Source Inspection** | All 24 modules (`*.kt`, `*.kts`, `*.xml`, `gradlew`) | Executed `verify_kotlin_and_manifest.py` AST/lexical & manifest verifier across the entire repository on disk | **PASSED**: Verified 24/24 modules contain valid Kotlin source files, zero unescaped string quotes, zero ASCII control chars, balanced delimiters, resolved `AetherApplication` in `AndroidManifest.xml`, and present Gradle Wrapper. |
| `VER-AUD-01` | **1. Static Source Inspection + Native/Host Execution** | `ProjectAuditAndRepairEngine` rules executed against baseline commit `ab81048` vs. recovered `HEAD` | Executed repository audit verifier against actual repository files on disk | **PASSED**: Detected baseline defects (`allowBackup`, missing files) and verified 0 critical syntax/manifest defects in recovered `HEAD`. |
| `VER-WEB-01` | **1. Static Source Inspection** | `aether_ai_workstation_preview.html` | `python3 skills/web-app-generation/scripts/check_web_app.py` | **PASSED (`OK: no issues found`)** |
| `VER-KOT-01` | **2. Unit Test (Kotlin JUnit)** | `SecurityEngineTest.kt`, `ModelRouterTest.kt`, `AuditAndRepairTest.kt`, `LocalInferenceJniTest.kt` | Requires host with `kotlinc` / `./gradlew testDebugUnitTest` | **`BLOCKED_BY_ENVIRONMENT`** (Source syntax verified; execution requires host JDK + Gradle + Kotlin compiler). |
| `VER-INS-01` | **5. Android Instrumentation Test** | `app/src/androidTest/kotlin/com/aether/ai/WorkstationUiTest.kt` | Requires Android SDK + Emulator or connected device (`./gradlew connectedDebugAndroidTest`) | **`BLOCKED_BY_ENVIRONMENT`** (Compose UI test source authored; execution requires Android runtime). |
| `VER-EXT-01` | **6. Real External Service Integration Test** | OpenAI, Anthropic, Gemini, GitHub REST v3, Google Drive REST v3, Hugging Face Hub | Requires outbound internet + live OAuth/API credentials | **`BLOCKED_BY_ENVIRONMENT`** (Air-gapped sandbox container). |
| `VER-DEV-01` | **7. Physical-Device Validation** | Samsung Galaxy S22 Ultra (`SM-S908U` / `SM-S908B`) thermal throttling, Keystore TEE, NPU/Vulkan delegation | Requires physical Samsung Galaxy S22 Ultra connected via `adb` | **`BLOCKED_BY_ENVIRONMENT`** (No physical device attached to VM). |
