package com.aether.cloud.integrations

import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.inject.Inject
import javax.inject.Singleton

enum class CloudServiceType {
    GITHUB,
    GOOGLE_DRIVE,
    HUGGING_FACE,
    GITLAB,
    BITBUCKET,
    FIREBASE,
    SUPABASE,
    NOTION,
    FIGMA,
    TELEGRAM,
    GENERIC_REST,
    WEBHOOK
}

data class DriveFileItem(
    val id: String,
    val name: String,
    val mimeType: String,
    val sizeBytes: Long,
    val sha256Checksum: String?
)

data class DriveBackupManifest(
    val backupId: String,
    val projectId: String,
    val versionNumber: Int,
    val archiveSha256: String,
    val sizeBytes: Long,
    val createdEpochMs: Long
)

data class GitHubRepoSummary(
    val fullName: String,
    val htmlUrl: String,
    val defaultBranch: String,
    val isPrivate: Boolean
)

private fun escapeJsonStr(value: String): String =
    value.replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")

/**
 * Generates OAuth 2.0 PKCE S256 code verifiers/challenges, builds authorization URLs with CSRF state,
 * exchanges authorization codes, and refreshes access tokens.
 */
@Singleton
class OAuth2PkceManager @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient()
) {
    fun generateCodeVerifier(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }

    fun deriveS256CodeChallenge(codeVerifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(codeVerifier.toByteArray(Charsets.US_ASCII))
        return Base64.getUrlEncoder().withoutPadding().encodeToString(digest)
    }

    fun generateStateCsrfToken(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    }

    fun buildAuthorizationUrl(
        authorizationEndpoint: String,
        clientId: String,
        redirectUri: String,
        scope: String,
        codeChallenge: String,
        stateToken: String
    ): String {
        val encClient = URLEncoder.encode(clientId, "UTF-8")
        val encRedirect = URLEncoder.encode(redirectUri, "UTF-8")
        val encScope = URLEncoder.encode(scope, "UTF-8")
        val encChallenge = URLEncoder.encode(codeChallenge, "UTF-8")
        val encState = URLEncoder.encode(stateToken, "UTF-8")
        return "$authorizationEndpoint?response_type=code&client_id=$encClient&redirect_uri=$encRedirect&scope=$encScope&code_challenge=$encChallenge&code_challenge_method=S256&state=$encState"
    }

    fun exchangeAuthorizationCode(
        tokenEndpoint: String,
        clientId: String,
        authorizationCode: String,
        redirectUri: String,
        codeVerifier: String,
        expectedState: String,
        receivedState: String
    ): AetherResult<String> {
        if (expectedState.isBlank() || expectedState != receivedState) {
            return AetherResult.Error(
                "OAUTH_CSRF_STATE_MISMATCH",
                "OAuth 2.0 callback state parameter did not match expected CSRF token.",
                recoverable = false
            )
        }
        return runCatching {
            val form = "grant_type=authorization_code" +
                "&client_id=${URLEncoder.encode(clientId, "UTF-8")}" +
                "&code=${URLEncoder.encode(authorizationCode, "UTF-8")}" +
                "&redirect_uri=${URLEncoder.encode(redirectUri, "UTF-8")}" +
                "&code_verifier=${URLEncoder.encode(codeVerifier, "UTF-8")}"
            val req = Request.Builder()
                .url(tokenEndpoint)
                .header("Accept", "application/json")
                .post(form.toRequestBody("application/x-www-form-urlencoded".toMediaType()))
                .build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    return AetherResult.Error("OAUTH_CODE_EXCHANGE_HTTP_${resp.code}", resp.message)
                }
                resp.body?.string().orEmpty()
            }
        }.fold(
            onSuccess = { AetherResult.Success(it) },
            onFailure = { AetherResult.Error("OAUTH_EXCHANGE_ERROR", it.message ?: "Code exchange failed", it) }
        )
    }

    fun refreshAccessToken(
        tokenEndpoint: String,
        clientId: String,
        refreshToken: String
    ): AetherResult<String> = runCatching {
        val formBody = "grant_type=refresh_token&client_id=$clientId&refresh_token=$refreshToken"
            .toRequestBody("application/x-www-form-urlencoded".toMediaType())
        val request = Request.Builder()
            .url(tokenEndpoint)
            .header("Accept", "application/json")
            .post(formBody)
            .build()
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                return AetherResult.Error("OAUTH_REFRESH_FAILED", "HTTP ${response.code}")
            }
            response.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("OAUTH_NETWORK_ERROR", it.message ?: "Refresh error", it) }
    )
}

/**
 * GitHub REST API v3 client (https://api.github.com) supporting authenticated user profile,
 * repository listing/creation, issues, pull requests, and GitHub Actions workflow runs.
 * Distinct from local JGit operations.
 */
@Singleton
class GitHubRestClient @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient()
) {
    companion object {
        const val DEFAULT_API_BASE = "https://api.github.com"
        const val GITHUB_API_VERSION = "2022-11-28"
    }

    private fun Request.Builder.applyGitHubHeaders(token: String): Request.Builder =
        this.header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", GITHUB_API_VERSION)

    fun getAuthenticatedUser(token: String, baseUrl: String = DEFAULT_API_BASE): AetherResult<String> = runCatching {
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/user")
            .applyGitHubHeaders(token)
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_USER_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_USER_ERROR", it.message ?: "Failed to query /user", it) }
    )

    fun listRepositories(
        token: String,
        perPage: Int = 30,
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/user/repos?sort=updated&per_page=$perPage")
            .applyGitHubHeaders(token)
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_REPOS_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_REPOS_ERROR", it.message ?: "Failed to list repositories", it) }
    )

    fun createRepository(
        token: String,
        name: String,
        description: String,
        isPrivate: Boolean = true,
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val payload = """{"name":"${escapeJsonStr(name)}","description":"${escapeJsonStr(description)}","private":$isPrivate,"auto_init":true}"""
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/user/repos")
            .applyGitHubHeaders(token)
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_CREATE_REPO_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_CREATE_REPO_ERROR", it.message ?: "Failed to create repository", it) }
    )

    fun listIssues(
        token: String,
        owner: String,
        repo: String,
        state: String = "open",
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/repos/$owner/$repo/issues?state=$state")
            .applyGitHubHeaders(token)
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_ISSUES_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_ISSUES_ERROR", it.message ?: "Failed to list issues", it) }
    )

    fun createIssue(
        token: String,
        owner: String,
        repo: String,
        title: String,
        body: String,
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val payload = """{"title":"${escapeJsonStr(title)}","body":"${escapeJsonStr(body)}"}"""
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/repos/$owner/$repo/issues")
            .applyGitHubHeaders(token)
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_CREATE_ISSUE_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_CREATE_ISSUE_ERROR", it.message ?: "Failed to create issue", it) }
    )

    fun createPullRequest(
        token: String,
        owner: String,
        repo: String,
        title: String,
        headBranch: String,
        baseBranch: String = "main",
        body: String = "",
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val payload = """{"title":"${escapeJsonStr(title)}","head":"${escapeJsonStr(headBranch)}","base":"${escapeJsonStr(baseBranch)}","body":"${escapeJsonStr(body)}"}"""
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/repos/$owner/$repo/pulls")
            .applyGitHubHeaders(token)
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_PR_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_PR_ERROR", it.message ?: "Failed to create PR", it) }
    )

    fun listWorkflowRuns(
        token: String,
        owner: String,
        repo: String,
        baseUrl: String = DEFAULT_API_BASE
    ): AetherResult<String> = runCatching {
        val req = Request.Builder()
            .url("${baseUrl.trimEnd('/')}/repos/$owner/$repo/actions/runs?per_page=10")
            .applyGitHubHeaders(token)
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("GITHUB_ACTIONS_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("GITHUB_ACTIONS_ERROR", it.message ?: "Failed to list workflow runs", it) }
    )
}

@Singleton
class VerifiedDriveBackupService @Inject constructor() {
    fun verifyUploadedBackup(
        localArchiveBytes: ByteArray,
        remoteReportedSha256: String?,
        remoteReportedSizeBytes: Long
    ): AetherResult<DriveBackupManifest> {
        if (remoteReportedSha256.isNullOrBlank()) {
            return AetherResult.Error("DRIVE_SYNC_UNVERIFIED", "Remote Drive file metadata did not return a checksum.")
        }
        if (localArchiveBytes.size.toLong() != remoteReportedSizeBytes) {
            return AetherResult.Error(
                "DRIVE_SIZE_MISMATCH",
                "Uploaded size ($remoteReportedSizeBytes) does not match local archive (${localArchiveBytes.size})."
            )
        }
        val localHash = ChecksumVerifier.sha256Hex(localArchiveBytes)
        if (!localHash.equals(remoteReportedSha256, ignoreCase = true)) {
            return AetherResult.Error(
                "DRIVE_CHECKSUM_MISMATCH",
                "Remote Drive SHA-256 ($remoteReportedSha256) does not match local SHA-256 ($localHash)."
            )
        }
        return AetherResult.Success(
            DriveBackupManifest(
                backupId = "drv-bkp-${System.currentTimeMillis()}",
                projectId = "active-project",
                versionNumber = 1,
                archiveSha256 = localHash,
                sizeBytes = remoteReportedSizeBytes,
                createdEpochMs = System.currentTimeMillis()
            )
        )
    }
}

/**
 * Google Drive REST v3 API client implementing file listing, folder creation,
 * multipart archive upload, file download, and SHA-256 backup verification.
 */
@Singleton
class GoogleDriveRestClient @Inject constructor(
    private val httpClient: OkHttpClient = OkHttpClient(),
    private val backupVerifier: VerifiedDriveBackupService = VerifiedDriveBackupService()
) {
    fun listFiles(accessToken: String, folderId: String? = null): AetherResult<String> = runCatching {
        val query = if (folderId != null) "'$folderId' in parents and trashed = false" else "trashed = false"
        val url = "https://www.googleapis.com/drive/v3/files?q=${URLEncoder.encode(query, "UTF-8")}&fields=files(id,name,mimeType,size,sha256Checksum)"
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("DRIVE_LIST_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("DRIVE_LIST_ERROR", it.message ?: "Drive list failed", it) }
    )

    fun createFolder(accessToken: String, folderName: String, parentId: String? = null): AetherResult<String> = runCatching {
        val parentsJson = if (parentId != null) ""","parents":["${escapeJsonStr(parentId)}"]""" else ""
        val metadata = """{"name":"${escapeJsonStr(folderName)}","mimeType":"application/vnd.google-apps.folder"$parentsJson}"""
        val req = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files?fields=id,name")
            .header("Authorization", "Bearer $accessToken")
            .post(metadata.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("DRIVE_FOLDER_HTTP_${resp.code}", resp.message)
            }
            resp.body?.string().orEmpty()
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("DRIVE_FOLDER_ERROR", it.message ?: "Folder creation failed", it) }
    )

    fun uploadVerifiedBackup(
        accessToken: String,
        fileName: String,
        archiveBytes: ByteArray,
        parentFolderId: String? = null
    ): AetherResult<DriveBackupManifest> = runCatching {
        val parentsJson = if (parentFolderId != null) ""","parents":["${escapeJsonStr(parentFolderId)}"]""" else ""
        val metadataJson = """{"name":"${escapeJsonStr(fileName)}","mimeType":"application/zip"$parentsJson}"""
        val multipartBody = MultipartBody.Builder()
            .setType("multipart/related".toMediaType())
            .addPart(metadataJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .addPart(archiveBytes.toRequestBody("application/zip".toMediaType()))
            .build()

        val req = Request.Builder()
            .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,size,sha256Checksum")
            .header("Authorization", "Bearer $accessToken")
            .post(multipartBody)
            .build()

        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("DRIVE_UPLOAD_HTTP_${resp.code}", resp.message)
            }
            val bodyStr = resp.body?.string().orEmpty()
            val shaMatch = Regex("\"sha256Checksum\"\\s*:\\s*\"([0-9a-fA-F]{64})\"").find(bodyStr)?.groupValues?.get(1)
            val sizeMatch = Regex("\"size\"\\s*:\\s*\"?(\\d+)\"?").find(bodyStr)?.groupValues?.get(1)?.toLongOrNull() ?: -1L
            return backupVerifier.verifyUploadedBackup(archiveBytes, shaMatch, sizeMatch)
        }
    }.fold(
        onSuccess = { it },
        onFailure = { AetherResult.Error("DRIVE_UPLOAD_ERROR", it.message ?: "Drive upload failed", it) }
    )

    fun downloadFile(
        accessToken: String,
        fileId: String,
        destination: File,
        expectedSha256: String? = null
    ): AetherResult<File> = runCatching {
        val req = Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files/$fileId?alt=media")
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                return AetherResult.Error("DRIVE_DOWNLOAD_HTTP_${resp.code}", resp.message)
            }
            val bytes = resp.body?.bytes() ?: return AetherResult.Error("DRIVE_EMPTY_BODY", "Empty download stream")
            if (!expectedSha256.isNullOrBlank() && !ChecksumVerifier.verifySha256(bytes, expectedSha256)) {
                return AetherResult.Error("DRIVE_DOWNLOAD_CHECKSUM_MISMATCH", "Downloaded Drive file failed SHA-256 check.")
            }
            destination.parentFile?.mkdirs()
            destination.writeBytes(bytes)
            destination
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("DRIVE_DOWNLOAD_ERROR", it.message ?: "Drive download failed", it) }
    )
}
