package com.aether.cloud.integrations

import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CloudIntegrationTest {
    private val pkce = OAuth2PkceManager()
    private val verifier = VerifiedDriveBackupService()

    @Test
    fun `rejects OAuth callback when CSRF state does not match`() {
        val res = pkce.exchangeAuthorizationCode(
            tokenEndpoint = "https://github.com/login/oauth/access_token",
            clientId = "client-1",
            authorizationCode = "code-xyz",
            redirectUri = "aether://oauth2redirect",
            codeVerifier = pkce.generateCodeVerifier(),
            expectedState = "expected-state-123",
            receivedState = "tampered-state-999"
        )
        assertTrue(res is AetherResult.Error)
        assertEquals("OAUTH_CSRF_STATE_MISMATCH", (res as AetherResult.Error).code)
    }

    @Test
    fun `verifies Drive backup SHA-256 and rejects mismatched checksum`() {
        val payload = "AETHER_BACKUP_ARCHIVE".toByteArray(Charsets.UTF_8)
        val validSha = ChecksumVerifier.sha256Hex(payload)
        val ok = verifier.verifyUploadedBackup(payload, validSha, payload.size.toLong())
        assertTrue(ok is AetherResult.Success)

        val bad = verifier.verifyUploadedBackup(payload, "0".repeat(64), payload.size.toLong())
        assertTrue(bad is AetherResult.Error)
        assertEquals("DRIVE_CHECKSUM_MISMATCH", (bad as AetherResult.Error).code)
    }
}
