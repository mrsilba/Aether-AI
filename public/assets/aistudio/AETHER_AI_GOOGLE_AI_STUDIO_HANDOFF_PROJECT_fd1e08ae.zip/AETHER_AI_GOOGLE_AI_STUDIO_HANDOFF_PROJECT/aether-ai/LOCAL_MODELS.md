# AETHER AI — Local Model Runtime & Samsung Galaxy S22 Ultra Optimization

## Dual Runtime Architecture

1. **[Google AI Edge LiteRT-LM](https://developers.google.com/edge/litert-lm/android)** (`com.google.ai.edge:litert-lm:0.6.0`):
   - Primary runtime for `.litertlm` / `.task` quantized models (Gemma 3, Qwen 2.5, Phi-4 Mini, EmbeddingGemma).
   - Supports GPU delegation on Qualcomm Adreno 730 (`SM-S908U`) and Samsung Xclipse 920 (`SM-S908B`).
2. **[llama.cpp Android NDK JNI](https://github.com/ggml-org/llama.cpp/blob/master/docs/android.md)** (`aether_llama_jni.cpp`):
   - Primary runtime for `.gguf` models downloaded from Hugging Face.
   - Compiled with ARM64 `asimddp` (dot product), `i8mm` (8-bit integer matrix multiply), and `fphp` (FP16) intrinsics.

## Samsung Galaxy S22 Ultra Memory Budgets

| Device Variant | Total RAM | OS & IDE Reserve | Max Safe Model Allocation | Recommended Quantized Models |
| :--- | :--- | :--- | :--- | :--- |
| **Galaxy S22 Ultra (8 GB LPDDR5)** | 8,192 MB | 2,200 MB | **~3,200 MB** | `Qwen2.5-Coder-1.5B-Instruct-Q4_K_M` (~1.1 GB), `Llama-3.2-3B-Instruct-Q4_K_M` (~2.1 GB), `Phi-4-Mini-3.8B-Q4_K_M` (~2.5 GB) |
| **Galaxy S22 Ultra (12 GB LPDDR5)** | 12,288 MB | 2,200 MB | **~5,400 MB** | All 1.5B–3.8B models + `Qwen2.5-Coder-7B-Instruct-Q4_K_M` (~4.4 GB), `DeepSeek-R1-Distill-Qwen-7B-Q4_K_M` (~4.5 GB) |

## Thermal & Memory Protection Rules

- **Single Large Model Rule**: `LocalModelLifecycleManager` automatically unloads any active model and reclaims native heap before loading another model.
- **Thermal Throttling**: When `PowerManager` reports `THERMAL_STATUS_SEVERE` (3), worker threads drop to 2; on `THERMAL_STATUS_CRITICAL` (4), local inference pauses, checkpoints state, and unloads weights.
