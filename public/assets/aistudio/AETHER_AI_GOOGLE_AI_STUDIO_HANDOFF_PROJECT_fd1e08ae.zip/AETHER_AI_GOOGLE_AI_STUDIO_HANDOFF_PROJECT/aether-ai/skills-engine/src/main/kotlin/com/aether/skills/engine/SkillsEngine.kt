package com.aether.skills.engine

import com.aether.core.common.AetherResult
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class SkillManifest(
    val name: String,
    val version: String,
    val description: String,
    val instructions: String,
    val inputSchemaJson: String,
    val outputSchemaJson: String,
    val requiredTools: Set<String>,
    val requiredPermissions: Set<String>,
    val maxExecutionTimeMs: Long = 30_000L
)

/**
 * Validates and sandboxes imported skills. Treats every external skill as untrusted input.
 */
@Singleton
class SkillManager @Inject constructor() {
    private val promptInjectionPatterns = listOf(
        Regex("""ignore\s+(?:all\s+)?(?:previous|prior|system)\s+instructions""", RegexOption.IGNORE_CASE),
        Regex("""override\s+security\s+policy""", RegexOption.IGNORE_CASE),
        Regex("""disable\s+secret\s+scanner""", RegexOption.IGNORE_CASE),
        Regex("""exfiltrate\s+api\s+key""", RegexOption.IGNORE_CASE)
    )

    private val registeredSkills = mutableMapOf<String, SkillManifest>()

    fun validateAndSanitizeSkill(manifest: SkillManifest): AetherResult<SkillManifest> {
        if (manifest.name.isBlank() || manifest.version.isBlank()) {
            return AetherResult.Error("INVALID_SKILL_METADATA", "Skill name and version are required.")
        }
        for (pattern in promptInjectionPatterns) {
            if (pattern.containsMatchIn(manifest.instructions) || pattern.containsMatchIn(manifest.description)) {
                return AetherResult.Error(
                    code = "UNTRUSTED_SKILL_INJECTION_BLOCKED",
                    message = "Skill '${manifest.name}' contains prohibited security-override instructions matching '${pattern.pattern}'."
                )
            }
        }
        registeredSkills[manifest.name] = manifest
        return AetherResult.Success(manifest)
    }

    fun listRegisteredSkills(): List<SkillManifest> = registeredSkills.values.toList()

    fun loadSkillFromMarkdownFile(skillFile: File): AetherResult<SkillManifest> {
        if (!skillFile.exists() || !skillFile.isFile) {
            return AetherResult.Error("SKILL_FILE_NOT_FOUND", "Skill file not found: ${skillFile.path}")
        }
        val text = skillFile.readText(Charsets.UTF_8)
        val name = skillFile.parentFile?.name ?: skillFile.nameWithoutExtension
        val manifest = SkillManifest(
            name = name,
            version = "1.0.0",
            description = "Imported local skill ($name)",
            instructions = text,
            inputSchemaJson = "{}",
            outputSchemaJson = "{}",
            requiredTools = setOf("read_file", "search_repo"),
            requiredPermissions = setOf("READ_ONLY_ANALYSIS")
        )
        return validateAndSanitizeSkill(manifest)
    }
}
