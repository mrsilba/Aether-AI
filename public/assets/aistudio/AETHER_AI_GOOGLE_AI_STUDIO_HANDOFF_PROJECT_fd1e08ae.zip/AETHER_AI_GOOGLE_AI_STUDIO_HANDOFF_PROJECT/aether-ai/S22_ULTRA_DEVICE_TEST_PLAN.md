# AETHER AI — Samsung Galaxy S22 Ultra Acceptance & Integration Validation Plan

Target Hardware: **Samsung Galaxy S22 Ultra** (`SM-S908U` Snapdragon 8 Gen 1 / `SM-S908B` Exynos 2200, Android 14 / 15 One UI 6.1/7.0).

## Part I — Physical-Device Acceptance Test Plan (19 Mandatory Procedures)

| Test ID | Acceptance Area | Reproducible Step-by-Step Procedure | Expected Measurable Result |
| :--- | :--- | :--- | :--- |
| `S22-01` | **Application Installation** | 1. Enable *USB Debugging* on the Galaxy S22 Ultra.<br>2. Run `adb install -r app/build/outputs/apk/debug/app-debug.apk`.<br>3. Verify package signature and permissions via `adb shell dumpsys package com.aether.ai.workstation`. | APK installs with exit code `Success`; `android:allowBackup="false"` is enforced; zero runtime permission prompts on cold install. |
| `S22-02` | **Startup & Navigation** | 1. Launch `AETHER AI Workstation`.<br>2. Tap each of the 10 navigation rail items (`1. Dashboard` through `10. Settings`).<br>3. Rotate device between Portrait and Landscape / Samsung DeX mode. | Cold start completes in `< 1,500 ms` with zero `ClassNotFoundException`; all 10 destinations render without frame drops or state loss on rotation. |
| `S22-03` | **English LTR & Persian RTL** | 1. Tap the `English (LTR)` / `فارسی (RTL)` button in the top bar.<br>2. Inspect navigation rail placement, typography, and card alignment.<br>3. Tap again to return to `English (LTR)`. | `LocalLayoutDirection` switches immediately to `LayoutDirection.Rtl`; navigation rail moves to the right edge; Persian strings (`ایستگاه مهندسی هوش مصنوعی اِتر`) render cleanly. |
| `S22-04` | **API Provider Configuration** | 1. Open `5. Models` / `10. Settings`.<br>2. Add an API key (`sk-...`).<br>3. Inspect `/data/data/com.aether.ai.workstation/` and `adb logcat`. | `AndroidKeystoreVault` encrypts the key using hardware-backed `AES/GCM/NoPadding`; plaintext key never appears in `logcat` or unencrypted files. |
| `S22-05` | **Cloud Model Request** | 1. Select a configured Tier-3 cloud provider (OpenAI, Anthropic, or Gemini).<br>2. Send a coding prompt in `2. AI Workspace`. | `CloudAiExecutionClient` streams SSE tokens in real time; token latency and estimated cost update on completion. |
| `S22-06` | **Local Model Loading** | 1. Copy `aether_tiny_coder_q8_0.gguf` (or a `1.5B–7B Q8_0/Q4_0` GGUF model) into app storage.<br>2. Tap `Load Model` in `5. Models`. | `LocalModelLifecycleManager` verifies `totalRequiredMb <= maxSafeLocalModelRamMb` (`~5,400 MB` on 12 GB S22 Ultra; `~3,200 MB` on 8 GB S22 Ultra) and loads JNI handle `>= 1000`. |
| `S22-07` | **Offline Inference** | 1. Enable **Airplane Mode** on the Galaxy S22 Ultra.<br>2. Toggle workstation to `Offline Local` mode.<br>3. Enter prompt `fun add(a:Int,b:Int):Int{` and run generation. | Cloud providers are marked offline; `LlamaCppNativeBridge.nativeGenerateStream` executes on-device and streams ` return a + b }` with zero network traffic. |
| `S22-08` | **File Access (SAF & Local)** | 1. Open `4. Projects & Audit` and grant directory access via Android Storage Access Framework (`ACTION_OPEN_DOCUMENT_TREE`).<br>2. Browse the repository tree. | `scanRepositoryFromDisk` enumerates project files, detects `settings.gradle.kts`, and computes SHA-256 digests without `SecurityException`. |
| `S22-09` | **Project Editing (Sora Editor)** | 1. Open a `.kt` file in `2. AI Workspace`.<br>2. Edit code, trigger Undo/Redo, and open the Diff Viewer. | `SoraEditorComposeBridge` highlights syntax with line numbers; `DiffAndHistoryManager.computeUnifiedDiff` displays exact `+` / `-` lines. |
| `S22-10` | **Git Operations (JGit)** | 1. Open a local Git repository in the workspace.<br>2. Run `inspectStatus`, create a branch, stage a modified file, and commit via `JGitRepositoryController`. | JGit creates a valid Git commit SHA in `.git/objects` and updates `HEAD` cleanly. |
| `S22-11` | **Google Drive OAuth 2.0** | 1. Open `7. Integrations` -> `Google Drive`.<br>2. Initiate OAuth 2.0 PKCE flow (`S256` code challenge, `drive.file` scope). | System browser completes Google sign-in without ever asking for the user's password inside the app; refresh token is stored in `AndroidKeystoreVault`. |
| `S22-12` | **Backup & Restore** | 1. Trigger `uploadVerifiedBackup` for the active project.<br>2. Inspect `VerifiedDriveBackupService` result.<br>3. Download and restore to a clean directory. | Backup succeeds **only** after remote Drive `sha256Checksum` and `size` match local archive bytes. |
| `S22-13` | **Agent Tool Execution** | 1. Dispatch a multi-step coding objective in `3. Agents`.<br>2. Attempt an unallowlisted command (`rm -rf /`). | `SupervisorOrchestrator` executes topological DAG waves in parallel; `CommandGuardrailEngine` blocks `rm -rf /` with `RequiresExplicitApproval`. |
| `S22-14` | **Project Audit & Repair** | 1. Run `execute13StepAudit` on a test repo containing a hardcoded `sk-proj-...` key and a unit test.<br>2. Attempt a repair that deletes an `assertEquals` call. | Audit flags `AUD-0001 (CRITICAL)`; `verifyRepairDoesNotTamperWithTests` blocks the test-weakening edit with `TEST_TAMPERING_BLOCKED`. |
| `S22-15` | **Build & Preview** | 1. Open an HTML/JS file in `PreviewEngineController`.<br>2. Switch between `STATIC MOCKUP`, `LIVE DEV PREVIEW`, and `RUNNING COMPILED APK`. | Badge in top bar explicitly displays the active fidelity mode; APK mode triggers Android `PackageInstaller` intent only when a real `.apk` file is present. |
| `S22-16` | **Thermal Monitoring** | 1. Run sustained local inference or simulate thermal status via `adb shell cmd thermalservice override-status 3` (`SEVERE`) and `4` (`CRITICAL`). | On `3 (SEVERE)`, thread count drops from 4 to 2 and RAM budget scales to `60%`; on `4 (CRITICAL)`, `LocalModelLifecycleManager` blocks/unloads local models (`THERMAL_PROTECTION_ACTIVE`). |
| `S22-17` | **Memory Pressure** | 1. With a 7B model loaded, attempt to load a second model or simulate `onTrimMemory(TRIM_MEMORY_RUNNING_CRITICAL)`. | `LocalModelLifecycleManager.loadModel()` unloads the first model via `nativeUnloadModel` before allocating the second; oversized models return `INSUFFICIENT_SAFE_RAM` without crashing. |
| `S22-18` | **Battery Consumption** | 1. Switch power profile to `PowerProfileMode.BATTERY_SAVER`.<br>2. Inspect thread allocation and WorkManager constraints. | Thread count caps at `2`; background `AutomationTaskScheduler` jobs enforce `setRequiresBatteryNotLow(true)`. |
| `S22-19` | **Crash & Process Termination Recovery** | 1. Start a multi-wave Agent DAG task (saving `AgentCheckpointEntity` to Room).<br>2. Force-stop app via `adb shell am force-stop com.aether.ai.workstation`.<br>3. Relaunch app. | App reads `AgentCheckpointEntity` from SQLite, skips completed task IDs, and resumes pending DAG tasks from the last verified checkpoint. |

## Part II — External Integration Validation Procedures (Section 5)

> **Important**: None of these 8 live network validations were executed inside the air-gapped build container (`BLOCKED_BY_ENVIRONMENT`). Execute them on a connected test workstation/device using dedicated test accounts and least-privilege scopes:

1. **OpenAI-Compatible APIs (`OpenAiCompatibleAdapter` + `CloudAiExecutionClient`)**:
   - *Test Account*: Restricted project key (`sk-proj-...`) with `$1.00` monthly spend cap, or local `llama-server` / `Ollama` on `http://10.0.2.2:8080/v1`.
   - *Procedure*: Call `streamCompletion` with `gpt-4o-mini` and verify `SseStreamParser` emits content deltas and terminates on `data: [DONE]`.
2. **Anthropic Claude (`AnthropicClaudeAdapter`)**:
   - *Test Account*: Console workbench test key (`sk-ant-api03-...`) with low rate/spend tier.
   - *Procedure*: Send a single-turn request to `https://api.anthropic.com/v1/messages` with header `anthropic-version: 2023-06-01` and verify SSE `content_block_delta` parsing.
3. **Google Gemini (`GoogleGeminiAdapter`)**:
   - *Test Account*: Google AI Studio test API key restricted to `generativelanguage.googleapis.com`.
   - *Procedure*: Invoke `POST /v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse` with `x-goog-api-key` header and verify streamed `candidates[0].content.parts[0].text`.
4. **GitHub OAuth / REST API (`JGitRepositoryController` + GitHub PAT)**:
   - *Test Account*: Dedicated sandbox GitHub account with a Fine-Grained Personal Access Token scoped **only** to a single private test repository (`Contents: Read and write`).
   - *Procedure*: Run `cloneRepository`, `stageAndCommit`, and `pushToRemote` against the sandbox repository and verify commit appearance on GitHub.
5. **Google Drive OAuth / REST v3 (`OAuth2PkceManager` + `GoogleDriveRestClient`)**:
   - *Test Account*: Test Google user configured in Google Cloud Console OAuth Consent Screen with non-sensitive scope `https://www.googleapis.com/auth/drive.file` (accesses only files created by AETHER AI).
   - *Procedure*: Run `createFolder`, `uploadVerifiedBackup`, `listFiles`, and `downloadFile`; confirm `VerifiedDriveBackupService` validates matching remote `sha256Checksum`.
6. **Hugging Face Model Downloads (`HuggingFaceRegistryClient`)**:
   - *Test Account*: Read-only token (`hf_...`) or public repository access.
   - *Procedure*: Start downloading a small GGUF file (e.g., `SmolLM2-135M-Instruct-Q8_0.gguf`), interrupt network at 50%, reconnect, call `downloadModelResumable`, and verify `HTTP 206 Partial Content` resume + final SHA-256 match.
7. **MCP HTTP Transport (`McpHttpTransport`)**:
   - *Procedure*: Start a local test MCP HTTP JSON-RPC server (`python3 -m http.server` / FastAPI MCP fixture), send `buildInitializeRequest(1)` and `buildToolCallRequest(2, ...)`, and verify response is wrapped in `<untrusted_mcp_output>` with any secret patterns redacted.
8. **MCP STDIO Transport (`SandboxedTerminalSession` + `McpClientRuntime`)**:
   - *Procedure*: Spawn a local stdio MCP script via `ProcessBuilder`, write JSON-RPC `initialize` to `stdin`, read newline-delimited JSON-RPC from `stdout`, and verify permission enforcement when calling an unallowlisted tool (`MCP_TOOL_PERMISSION_DENIED`).
    
