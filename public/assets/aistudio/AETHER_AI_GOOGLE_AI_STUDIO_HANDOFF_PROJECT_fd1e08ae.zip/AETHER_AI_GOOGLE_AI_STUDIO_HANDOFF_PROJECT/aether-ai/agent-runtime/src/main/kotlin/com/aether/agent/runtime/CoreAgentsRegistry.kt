package com.aether.agent.runtime

enum class AgentRole {
    ARCHITECT,
    SENIOR_DEVELOPER,
    CODE_REVIEWER,
    DEBUGGER,
    SECURITY_AUDITOR,
    QA_ENGINEER,
    UI_UX_ANALYST,
    DATABASE_ENGINEER,
    DEVOPS_ENGINEER,
    RESEARCHER,
    DOCUMENTATION_WRITER,
    PROJECT_MANAGER
}

data class AgentDefinition(
    val role: AgentRole,
    val displayName: String,
    val systemInstructions: String,
    val allowedTools: Set<String>,
    val canMutateFiles: Boolean,
    val maxIterations: Int,
    val timeoutSeconds: Long
)

object CoreAgentsRegistry {
    val defaultAgents: List<AgentDefinition> = listOf(
        AgentDefinition(
            role = AgentRole.ARCHITECT,
            displayName = "Architect Agent",
            systemInstructions = "Design modular Clean Architecture boundaries, evaluate trade-offs, and detect cyclic dependencies.",
            allowedTools = setOf("read_file", "list_dir", "search_repo", "analyze_dependencies", "memory_read"),
            canMutateFiles = false,
            maxIterations = 12,
            timeoutSeconds = 120
        ),
        AgentDefinition(
            role = AgentRole.SENIOR_DEVELOPER,
            displayName = "Senior Developer Agent",
            systemInstructions = "Implement production-grade Kotlin, Java, Python, TypeScript, and C++ code adhering strictly to project architecture.",
            allowedTools = setOf("read_file", "write_file", "apply_patch", "search_repo", "format_code"),
            canMutateFiles = true,
            maxIterations = 20,
            timeoutSeconds = 180
        ),
        AgentDefinition(
            role = AgentRole.CODE_REVIEWER,
            displayName = "Code Review Agent",
            systemInstructions = "Inspect diffs for logic bugs, concurrency hazards, nullability issues, and API contract violations.",
            allowedTools = setOf("git_diff", "read_file", "search_repo"),
            canMutateFiles = false,
            maxIterations = 10,
            timeoutSeconds = 90
        ),
        AgentDefinition(
            role = AgentRole.DEBUGGER,
            displayName = "Debugging Agent",
            systemInstructions = "Analyze stack traces, logcat output, and compiler errors to isolate root causes and propose minimal fixes.",
            allowedTools = setOf("read_file", "search_repo", "inspect_build_logs", "run_unit_test"),
            canMutateFiles = false,
            maxIterations = 15,
            timeoutSeconds = 120
        ),
        AgentDefinition(
            role = AgentRole.SECURITY_AUDITOR,
            displayName = "Security Auditor Agent",
            systemInstructions = "Audit source code, manifests, and network clients for hardcoded secrets, insecure crypto, SQLi, and permission leaks.",
            allowedTools = setOf("read_file", "search_repo", "scan_secrets", "inspect_manifest"),
            canMutateFiles = false,
            maxIterations = 12,
            timeoutSeconds = 120
        ),
        AgentDefinition(
            role = AgentRole.QA_ENGINEER,
            displayName = "QA Engineer Agent",
            systemInstructions = "Write deterministic unit, integration, and edge-case tests without weakening assertions or deleting existing tests.",
            allowedTools = setOf("read_file", "write_test_file", "run_unit_test", "inspect_coverage"),
            canMutateFiles = true,
            maxIterations = 15,
            timeoutSeconds = 150
        ),
        AgentDefinition(
            role = AgentRole.UI_UX_ANALYST,
            displayName = "UI/UX Analyst Agent",
            systemInstructions = "Evaluate Jetpack Compose and Web layouts for accessibility, WCAG contrast, RTL Persian/LTR English support, and adaptive sizing.",
            allowedTools = setOf("read_file", "inspect_compose_tree", "capture_preview"),
            canMutateFiles = false,
            maxIterations = 10,
            timeoutSeconds = 90
        ),
        AgentDefinition(
            role = AgentRole.DATABASE_ENGINEER,
            displayName = "Database Engineer Agent",
            systemInstructions = "Audit Room entities, SQL queries, indices, foreign keys, and schema migrations.",
            allowedTools = setOf("read_file", "inspect_schema", "analyze_query_plan"),
            canMutateFiles = false,
            maxIterations = 10,
            timeoutSeconds = 90
        ),
        AgentDefinition(
            role = AgentRole.DEVOPS_ENGINEER,
            displayName = "DevOps Agent",
            systemInstructions = "Configure Gradle build scripts, version catalogs, CI pipelines, and remote build worker tasks.",
            allowedTools = setOf("read_file", "write_file", "run_build_check"),
            canMutateFiles = true,
            maxIterations = 12,
            timeoutSeconds = 120
        ),
        AgentDefinition(
            role = AgentRole.RESEARCHER,
            displayName = "Research Agent",
            systemInstructions = "Query project memory, documentation, and MCP resources to ground engineering decisions.",
            allowedTools = setOf("memory_search", "mcp_read_resource", "search_repo"),
            canMutateFiles = false,
            maxIterations = 10,
            timeoutSeconds = 90
        ),
        AgentDefinition(
            role = AgentRole.DOCUMENTATION_WRITER,
            displayName = "Documentation Agent",
            systemInstructions = "Maintain accurate architecture docs, API references, and changelogs synchronized with verified code changes.",
            allowedTools = setOf("read_file", "write_doc_file", "git_log"),
            canMutateFiles = true,
            maxIterations = 10,
            timeoutSeconds = 90
        ),
        AgentDefinition(
            role = AgentRole.PROJECT_MANAGER,
            displayName = "Project Manager Agent",
            systemInstructions = "Decompose user goals into milestone DAGs, track blockers, and verify acceptance criteria before marking tasks complete.",
            allowedTools = setOf("read_file", "memory_read", "memory_write", "checkpoint_status"),
            canMutateFiles = false,
            maxIterations = 10,
            timeoutSeconds = 90
        )
    )
}
