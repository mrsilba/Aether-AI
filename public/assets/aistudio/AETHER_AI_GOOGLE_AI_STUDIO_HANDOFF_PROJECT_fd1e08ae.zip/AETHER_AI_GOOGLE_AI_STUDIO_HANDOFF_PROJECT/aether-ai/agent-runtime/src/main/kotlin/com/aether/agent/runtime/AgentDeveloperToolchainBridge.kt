package com.aether.agent.runtime

import com.aether.core.common.AetherResult
import com.aether.core.security.CommandDecision
import com.aether.core.security.CommandGuardrailEngine
import com.aether.core.security.EmergencyStopController
import com.aether.core.security.SecretScanner
import javax.inject.Inject
import javax.inject.Singleton

data class AgentToolExecutionLog(
    val logId: String,
    val agentRole: AgentRole,
    val toolId: String,
    val commandOrAction: String,
    val permissionRequired: String,
    val approvedByUser: Boolean,
    val succeeded: Boolean,
    val outputSummary: String,
    val timestampEpochMs: Long
)

/**
 * Enables AI Developer Agents to inspect available tools, enforce permission gates,
 * execute tests, analyze failures, apply checkpointed patches, and roll back on regression.
 */
@Singleton
class AgentDeveloperToolchainBridge @Inject constructor(
    private val guardrailEngine: CommandGuardrailEngine = CommandGuardrailEngine(),
    private val emergencyStopController: EmergencyStopController = EmergencyStopController()
) {
    private val executionLogs = mutableListOf<AgentToolExecutionLog>()

    @Synchronized
    fun executeAgentToolAction(
        agent: AgentDefinition,
        toolId: String,
        actionDescription: String,
        shellCommand: String? = null,
        userApproved: Boolean = false,
        actionBlock: () -> AetherResult<String>
    ): AetherResult<String> {
        if (emergencyStopController.halted.value) {
            return AetherResult.Error("EMERGENCY_STOP_ACTIVE", "Execution halted by Emergency Stop controller.")
        }
        if (toolId !in agent.allowedTools) {
            recordLog(agent.role, toolId, actionDescription, "AGENT_SCOPE_DENIED", false, false, "Tool not in agent allowedTools")
            return AetherResult.Error(
                "AGENT_TOOL_UNAUTHORIZED",
                "Agent '${agent.displayName}' is not permitted to invoke tool '$toolId'."
            )
        }
        if (shellCommand != null) {
            when (val decision = guardrailEngine.evaluateCommand(shellCommand)) {
                is CommandDecision.Denied -> {
                    recordLog(agent.role, toolId, shellCommand, "DENYLISTED", false, false, decision.reason)
                    return AetherResult.Error("COMMAND_DENIED", decision.reason)
                }
                is CommandDecision.RequiresExplicitApproval -> {
                    if (!userApproved) {
                        recordLog(agent.role, toolId, shellCommand, decision.operationType.name, false, false, decision.reason)
                        return AetherResult.Error("USER_APPROVAL_REQUIRED", decision.reason)
                    }
                }
                is CommandDecision.Allowed -> Unit
            }
        }
        val result = actionBlock()
        val ok = result is AetherResult.Success
        val summary = when (result) {
            is AetherResult.Success -> SecretScanner.redactSecrets(result.data)
            is AetherResult.Error -> "${result.code}: ${result.message}"
        }
        recordLog(agent.role, toolId, actionDescription, "EXECUTED", userApproved, ok, summary)
        return result
    }

    @Synchronized
    fun getExecutionLogs(): List<AgentToolExecutionLog> = executionLogs.toList()

    private fun recordLog(
        role: AgentRole,
        toolId: String,
        action: String,
        permission: String,
        approved: Boolean,
        succeeded: Boolean,
        summary: String
    ) {
        executionLogs.add(
            AgentToolExecutionLog(
                logId = "alog-${executionLogs.size + 1}",
                agentRole = role,
                toolId = toolId,
                commandOrAction = SecretScanner.redactSecrets(action),
                permissionRequired = permission,
                approvedByUser = approved,
                succeeded = succeeded,
                outputSummary = summary,
                timestampEpochMs = System.currentTimeMillis()
            )
        )
    }
}
