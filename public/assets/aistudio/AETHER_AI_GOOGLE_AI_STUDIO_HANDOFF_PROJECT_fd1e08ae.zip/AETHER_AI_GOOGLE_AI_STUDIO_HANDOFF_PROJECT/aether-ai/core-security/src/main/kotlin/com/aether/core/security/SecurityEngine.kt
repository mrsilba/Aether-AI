package com.aether.core.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Hardware-backed AES-256-GCM Credential Vault using AndroidKeyStore.
 * Never exposes API keys in logs, crash dumps, or plaintext preferences.
 */
@Singleton
class AndroidKeystoreVault @Inject constructor() {
    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"
        private const val GCM_TAG_BITS = 128
        private const val GCM_IV_BYTES = 12
        private const val DEFAULT_KEY_ALIAS = "aether_master_aes256_gcm_key"
    }

    fun encryptCredential(plaintext: String): ByteArray {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        return ByteArray(1 + iv.size + ciphertext.size).apply {
            this[0] = iv.size.toByte()
            System.arraycopy(iv, 0, this, 1, iv.size)
            System.arraycopy(ciphertext, 0, this, 1 + iv.size, ciphertext.size)
        }
    }

    fun decryptCredential(payload: ByteArray): String {
        require(payload.size > GCM_IV_BYTES + 1) { "Invalid encrypted payload" }
        val ivLength = payload[0].toInt() and 0xFF
        val iv = payload.copyOfRange(1, 1 + ivLength)
        val ciphertext = payload.copyOfRange(1 + ivLength, payload.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return String(cipher.doFinal(ciphertext), Charsets.UTF_8)
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        val existing = keyStore.getEntry(DEFAULT_KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        if (existing != null) return existing.secretKey

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            DEFAULT_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }
}

enum class DangerousOperationType {
    DELETE_PROJECT_DIRECTORY,
    REPLACE_LARGE_FILE_SET,
    PUBLISH_RELEASE,
    GIT_FORCE_PUSH,
    MODIFY_SIGNING_CREDENTIALS,
    UNRESTRICTED_SHELL_EXECUTION,
    EXTERNAL_SENSITIVE_UPLOAD
}

data class SecretMatch(
    val ruleId: String,
    val description: String,
    val line: Int,
    val redactedPreview: String
)

/**
 * Scans outgoing prompts, logs, and repository files for leaked credentials.
 */
object SecretScanner {
    private val rules = listOf(
        "OPENAI_API_KEY" to Regex("""sk-(?:proj-|live-)?[A-Za-z0-9_-]{20,}"""),
        "ANTHROPIC_API_KEY" to Regex("""sk-ant-api03-[A-Za-z0-9_-]{20,}"""),
        "GOOGLE_AI_KEY" to Regex("""AIza[0-9A-Za-z_-]{35}"""),
        "GITHUB_PAT" to Regex("""gh[pousr]_[A-Za-z0-9_]{30,}"""),
        "HUGGINGFACE_TOKEN" to Regex("""hf_[A-Za-z0-9]{30,}"""),
        "AWS_ACCESS_KEY" to Regex("""AKIA[0-9A-Z]{16}"""),
        "PRIVATE_KEY_PEM" to Regex("""-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"""),
        "SLACK_TOKEN" to Regex("""xox[baprs]-[0-9A-Za-z-]{10,}""")
    )

    fun scanText(content: String): List<SecretMatch> {
        val findings = mutableListOf<SecretMatch>()
        content.lines().forEachIndexed { index, lineText ->
            for ((ruleId, regex) in rules) {
                val match = regex.find(lineText)
                if (match != null) {
                    val raw = match.value
                    val redacted = if (raw.length > 8) {
                        "${raw.take(4)}...[REDACTED]...${raw.takeLast(3)}"
                    } else "***REDACTED***"
                    findings.add(
                        SecretMatch(
                            ruleId = ruleId,
                            description = "Detected $ruleId pattern",
                            line = index + 1,
                            redactedPreview = redacted
                        )
                    )
                }
            }
        }
        return findings
    }

    fun redactSecrets(content: String): String {
        var sanitized = content
        for ((ruleId, regex) in rules) {
            sanitized = regex.replace(sanitized) { "[REDACTED:$ruleId]" }
        }
        return sanitized
    }
}

/**
 * Enforces command allowlists/denylists, blocks shell metacharacter injection and path traversal,
 * and requires explicit user approval for dangerous operations.
 */
@Singleton
class CommandGuardrailEngine @Inject constructor() {
    private val allowlistedBinaries = setOf(
        "git", "ls", "cat", "grep", "find", "head", "tail", "wc",
        "diff", "sha256sum", "python3", "java", "javac", "gradle", "./gradlew"
    )
    private val denylistedPatterns = listOf(
        Regex("""rm\s+-rf\s+/(?:\s|$)"""),
        Regex("""mkfs\."""),
        Regex("""dd\s+if="""),
        Regex("""chmod\s+-R\s+777"""),
        Regex("""curl\s+.*\|\s*(?:sh|bash)"""),
        Regex("""wget\s+.*\|\s*(?:sh|bash)"""),
        Regex("""su\s+-c"""),
        Regex("""git\s+push\s+.*--force"""),
        Regex("""[;&`]|(?:\|\|)|(?:&&)|(?:\$\()""")
    )

    fun evaluateCommand(command: String): CommandDecision {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return CommandDecision.Denied("Empty command")
        if (trimmed.contains("../") || trimmed.contains("..\\")) {
            return CommandDecision.Denied("Path traversal sequence ('..') is prohibited in sandboxed commands")
        }
        for (pattern in denylistedPatterns) {
            if (pattern.containsMatchIn(trimmed)) {
                return CommandDecision.RequiresExplicitApproval(
                    DangerousOperationType.UNRESTRICTED_SHELL_EXECUTION,
                    "Command matches high-risk denylist or shell-chaining pattern: ${pattern.pattern}"
                )
            }
        }
        val binary = trimmed.split(Regex("""\s+""")).first()
        if (binary !in allowlistedBinaries) {
            return CommandDecision.RequiresExplicitApproval(
                DangerousOperationType.UNRESTRICTED_SHELL_EXECUTION,
                "Binary '$binary' is not in the default sandbox allowlist"
            )
        }
        return CommandDecision.Allowed
    }
}

sealed interface CommandDecision {
    data object Allowed : CommandDecision
    data class RequiresExplicitApproval(
        val operationType: DangerousOperationType,
        val reason: String
    ) : CommandDecision
    data class Denied(val reason: String) : CommandDecision
}

/**
 * Global Emergency Stop switch that immediately halts active agent loops, tool calls,
 * local inference streams, and background workers.
 */
@Singleton
class EmergencyStopController @Inject constructor() {
    private val _halted = MutableStateFlow(false)
    val halted: StateFlow<Boolean> = _halted

    fun triggerEmergencyStop(reason: String): Long {
        _halted.value = true
        return System.currentTimeMillis()
    }

    fun resetAfterUserConfirmation() {
        _halted.value = false
    }
}
