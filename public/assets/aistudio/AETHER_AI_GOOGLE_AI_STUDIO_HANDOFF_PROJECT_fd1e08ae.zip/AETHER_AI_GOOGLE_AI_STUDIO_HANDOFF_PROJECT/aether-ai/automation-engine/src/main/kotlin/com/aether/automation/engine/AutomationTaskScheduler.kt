package com.aether.automation.engine

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

enum class AutomationWorkflowType {
    BACKUP_AFTER_MODIFICATION,
    RUN_TESTS_AFTER_COMMIT,
    GENERATE_PROJECT_REPORT,
    RESUME_INTERRUPTED_CHECKPOINT
}

class AetherAutomationWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val workflow = inputData.getString("workflow_type") ?: return Result.failure()
        val projectId = inputData.getString("project_id") ?: return Result.failure()
        val checkpointId = inputData.getString("checkpoint_id") ?: "chk-auto"

        val auditDir = File(applicationContext.noBackupFilesDir, "automation_journals")
        auditDir.mkdirs()
        val journalFile = File(auditDir, "${projectId}_${workflow.lowercase()}.log")
        val timestamp = System.currentTimeMillis()
        journalFile.appendText("[$timestamp] Executed workflow=$workflow project=$projectId checkpoint=$checkpointId\n")

        return Result.success(
            workDataOf(
                "completed_workflow" to workflow,
                "project_id" to projectId,
                "checkpoint_id" to checkpointId,
                "journal_path" to journalFile.absolutePath,
                "completed_at_ms" to timestamp
            )
        )
    }
}

@Singleton
class AutomationTaskScheduler @Inject constructor() {
    fun enqueueWorkflow(
        context: Context,
        workflowType: AutomationWorkflowType,
        projectId: String,
        checkpointId: String,
        requireUnmeteredNetwork: Boolean = false
    ) {
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(true)
            .setRequiredNetworkType(
                if (requireUnmeteredNetwork) NetworkType.UNMETERED else NetworkType.NOT_REQUIRED
            )
            .build()

        val workRequest = OneTimeWorkRequestBuilder<AetherAutomationWorker>()
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            .setInputData(
                workDataOf(
                    "workflow_type" to workflowType.name,
                    "project_id" to projectId,
                    "checkpoint_id" to checkpointId
                )
            )
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            "aether_${workflowType.name}_$projectId",
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }
}
