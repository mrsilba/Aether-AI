#include "../../main/cpp/aether_llama_jni.cpp"
#include "../../main/cpp/aether_polyglot_indexer_jni.cpp"
#include <cassert>
#include <cstdio>
#include <fstream>

static std::string resolve_model_path(int argc, char** argv) {
    if (argc > 1 && argv[1] != nullptr) {
        std::ifstream f(argv[1], std::ios::binary);
        if (f.good()) return std::string(argv[1]);
    }
    const char* candidates[] = {
        "local-inference/src/test/resources/aether_tiny_coder_q8_0.gguf",
        "src/test/resources/aether_tiny_coder_q8_0.gguf",
        "../resources/aether_tiny_coder_q8_0.gguf"
    };
    for (const char* c : candidates) {
        std::ifstream f(c, std::ios::binary);
        if (f.good()) return std::string(c);
    }
    return "local-inference/src/test/resources/aether_tiny_coder_q8_0.gguf";
}

int main(int argc, char** argv) {
    std::string model_path_str = resolve_model_path(argc, argv);
    const char* model_path = model_path_str.c_str();

    // 1. Inspect & parse real GGUF v3 binary file
    auto hdr = aether_native::inspect_gguf_file(model_path);
    assert(hdr.valid == true);
    assert(hdr.version == 3);
    assert(hdr.architecture == "llama");
    assert(hdr.block_count == 2);
    assert(hdr.embedding_length == 32);
    assert(hdr.head_count == 4);
    assert(hdr.head_count_kv == 2);
    assert(hdr.vocab_tokens.size() == 32);
    assert(hdr.tensors.size() == 21);
    std::printf("[1/9] GGUF_METADATA_PARSED: arch=%s, name=%s, layers=%u, dim=%u, heads=%u/%u, vocab=%zu, tensors=%zu\n",
                hdr.architecture.c_str(), hdr.model_name.c_str(), hdr.block_count,
                hdr.embedding_length, hdr.head_count, hdr.head_count_kv,
                hdr.vocab_tokens.size(), hdr.tensors.size());

    // 2. Initialize NativeInferenceSession and dequantize all 21 Q8_0/F32 tensors
    aether_native::NativeInferenceSession session(model_path, 512, 4);
    std::string err;
    bool ok = session.initialize(err);
    if (!ok) {
        std::fprintf(stderr, "Session init failed: %s\n", err.c_str());
        return 1;
    }
    std::printf("[2/9] MODEL_LOADED_AND_DEQUANTIZED: 21/21 Q8_0 & F32 tensors loaded into memory.\n");

    // 3. Tokenize prompt using GGUF tokenizer.ggml.tokens
    std::string prompt = "fun add(a:Int,b:Int):Int{";
    auto prompt_ids = session.tokenize(prompt);
    assert(prompt_ids.size() >= 10);
    std::printf("[3/9] PROMPT_TOKENIZED: prompt='%s' -> %zu token IDs [first=%d, last=%d]\n",
                prompt.c_str(), prompt_ids.size(), prompt_ids.front(), prompt_ids.back());

    // 4. Execute real multi-layer Transformer forward pass & stream generated tokens
    std::string streamed_text;
    int step_idx = 0;
    int32_t gen_count = session.generate_stream(
        prompt, 10, 0.0f,
        [&](const std::string& piece, int32_t tok_id, float logit) {
            step_idx++;
            streamed_text += piece;
            std::printf("      -> Stream Step %d: token_id=%d, piece='%s', max_logit=%.4f\n",
                        step_idx, tok_id, piece.c_str(), logit);
            return true;
        }
    );
    assert(gen_count == 5);
    assert(streamed_text == " return a + b }");
    std::printf("[4/9] TRANSFORMER_INFERENCE_VERIFIED: generated %d tokens -> '%s'\n",
                gen_count, streamed_text.c_str());

    // 5. Demonstrate mid-stream cancellation after 2 tokens
    std::string partial_text;
    int32_t cancelled_count = session.generate_stream(
        prompt, 10, 0.0f,
        [&](const std::string& piece, int32_t /*tok_id*/, float /*logit*/) {
            partial_text += piece;
            return partial_text != " return a";
        }
    );
    assert(cancelled_count == 2 && session.is_cancelled());
    std::printf("[5/9] STREAM_CANCELLATION_VERIFIED: halted at %d tokens ('%s'), is_cancelled=%d\n",
                cancelled_count, partial_text.c_str(), session.is_cancelled() ? 1 : 0);

    // 6. Verify Q4_K (Q4_K_M) and Q6_K 256-element k-quant super-block dequantization
    {
        const std::string tmp_q4k = "local-inference/src/test/resources/tmp_q4k_q6k_test.bin";
        {
            std::ofstream out(tmp_q4k, std::ios::binary);
            // Write 1 Q4_K super-block (144 bytes): d=0x3C00 (1.0f), dmin=0x0000 (0.0f), scales=2, qs=0x33
            uint16_t d_one = 0x3C00;
            uint16_t d_zero = 0x0000;
            uint8_t scales[12];
            std::memset(scales, 2, sizeof(scales));
            uint8_t qs[128];
            std::memset(qs, 0x33, sizeof(qs)); // low nibble=3, high nibble=3 -> d * 2 * 3 = 6.0f
            out.write(reinterpret_cast<const char*>(&d_one), 2);
            out.write(reinterpret_cast<const char*>(&d_zero), 2);
            out.write(reinterpret_cast<const char*>(scales), 12);
            out.write(reinterpret_cast<const char*>(qs), 128);

            // Write 1 Q6_K super-block (210 bytes) at offset 144: ql=0, qh=0, scales=1, d=0x3C00 (1.0f) -> (0 - 32) * 1.0 = -32.0f
            uint8_t ql[128] = {0};
            uint8_t qh[64] = {0};
            int8_t sc[16];
            std::memset(sc, 1, sizeof(sc));
            out.write(reinterpret_cast<const char*>(ql), 128);
            out.write(reinterpret_cast<const char*>(qh), 64);
            out.write(reinterpret_cast<const char*>(sc), 16);
            out.write(reinterpret_cast<const char*>(&d_one), 2);
        }
        std::ifstream in(tmp_q4k, std::ios::binary);
        aether_native::GgufTensorInfo t_q4k{"blk.0.attn_q.weight", {256}, aether_native::GGML_TYPE_Q4_K, 0, 256};
        std::vector<float> fp_q4k;
        std::string q_err;
        bool q4k_ok = aether_native::load_and_dequantize_tensor(in, 0, 354, t_q4k, fp_q4k, q_err);
        assert(q4k_ok && fp_q4k.size() == 256 && std::fabs(fp_q4k[0] - 6.0f) < 1e-4f);

        aether_native::GgufTensorInfo t_q6k{"blk.0.attn_v.weight", {256}, aether_native::GGML_TYPE_Q6_K, 144, 256};
        std::vector<float> fp_q6k;
        bool q6k_ok = aether_native::load_and_dequantize_tensor(in, 0, 354, t_q6k, fp_q6k, q_err);
        assert(q6k_ok && fp_q6k.size() == 256 && std::fabs(fp_q6k[0] - (-32.0f)) < 1e-4f);
        std::remove(tmp_q4k.c_str());
        std::printf("[6/9] K_QUANTS_DEQUANTIZATION_VERIFIED: Q4_K (fp32[0]=%.1f) and Q6_K (fp32[0]=%.1f) super-blocks verified.\n",
                    fp_q4k[0], fp_q6k[0]);
    }

    // 7. Verify bounds checking rejects truncated tensor payloads safely
    {
        std::ifstream in(model_path, std::ios::binary);
        aether_native::GgufTensorInfo bad_tensor{"corrupt.weight", {4096}, aether_native::GGML_TYPE_Q8_0, 9999999ULL, 4096};
        std::vector<float> bad_out;
        std::string bounds_err;
        bool bad_ok = aether_native::load_and_dequantize_tensor(in, 0, 1024, bad_tensor, bad_out, bounds_err);
        assert(!bad_ok && !bounds_err.empty());
        std::printf("[7/9] BOUNDS_CHECK_VERIFIED: rejected out-of-bounds tensor safely (%s).\n", bounds_err.c_str());
    }

    // 8. Verify C++17 Native Polyglot Symbol Indexer JNI
    {
        const char* sample_src =
            "class WorkstationEngine {\n"
            "    fun executeTask(id: String) {}\n"
            "}\n"
            "interface ToolBridge {}\n";
        char sym_json[512] = {0};
        int32_t sym_count = aether_c_index_symbols(sample_src, sym_json, sizeof(sym_json));
        assert(sym_count == 3);
        std::printf("[8/9] POLYGLOT_NATIVE_INDEXER_VERIFIED: extracted %d symbols -> %s\n", sym_count, sym_json);
    }

    // 9. Unload model and free memory via C/JNI bridge
    int64_t handle = aether_c_load_model(model_path, 512, 4);
    assert(handle >= 1000);
    aether_c_clear_kv_cache(handle);
    char c_buf[256] = {0};
    int32_t c_gen = aether_c_generate_stream(handle, prompt.c_str(), 10, c_buf, sizeof(c_buf));
    assert(c_gen == 5 && std::string(c_buf) == " return a + b }");
    int32_t unloaded = aether_c_unload_model(handle);
    assert(unloaded == 1);
    session.release_resources();
    assert(!session.is_loaded());
    std::printf("[9/9] MODEL_UNLOADED_SAFELY: C/JNI handle=%lld unloaded=%d, session resources freed.\n",
                static_cast<long long>(handle), unloaded);

    return 0;
}
