package com.aether.local.inference

import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import com.aether.core.common.AetherResult
import com.aether.observability.HardwareProfile
import com.aether.observability.ThermalState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

enum class LocalBackendType { LITERT_LM, LLAMA_CPP_GGUF }

data class LocalModelSpec(
    val modelId: String,
    val backendType: LocalBackendType,
    val filePath: String,
    val weightsSizeMb: Int,
    val numLayers: Int,
    val hiddenDim: Int,
    val defaultContextLength: Int = 4096
)

/**
 * JNI Bridge connecting Kotlin to `libaether_llama_jni.so`.
 */
@Singleton
class LlamaCppNativeBridge @Inject constructor() {
    companion object {
        var nativeLibraryLoaded: Boolean = false
            private set

        init {
            nativeLibraryLoaded = try {
                System.loadLibrary("aether_llama_jni")
                true
            } catch (_: UnsatisfiedLinkError) {
                false
            }
        }
    }

    external fun nativeLoadModel(modelPath: String, contextLength: Int, threads: Int): Long
    external fun nativeGenerateStream(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        outBuffer: ByteArray,
        outBufferCapacity: Int
    ): Int
    external fun nativeClearKvCache(handle: Long)
    external fun nativeCancel(handle: Long)
    external fun nativeUnloadModel(handle: Long): Boolean
    external fun nativeIndexSymbols(
        sourceCode: String,
        outBuffer: ByteArray,
        outBufferCapacity: Int
    ): Int
}

/**
 * Enforces strict single-large-model memory budgeting, KV-cache allocation,
 * thermal throttling, and native JNI / LiteRT-LM session execution.
 */
@Singleton
class LocalModelLifecycleManager @Inject constructor(
    private val nativeBridge: LlamaCppNativeBridge = LlamaCppNativeBridge()
) {
    private var activeModel: LocalModelSpec? = null
    private var activeNativeHandle: Long = -1L
    private var allocatedRamMb: Int = 0

    fun canLoadModel(
        spec: LocalModelSpec,
        contextLength: Int,
        hardware: HardwareProfile
    ): AetherResult<Int> {
        if (hardware.thermalState >= ThermalState.CRITICAL) {
            return AetherResult.Error(
                code = "THERMAL_PROTECTION_ACTIVE",
                message = "Device thermal state is ${hardware.thermalState}. Local LLM loading suspended to prevent overheating."
            )
        }
        val kvCacheMb = (((2L * spec.numLayers * spec.hiddenDim * contextLength * 2L) / (1024L * 1024L)) + 32L).toInt()
        val runtimeOverheadMb = 220
        val totalRequiredMb = spec.weightsSizeMb + kvCacheMb + runtimeOverheadMb

        if (totalRequiredMb > hardware.maxSafeLocalModelRamMb) {
            return AetherResult.Error(
                code = "INSUFFICIENT_SAFE_RAM",
                message = "Model '${spec.modelId}' requires ${totalRequiredMb}MB (weights=${spec.weightsSizeMb}MB, KV=${kvCacheMb}MB), exceeding safe budget of ${hardware.maxSafeLocalModelRamMb}MB."
            )
        }
        return AetherResult.Success(totalRequiredMb)
    }

    @Synchronized
    fun loadModel(
        spec: LocalModelSpec,
        contextLength: Int,
        hardware: HardwareProfile,
        threads: Int = 4
    ): AetherResult<String> {
        if (activeModel != null && activeModel?.modelId != spec.modelId) {
            unloadActiveModel()
        }
        return when (val check = canLoadModel(spec, contextLength, hardware)) {
            is AetherResult.Error -> check
            is AetherResult.Success -> {
                if (LlamaCppNativeBridge.nativeLibraryLoaded && spec.backendType == LocalBackendType.LLAMA_CPP_GGUF) {
                    val handle = nativeBridge.nativeLoadModel(spec.filePath, contextLength, threads)
                    if (handle < 0L) {
                        return AetherResult.Error("JNI_MODEL_LOAD_FAILED", "Native GGUF loader rejected ${spec.filePath}")
                    }
                    activeNativeHandle = handle
                }
                activeModel = spec
                allocatedRamMb = check.data
                AetherResult.Success("Loaded ${spec.modelId} (${check.data}MB allocated, handle=$activeNativeHandle)")
            }
        }
    }

    fun streamCompletion(prompt: String, maxTokens: Int = 128): Flow<String> = flow {
        val model = activeModel ?: throw IllegalStateException("No local model is currently loaded")
        if (LlamaCppNativeBridge.nativeLibraryLoaded && activeNativeHandle >= 0L) {
            val buf = ByteArray(8192)
            val count = nativeBridge.nativeGenerateStream(activeNativeHandle, prompt, maxTokens, buf, buf.size)
            if (count > 0) {
                val text = buf.decodeToString().trimEnd('\u0000')
                emit(text)
            }
        } else {
            emit("[Local ${model.modelId} offline fallback response for: ${prompt.take(40)}]")
        }
    }.flowOn(Dispatchers.IO)

    @Synchronized
    fun clearKvCache() {
        if (LlamaCppNativeBridge.nativeLibraryLoaded && activeNativeHandle >= 0L) {
            nativeBridge.nativeClearKvCache(activeNativeHandle)
        }
    }

    fun cancelActiveGeneration() {
        if (LlamaCppNativeBridge.nativeLibraryLoaded && activeNativeHandle >= 0L) {
            nativeBridge.nativeCancel(activeNativeHandle)
        }
    }

    @Synchronized
    fun unloadActiveModel(): Boolean {
        val hadModel = activeModel != null
        if (LlamaCppNativeBridge.nativeLibraryLoaded && activeNativeHandle >= 0L) {
            nativeBridge.nativeUnloadModel(activeNativeHandle)
        }
        activeNativeHandle = -1L
        activeModel = null
        allocatedRamMb = 0
        return hadModel
    }

    fun currentAllocatedRamMb(): Int = allocatedRamMb
    fun currentModel(): LocalModelSpec? = activeModel
}

/**
 * Dedicated Android Service designed to run in `:inference_service` process so native GGUF allocations
 * are isolated from the main UI heap and automatically respond to OS memory pressure callbacks.
 */
class IsolatedInferenceService : Service() {
    private val lifecycleManager = LocalModelLifecycleManager()

    inner class LocalInferenceBinder : Binder() {
        fun getManager(): LocalModelLifecycleManager = lifecycleManager
    }

    private val binder = LocalInferenceBinder()

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
            level >= ComponentCallbacks2.TRIM_MEMORY_COMPLETE
        ) {
            lifecycleManager.cancelActiveGeneration()
            lifecycleManager.unloadActiveModel()
        } else if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            lifecycleManager.clearKvCache()
        }
    }

    override fun onDestroy() {
        lifecycleManager.cancelActiveGeneration()
        lifecycleManager.unloadActiveModel()
        super.onDestroy()
    }
}
