# AETHER AI — Cloud Integration Hub

## Supported External Services

| Service | Authentication Flow | Supported Operations | Security & Verification Notes |
| :--- | :--- | :--- | :--- |
| **GitHub** | OAuth 2.0 PKCE / Fine-grained PAT | Repo list/browse, clone, issues, PRs, commits, branches, releases | Token encrypted in `AndroidKeystoreVault`; never prompts for raw GitHub password |
| **Google Drive** | Google Identity Services OAuth 2.0 (`drive.file` scope) | Browse, upload, download, versioned project backup & sync | `VerifiedDriveBackupService` verifies remote file size and SHA-256 digest before reporting backup success |
| **Hugging Face** | Bearer Token (`hf_...`) | GGUF / LiteRT-LM model search, metadata inspection, resumable download | HTTP `Range` header resume + post-download SHA-256 verification |
| **GitLab & Bitbucket** | OAuth 2.0 / Repository Tokens | Repo clone, merge requests, branch/commit inspection | Scoped per project |
| **Supabase & Firebase** | Service/Project API Keys (Keystore encrypted) | Schema inspection, edge function logs, REST diagnostics | Read-only by default; mutations require explicit approval |
| **Notion, Figma, Telegram, Webhooks** | OAuth 2.0 / Bot Token / Signed Webhook Secret | Spec retrieval, UI token inspection, build/audit notifications | Outgoing payloads scrubbed by `SecretScanner` |
