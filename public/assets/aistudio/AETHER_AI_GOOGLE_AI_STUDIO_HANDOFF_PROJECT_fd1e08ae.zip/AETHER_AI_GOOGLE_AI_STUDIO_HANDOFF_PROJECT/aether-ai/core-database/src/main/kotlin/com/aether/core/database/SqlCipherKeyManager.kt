package com.aether.core.database

import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import com.aether.core.security.AndroidKeystoreVault
import java.io.File
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.AEADBadTagException
import javax.inject.Inject
import javax.inject.Singleton

enum class DatabaseKeyState {
    KEY_CREATED_FIRST_RUN,
    KEY_RECOVERED_EXISTING,
    KEY_ROTATED_SUCCESSFULLY,
    KEY_UNAVAILABLE,
    KEY_INVALIDATED
}

data class UnwrappedDatabaseKey(
    val keyBytes: ByteArray,
    val keyState: DatabaseKeyState,
    val publicFingerprintSha256: String
) {
    fun zeroize() {
        keyBytes.fill(0)
    }
}

/**
 * Manages the 256-bit (32-byte) SQLCipher database encryption key using AndroidKeystoreVault
 * as the root of trust. Stores only the AES-256-GCM wrapped key material in app-private storage.
 * Never persists raw key bytes in SharedPreferences, logs, or plaintext files, and never
 * silently regenerates a new key if an encrypted database already exists on disk.
 */
@Singleton
class SqlCipherKeyManager @Inject constructor(
    private val keystoreVault: AndroidKeystoreVault
) {
    companion object {
        const val WRAPPED_KEY_FILENAME = "aether_sqlcipher_db_key.wrapped"
        const val KEY_SIZE_BYTES = 32
    }

    @Volatile
    var lastKeyFingerprintSha256: String = "UNINITIALIZED"
        private set

    fun getOrCreateDatabaseKey(
        keyStorageDir: File,
        encryptedDbFileExists: Boolean
    ): AetherResult<UnwrappedDatabaseKey> {
        keyStorageDir.mkdirs()
        val wrappedFile = File(keyStorageDir, WRAPPED_KEY_FILENAME)

        if (!wrappedFile.exists()) {
            if (encryptedDbFileExists) {
                return AetherResult.Error(
                    code = DatabaseKeyState.KEY_UNAVAILABLE.name,
                    message = "Encrypted database exists on disk, but wrapped key file '${wrappedFile.name}' is missing.",
                    recoverable = false
                )
            }
            return try {
                val rawKey = ByteArray(KEY_SIZE_BYTES).also { SecureRandom().nextBytes(it) }
                val encodedRawBase64 = Base64.getEncoder().withoutPadding().encodeToString(rawKey)
                val encryptedBlob = keystoreVault.encryptCredential(encodedRawBase64)
                wrappedFile.writeBytes(encryptedBlob)
                val fingerprint = ChecksumVerifier.sha256Hex("AETHER_KEY_CHECK:$encodedRawBase64".toByteArray(Charsets.UTF_8))
                lastKeyFingerprintSha256 = fingerprint
                AetherResult.Success(
                    UnwrappedDatabaseKey(
                        keyBytes = rawKey,
                        keyState = DatabaseKeyState.KEY_CREATED_FIRST_RUN,
                        publicFingerprintSha256 = fingerprint
                    )
                )
            } catch (e: Exception) {
                AetherResult.Error(
                    code = DatabaseKeyState.KEY_UNAVAILABLE.name,
                    message = "Failed to generate and wrap initial database key: ${e.message}",
                    cause = e,
                    recoverable = false
                )
            }
        }

        return try {
            val encryptedBlob = wrappedFile.readBytes()
            val decodedBase64 = keystoreVault.decryptCredential(encryptedBlob)
            val rawKey = Base64.getDecoder().decode(decodedBase64)
            if (rawKey.size != KEY_SIZE_BYTES) {
                rawKey.fill(0)
                return AetherResult.Error(
                    code = DatabaseKeyState.KEY_INVALIDATED.name,
                    message = "Unwrapped database key has unexpected length (${rawKey.size} != $KEY_SIZE_BYTES).",
                    recoverable = false
                )
            }
            val fingerprint = ChecksumVerifier.sha256Hex("AETHER_KEY_CHECK:$decodedBase64".toByteArray(Charsets.UTF_8))
            lastKeyFingerprintSha256 = fingerprint
            AetherResult.Success(
                UnwrappedDatabaseKey(
                    keyBytes = rawKey,
                    keyState = DatabaseKeyState.KEY_RECOVERED_EXISTING,
                    publicFingerprintSha256 = fingerprint
                )
            )
        } catch (e: AEADBadTagException) {
            AetherResult.Error(
                code = DatabaseKeyState.KEY_INVALIDATED.name,
                message = "AndroidKeyStore AES-GCM authentication tag mismatch (key invalidated or wrapped blob tampered).",
                cause = e,
                recoverable = false
            )
        } catch (e: Exception) {
            AetherResult.Error(
                code = DatabaseKeyState.KEY_INVALIDATED.name,
                message = "Keystore key unwrapping failed (${e.javaClass.simpleName}): ${e.message}",
                cause = e,
                recoverable = false
            )
        }
    }

    fun generateCandidateRotationKey(): ByteArray =
        ByteArray(KEY_SIZE_BYTES).also { SecureRandom().nextBytes(it) }

    fun commitRotatedDatabaseKey(
        keyStorageDir: File,
        newRawKey: ByteArray
    ): AetherResult<UnwrappedDatabaseKey> {
        require(newRawKey.size == KEY_SIZE_BYTES) { "Rotation key must be $KEY_SIZE_BYTES bytes" }
        keyStorageDir.mkdirs()
        val wrappedFile = File(keyStorageDir, WRAPPED_KEY_FILENAME)
        val backupFile = File(keyStorageDir, "$WRAPPED_KEY_FILENAME.bak")
        return try {
            if (wrappedFile.exists()) {
                wrappedFile.copyTo(backupFile, overwrite = true)
            }
            val encodedRawBase64 = Base64.getEncoder().withoutPadding().encodeToString(newRawKey)
            val encryptedBlob = keystoreVault.encryptCredential(encodedRawBase64)
            wrappedFile.writeBytes(encryptedBlob)
            backupFile.delete()
            val fingerprint = ChecksumVerifier.sha256Hex("AETHER_KEY_CHECK:$encodedRawBase64".toByteArray(Charsets.UTF_8))
            lastKeyFingerprintSha256 = fingerprint
            AetherResult.Success(
                UnwrappedDatabaseKey(
                    keyBytes = newRawKey.copyOf(),
                    keyState = DatabaseKeyState.KEY_ROTATED_SUCCESSFULLY,
                    publicFingerprintSha256 = fingerprint
                )
            )
        } catch (e: Exception) {
            if (backupFile.exists()) {
                backupFile.copyTo(wrappedFile, overwrite = true)
            }
            AetherResult.Error(
                code = DatabaseKeyState.KEY_UNAVAILABLE.name,
                message = "Failed to persist rotated wrapped key: ${e.message}",
                cause = e,
                recoverable = false
            )
        }
    }
}
