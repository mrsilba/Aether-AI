package com.aether.core.database

import com.aether.core.common.AetherResult
import com.aether.core.common.ChecksumVerifier
import net.sqlcipher.database.SQLiteDatabase
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

enum class MigrationOutcomeState {
    NO_PLAINTEXT_DB_FOUND,
    ENCRYPTED_DB_ALREADY_ACTIVE,
    MIGRATION_IN_PROGRESS,
    MIGRATION_COMPLETED,
    MIGRATION_FAILED_PRESERVED_BACKUP
}

data class MigrationExecutionReport(
    val state: MigrationOutcomeState,
    val tablesMigrated: Int,
    val totalRecordsVerified: Long,
    val backupFilePath: String?,
    val backupSha256: String?
)

/**
 * Safely migrates an existing legacy plaintext SQLite database (`aether_workspace.db`)
 * to a SQLCipher-encrypted database (`aether_encrypted.db`) using SQLCipher's official
 * `sqlcipher_export` convenience function.
 *
 * Strict guarantees:
 * 1. Never overwrites an already-valid encrypted destination database.
 * 2. Creates a SHA-256 verified `.pre_sqlcipher.bak` backup before migration.
 * 3. Writes to `.migration.tmp` first, reopens with the encryption key, and verifies table/record counts.
 * 4. Retires the original plaintext database file ONLY after verification succeeds.
 */
@Singleton
class SqlCipherMigrationEngine @Inject constructor() {

    companion object {
        private val SQLITE_PLAINTEXT_MAGIC = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII)
        private val MONITORED_TABLES = listOf(
            "ai_providers",
            "local_models",
            "projects",
            "agent_checkpoints",
            "project_memories",
            "security_audit_logs"
        )
    }

    fun isPlaintextSqliteFile(file: File): Boolean {
        if (!file.exists() || file.length() < SQLITE_PLAINTEXT_MAGIC.size) return false
        val header = ByteArray(SQLITE_PLAINTEXT_MAGIC.size)
        file.inputStream().use { ins ->
            val read = ins.read(header)
            if (read < SQLITE_PLAINTEXT_MAGIC.size) return false
        }
        return header.contentEquals(SQLITE_PLAINTEXT_MAGIC)
    }

    fun migrateIfPlaintextExists(
        plaintextDbFile: File,
        encryptedDbFile: File,
        keyBytes: ByteArray
    ): AetherResult<MigrationExecutionReport> {
        val tempEncryptedFile = File(encryptedDbFile.parentFile, "${encryptedDbFile.name}.migration.tmp")
        val backupFile = File(plaintextDbFile.parentFile, "${plaintextDbFile.name}.pre_sqlcipher.bak")

        // Clean up any leftover partial .tmp file from an interrupted prior run
        if (tempEncryptedFile.exists()) {
            tempEncryptedFile.delete()
        }

        // If no plaintext DB exists (and no interrupted backup waiting for recovery), nothing to migrate
        if (!plaintextDbFile.exists() && !backupFile.exists()) {
            val state = if (encryptedDbFile.exists()) {
                MigrationOutcomeState.ENCRYPTED_DB_ALREADY_ACTIVE
            } else {
                MigrationOutcomeState.NO_PLAINTEXT_DB_FOUND
            }
            return AetherResult.Success(MigrationExecutionReport(state, 0, 0L, null, null))
        }

        // Prevent accidental overwriting if valid encrypted DB already exists
        if (encryptedDbFile.exists() && !isPlaintextSqliteFile(encryptedDbFile) && encryptedDbFile.length() > 0L) {
            return AetherResult.Success(
                MigrationExecutionReport(
                    state = MigrationOutcomeState.ENCRYPTED_DB_ALREADY_ACTIVE,
                    tablesMigrated = 0,
                    totalRecordsVerified = 0L,
                    backupFilePath = backupFile.takeIf { it.exists() }?.absolutePath,
                    backupSha256 = null
                )
            )
        }

        // Recover source file if previous run was interrupted after backup creation
        val sourcePlaintext = if (plaintextDbFile.exists()) plaintextDbFile else backupFile
        if (!isPlaintextSqliteFile(sourcePlaintext)) {
            return AetherResult.Error(
                code = "DATABASE_CORRUPTION_DETECTED",
                message = "Legacy database file '${sourcePlaintext.name}' does not have a valid SQLite header.",
                recoverable = false
            )
        }

        return try {
            // Step 1: Create verified backup before touching source data
            val sourceBytes = sourcePlaintext.readBytes()
            val sourceSha256 = ChecksumVerifier.sha256Hex(sourceBytes)
            if (!backupFile.exists() || ChecksumVerifier.sha256Hex(backupFile.readBytes()) != sourceSha256) {
                backupFile.writeBytes(sourceBytes)
            }

            // Step 2: Open plaintext database and count source tables/rows
            val sourceRowCounts = mutableMapOf<String, Long>()
            val hexKey = keyBytes.joinToString("") { "%02x".format(it) }

            val plainDb = SQLiteDatabase.openDatabase(
                sourcePlaintext.absolutePath,
                "",
                null,
                SQLiteDatabase.OPEN_READWRITE
            )
            var userTableCount = 0
            try {
                plainDb.rawQuery(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%'",
                    null
                ).use { cursor ->
                    while (cursor.moveToNext()) {
                        val tableName = cursor.getString(0)
                        userTableCount++
                        plainDb.rawQuery("SELECT count(*) FROM `$tableName`", null).use { countCursor ->
                            if (countCursor.moveToFirst()) {
                                sourceRowCounts[tableName] = countCursor.getLong(0)
                            }
                        }
                    }
                }

                // Step 3: Attach temporary encrypted database and run sqlcipher_export
                plainDb.rawExecSQL("ATTACH DATABASE '${tempEncryptedFile.absolutePath}' AS encrypted KEY \"x'$hexKey'\";")
                plainDb.rawExecSQL("SELECT sqlcipher_export('encrypted');")
                plainDb.rawExecSQL("DETACH DATABASE encrypted;")
            } finally {
                plainDb.close()
            }

            // Step 4: Verify temporary encrypted database is NOT plaintext and matches all row counts
            if (!tempEncryptedFile.exists() || isPlaintextSqliteFile(tempEncryptedFile)) {
                tempEncryptedFile.delete()
                return AetherResult.Error(
                    code = "ENCRYPTION_INITIALIZATION_FAILED",
                    message = "Exported database failed encryption header check.",
                    recoverable = false
                )
            }

            var verifiedTotalRows = 0L
            val encDb = SQLiteDatabase.openDatabase(
                tempEncryptedFile.absolutePath,
                keyBytes,
                null,
                SQLiteDatabase.OPEN_READONLY,
                null,
                null
            )
            try {
                for ((tableName, expectedCount) in sourceRowCounts) {
                    encDb.rawQuery("SELECT count(*) FROM `$tableName`", null).use { c ->
                        val actual = if (c.moveToFirst()) c.getLong(0) else -1L
                        if (actual != expectedCount) {
                            throw IllegalStateException("Row count mismatch in table '$tableName': expected $expectedCount, got $actual")
                        }
                        verifiedTotalRows += actual
                    }
                }
            } finally {
                encDb.close()
            }

            // Step 5: Atomically promote temp encrypted file to final destination and retire plaintext file
            if (!tempEncryptedFile.renameTo(encryptedDbFile)) {
                tempEncryptedFile.copyTo(encryptedDbFile, overwrite = true)
                tempEncryptedFile.delete()
            }
            if (plaintextDbFile.exists()) {
                plaintextDbFile.delete()
            }

            AetherResult.Success(
                MigrationExecutionReport(
                    state = MigrationOutcomeState.MIGRATION_COMPLETED,
                    tablesMigrated = userTableCount,
                    totalRecordsVerified = verifiedTotalRows,
                    backupFilePath = backupFile.absolutePath,
                    backupSha256 = sourceSha256
                )
            )
        } catch (e: Exception) {
            tempEncryptedFile.delete()
            AetherResult.Error(
                code = MigrationOutcomeState.MIGRATION_FAILED_PRESERVED_BACKUP.name,
                message = "Plaintext-to-SQLCipher migration failed safely (backup preserved at ${backupFile.name}): ${e.message}",
                cause = e,
                recoverable = false
            )
        }
    }
}
