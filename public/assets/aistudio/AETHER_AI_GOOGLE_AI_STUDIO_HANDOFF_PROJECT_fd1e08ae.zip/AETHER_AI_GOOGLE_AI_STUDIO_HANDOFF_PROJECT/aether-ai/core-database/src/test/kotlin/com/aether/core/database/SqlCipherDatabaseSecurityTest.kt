package com.aether.core.database

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.SecureRandom

/**
 * Automated security verification tests for SQLCipher database encryption, key lifecycle,
 * raw header inspection, plaintext migration, and strict no-plaintext-fallback (Tests A–G).
 */
class SqlCipherDatabaseSecurityTest {

    private val migrationEngine = SqlCipherMigrationEngine()

    @Test
    fun `Test D - raw database inspection detects plaintext SQLite header vs encrypted salt`() {
        val tempPlain = File.createTempFile("aether_test_plain", ".db")
        val tempEnc = File.createTempFile("aether_test_enc", ".db")
        try {
            // Standard SQLite 3 header starts with 16-byte ASCII "SQLite format 3\u0000"
            val sqliteHeader = "SQLite format 3\u0000".toByteArray(Charsets.US_ASCII) + ByteArray(84)
            tempPlain.writeBytes(sqliteHeader)
            assertTrue(migrationEngine.isPlaintextSqliteFile(tempPlain))

            // SQLCipher encrypted database starts with a 16-byte random salt
            val randomSaltPage = ByteArray(100).also { SecureRandom().nextBytes(it) }
            // Ensure first 16 bytes do not accidentally match SQLite header
            randomSaltPage[0] = 0xAF.toByte()
            tempEnc.writeBytes(randomSaltPage)
            assertFalse(migrationEngine.isPlaintextSqliteFile(tempEnc))
        } finally {
            tempPlain.delete()
            tempEnc.delete()
        }
    }

    @Test
    fun `Test G - key unavailable when encrypted database exists but wrapped key file is missing`() {
        val tempDir = File(System.getProperty("java.io.tmpdir"), "aether_key_test_${System.nanoTime()}")
        tempDir.mkdirs()
        try {
            val manager = SqlCipherKeyManager(keystoreVault = com.aether.core.security.AndroidKeystoreVault())
            val res = manager.getOrCreateDatabaseKey(
                keyStorageDir = tempDir,
                encryptedDbFileExists = true
            )
            assertTrue(res is com.aether.core.common.AetherResult.Error)
            val err = res as com.aether.core.common.AetherResult.Error
            assertEquals(DatabaseKeyState.KEY_UNAVAILABLE.name, err.code)
        } finally {
            tempDir.deleteRecursively()
        }
    }
}
