package com.aether.core.database

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "ai_providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val providerType: String,
    val displayName: String,
    val baseUrl: String,
    val encryptedApiKeyBase64: String,
    val defaultModelId: String,
    val contextWindow: Int,
    val maxOutputTokens: Int,
    val supportsTools: Boolean,
    val supportsVision: Boolean,
    val supportsStreaming: Boolean,
    val inputCostPerMillionUsd: Double,
    val outputCostPerMillionUsd: Double,
    val timeoutMs: Long,
    val maxRetries: Int,
    val enabled: Boolean
)

@Entity(tableName = "local_models")
data class LocalModelEntity(
    @PrimaryKey val modelId: String,
    val displayName: String,
    val family: String,
    val format: String, // GGUF or LITERT_LM
    val quantization: String,
    val filePath: String,
    val sizeBytes: Long,
    val sha256Checksum: String,
    val contextLength: Int,
    val requiredRamMb: Int,
    val supportsTools: Boolean,
    val supportsEmbeddings: Boolean,
    val installedAtEpochMs: Long,
    val verified: Boolean
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val projectId: String,
    val name: String,
    val rootUriOrPath: String,
    val primaryLanguage: String,
    val buildSystem: String,
    val gitBranch: String?,
    val lastOpenedEpochMs: Long
)

@Entity(
    tableName = "agent_checkpoints",
    indices = [Index(value = ["projectId", "updatedAtEpochMs"])]
)
data class AgentCheckpointEntity(
    @PrimaryKey val checkpointId: String,
    val projectId: String,
    val objective: String,
    val serializedDagJson: String,
    val completedTaskIdsJson: String,
    val gitCommitOrSnapshotRef: String,
    val status: String, // RUNNING, PAUSED, COMPLETED, FAILED, ROLLED_BACK
    val updatedAtEpochMs: Long
)

@Entity(
    tableName = "project_memories",
    indices = [Index(value = ["projectId", "category", "updatedAtEpochMs"])]
)
data class ProjectMemoryEntity(
    @PrimaryKey val memoryId: String,
    val projectId: String,
    val category: String, // ARCHITECTURE, DECISIONS, CONSTRAINTS, PREFERENCES, MILESTONES, TASKS, DEFECTS, REPAIRS, TESTS, DOCS
    val title: String,
    val content: String,
    val verifiedState: Boolean,
    val embeddingBlobJson: String?,
    val updatedAtEpochMs: Long
)

@Entity(
    tableName = "security_audit_logs",
    indices = [Index(value = ["timestampEpochMs", "actionType"])]
)
data class SecurityAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestampEpochMs: Long,
    val actor: String,
    val actionType: String,
    val targetResource: String,
    val approvedByUser: Boolean,
    val outcome: String
)

@Entity(
    tableName = "conversation_sessions",
    indices = [Index(value = ["projectId", "updatedAtEpochMs"])]
)
data class ConversationSessionEntity(
    @PrimaryKey val conversationId: String,
    val projectId: String,
    val title: String,
    val activeModelId: String,
    val createdAtEpochMs: Long,
    val updatedAtEpochMs: Long
)

@Entity(
    tableName = "conversation_messages",
    indices = [Index(value = ["conversationId", "timestampEpochMs"])]
)
data class ConversationMessageEntity(
    @PrimaryKey val messageId: String,
    val conversationId: String,
    val role: String, // system, user, assistant, tool
    val content: String,
    val toolCallId: String?,
    val tokenCount: Int,
    val timestampEpochMs: Long
)

@Dao
interface AetherDao {
    @Query("SELECT * FROM ai_providers ORDER BY displayName ASC")
    fun observeProviders(): Flow<List<ProviderEntity>>

    @Query("SELECT * FROM ai_providers WHERE enabled = 1 ORDER BY displayName ASC")
    suspend fun getEnabledProviders(): List<ProviderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProvider(entity: ProviderEntity)

    @Query("SELECT * FROM local_models ORDER BY displayName ASC")
    fun observeLocalModels(): Flow<List<LocalModelEntity>>

    @Query("SELECT * FROM local_models WHERE verified = 1 ORDER BY installedAtEpochMs DESC")
    suspend fun getVerifiedLocalModels(): List<LocalModelEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLocalModel(entity: LocalModelEntity)

    @Query("SELECT * FROM projects ORDER BY lastOpenedEpochMs DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects ORDER BY lastOpenedEpochMs DESC")
    suspend fun getAllProjects(): List<ProjectEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(entity: ProjectEntity)

    @Query("SELECT * FROM agent_checkpoints WHERE projectId = :projectId ORDER BY updatedAtEpochMs DESC")
    suspend fun getCheckpointsForProject(projectId: String): List<AgentCheckpointEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCheckpoint(checkpoint: AgentCheckpointEntity)

    @Query("SELECT * FROM project_memories WHERE projectId = :projectId ORDER BY updatedAtEpochMs DESC")
    fun observeProjectMemories(projectId: String): Flow<List<ProjectMemoryEntity>>

    @Query("SELECT * FROM project_memories WHERE projectId = :projectId ORDER BY updatedAtEpochMs DESC")
    suspend fun getProjectMemoriesSnapshot(projectId: String): List<ProjectMemoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProjectMemory(memory: ProjectMemoryEntity)

    @Query("DELETE FROM project_memories WHERE memoryId = :memoryId AND projectId = :projectId")
    suspend fun deleteProjectMemory(memoryId: String, projectId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConversationSession(session: ConversationSessionEntity)

    @Query("SELECT * FROM conversation_sessions WHERE projectId = :projectId ORDER BY updatedAtEpochMs DESC")
    fun observeConversationSessions(projectId: String): Flow<List<ConversationSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversationMessage(message: ConversationMessageEntity)

    @Query("SELECT * FROM conversation_messages WHERE conversationId = :conversationId ORDER BY timestampEpochMs ASC")
    fun observeConversationMessages(conversationId: String): Flow<List<ConversationMessageEntity>>

    @Query("SELECT * FROM conversation_messages WHERE conversationId = :conversationId ORDER BY timestampEpochMs ASC")
    suspend fun getConversationMessagesSnapshot(conversationId: String): List<ConversationMessageEntity>

    @Insert
    suspend fun insertSecurityAuditLog(log: SecurityAuditLogEntity)

    @Query("SELECT * FROM security_audit_logs ORDER BY timestampEpochMs DESC LIMIT :limit")
    suspend fun getRecentSecurityAuditLogs(limit: Int = 50): List<SecurityAuditLogEntity>
}

@Database(
    entities = [
        ProviderEntity::class,
        LocalModelEntity::class,
        ProjectEntity::class,
        AgentCheckpointEntity::class,
        ProjectMemoryEntity::class,
        SecurityAuditLogEntity::class,
        ConversationSessionEntity::class,
        ConversationMessageEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AetherDatabase : RoomDatabase() {
    abstract fun aetherDao(): AetherDao

    companion object {
        val MIGRATION_1_2: Migration = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_project_memories_projectId_category_updatedAtEpochMs` ON `project_memories` (`projectId`, `category`, `updatedAtEpochMs`)"
                )
            }
        }
    }
}
