package com.aether.core.database

import android.content.Context
import androidx.room.Room
import com.aether.core.common.AetherResult
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteDatabaseHook
import net.sqlcipher.database.SupportFactory
import javax.inject.Inject
import javax.inject.Singleton

enum class EncryptedDatabaseState {
    UNINITIALIZED,
    FIRST_TIME_ENCRYPTED_CREATED,
    ENCRYPTED_OPENED_SUCCESSFULLY,
    MIGRATION_IN_PROGRESS,
    MIGRATION_COMPLETED,
    KEY_UNAVAILABLE,
    KEY_INVALIDATED,
    DATABASE_CORRUPTION_DETECTED,
    ENCRYPTION_INITIALIZATION_FAILED
}

class EncryptedDatabaseInitializationException(
    val failureState: EncryptedDatabaseState,
    override val message: String,
    override val cause: Throwable? = null
) : IllegalStateException("$failureState: $message", cause)

/**
 * Authoritative SQLCipher-backed Room database initializer.
 * Enforces strict no-plaintext-fallback: if key retrieval, migration, or SQLCipher header
 * verification fails, transitions to an explicit failure state and throws
 * [EncryptedDatabaseInitializationException] rather than opening an unencrypted database.
 */
@Singleton
class EncryptedDatabaseInitializer @Inject constructor(
    private val keyManager: SqlCipherKeyManager,
    private val migrationEngine: SqlCipherMigrationEngine
) {
    companion object {
        const val LEGACY_PLAINTEXT_DB_NAME = "aether_workspace.db"
        const val ENCRYPTED_DB_NAME = "aether_encrypted.db"
    }

    private val _state = MutableStateFlow(EncryptedDatabaseState.UNINITIALIZED)
    val state: StateFlow<EncryptedDatabaseState> = _state

    @Volatile
    private var activeDatabase: AetherDatabase? = null

    @Synchronized
    fun initializeEncryptedDatabase(context: Context): AetherDatabase {
        activeDatabase?.let { return it }

        // Step 1: Load native SQLCipher libraries (libsqlcipher.so)
        try {
            SQLiteDatabase.loadLibs(context)
        } catch (e: Throwable) {
            _state.value = EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED
            throw EncryptedDatabaseInitializationException(
                EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED,
                "Failed to load native SQLCipher libraries: ${e.message}",
                e
            )
        }

        val encryptedDbFile = context.getDatabasePath(ENCRYPTED_DB_NAME)
        val legacyPlaintextFile = context.getDatabasePath(LEGACY_PLAINTEXT_DB_NAME)
        encryptedDbFile.parentFile?.mkdirs()

        // Step 2: Reject if the target encrypted database file is actually a plaintext SQLite file
        if (encryptedDbFile.exists() && migrationEngine.isPlaintextSqliteFile(encryptedDbFile)) {
            _state.value = EncryptedDatabaseState.DATABASE_CORRUPTION_DETECTED
            throw EncryptedDatabaseInitializationException(
                EncryptedDatabaseState.DATABASE_CORRUPTION_DETECTED,
                "Target database '${encryptedDbFile.name}' contains an unencrypted SQLite header; refusing to open."
            )
        }

        // Step 3: Retrieve or generate Keystore-protected 256-bit SQLCipher key
        val unwrappedKey = when (
            val keyRes = keyManager.getOrCreateDatabaseKey(
                keyStorageDir = context.noBackupFilesDir,
                encryptedDbFileExists = encryptedDbFile.exists()
            )
        ) {
            is AetherResult.Success -> keyRes.data
            is AetherResult.Error -> {
                val mappedState = when (keyRes.code) {
                    DatabaseKeyState.KEY_UNAVAILABLE.name -> EncryptedDatabaseState.KEY_UNAVAILABLE
                    DatabaseKeyState.KEY_INVALIDATED.name -> EncryptedDatabaseState.KEY_INVALIDATED
                    else -> EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED
                }
                _state.value = mappedState
                throw EncryptedDatabaseInitializationException(mappedState, keyRes.message, keyRes.cause)
            }
        }

        // Step 4: Execute safe plaintext-to-encrypted migration if legacy plaintext DB exists
        var migrated = false
        if (legacyPlaintextFile.exists()) {
            _state.value = EncryptedDatabaseState.MIGRATION_IN_PROGRESS
            when (
                val migRes = migrationEngine.migrateIfPlaintextExists(
                    plaintextDbFile = legacyPlaintextFile,
                    encryptedDbFile = encryptedDbFile,
                    keyBytes = unwrappedKey.keyBytes
                )
            ) {
                is AetherResult.Success -> {
                    migrated = (migRes.data.state == MigrationOutcomeState.MIGRATION_COMPLETED)
                }
                is AetherResult.Error -> {
                    unwrappedKey.zeroize()
                    val failState = if (migRes.code == "DATABASE_CORRUPTION_DETECTED") {
                        EncryptedDatabaseState.DATABASE_CORRUPTION_DETECTED
                    } else {
                        EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED
                    }
                    _state.value = failState
                    throw EncryptedDatabaseInitializationException(failState, migRes.message, migRes.cause)
                }
            }
        }

        // Step 5: Build Room database with SQLCipher SupportFactory and postKey hardening hook
        val existedBeforeOpen = encryptedDbFile.exists()
        val cipherHook = object : SQLiteDatabaseHook {
            override fun preKey(database: SQLiteDatabase?) = Unit
            override fun postKey(database: SQLiteDatabase?) {
                database?.rawExecSQL("PRAGMA cipher_memory_security = ON;")
                database?.rawExecSQL("PRAGMA foreign_keys = ON;")
            }
        }

        return try {
            val passphraseCopy = unwrappedKey.keyBytes.copyOf()
            // clearPassphrase = true ensures SQLCipher zeroes passphraseCopy after key derivation
            val supportFactory = SupportFactory(passphraseCopy, cipherHook, true)
            val db = Room.databaseBuilder(
                context.applicationContext,
                AetherDatabase::class.java,
                ENCRYPTED_DB_NAME
            )
                .openHelperFactory(supportFactory)
                .addMigrations(AetherDatabase.MIGRATION_1_2)
                .build()

            // Force immediate SQLCipher key verification & header decryption check
            db.openHelper.writableDatabase.version

            // Verify on-disk file is not plaintext SQLite
            if (encryptedDbFile.exists() && migrationEngine.isPlaintextSqliteFile(encryptedDbFile)) {
                db.close()
                _state.value = EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED
                throw EncryptedDatabaseInitializationException(
                    EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED,
                    "Database file was written in plaintext despite SupportFactory configuration."
                )
            }

            _state.value = when {
                migrated -> EncryptedDatabaseState.MIGRATION_COMPLETED
                !existedBeforeOpen -> EncryptedDatabaseState.FIRST_TIME_ENCRYPTED_CREATED
                else -> EncryptedDatabaseState.ENCRYPTED_OPENED_SUCCESSFULLY
            }
            activeDatabase = db
            db
        } catch (e: EncryptedDatabaseInitializationException) {
            throw e
        } catch (e: Exception) {
            val msg = e.message.orEmpty()
            val failState = if (msg.contains("file is not a database", ignoreCase = true) ||
                msg.contains("hmac check failed", ignoreCase = true)
            ) {
                EncryptedDatabaseState.DATABASE_CORRUPTION_DETECTED
            } else {
                EncryptedDatabaseState.ENCRYPTION_INITIALIZATION_FAILED
            }
            _state.value = failState
            throw EncryptedDatabaseInitializationException(
                failState,
                "SQLCipher database failed to open with provided key: ${e.message}",
                e
            )
        } finally {
            unwrappedKey.zeroize()
        }
    }

    @Synchronized
    fun closeDatabase() {
        activeDatabase?.close()
        activeDatabase = null
    }
}

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideEncryptedAetherDatabase(
        @ApplicationContext context: Context,
        initializer: EncryptedDatabaseInitializer
    ): AetherDatabase = initializer.initializeEncryptedDatabase(context)

    @Provides
    @Singleton
    fun provideAetherDao(database: AetherDatabase): AetherDao = database.aetherDao()
}
