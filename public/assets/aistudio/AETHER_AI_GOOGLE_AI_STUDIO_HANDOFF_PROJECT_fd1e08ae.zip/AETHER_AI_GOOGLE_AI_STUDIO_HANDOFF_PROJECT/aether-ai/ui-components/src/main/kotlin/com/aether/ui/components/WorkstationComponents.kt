package com.aether.ui.components

import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ResizableSplitPane(
    initialLeftWeight: Float = 0.55f,
    leftContent: @Composable () -> Unit,
    rightContent: @Composable () -> Unit
) {
    var leftWeight by remember { mutableFloatStateOf(initialLeftWeight.coerceIn(0.25f, 0.75f)) }
    val dragState = rememberDraggableState { deltaPx ->
        val deltaWeight = deltaPx / 1200f
        leftWeight = (leftWeight + deltaWeight).coerceIn(0.25f, 0.75f)
    }

    Row(modifier = Modifier.fillMaxSize()) {
        Box(modifier = Modifier.weight(leftWeight).fillMaxHeight()) { leftContent() }
        VerticalDivider(
            modifier = Modifier
                .fillMaxHeight()
                .width(6.dp)
                .draggable(
                    state = dragState,
                    orientation = Orientation.Horizontal
                )
        )
        Box(modifier = Modifier.weight(1f - leftWeight).fillMaxHeight()) { rightContent() }
    }
}

@Composable
fun TelemetryMetricCard(title: String, primaryValue: String, subtitle: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, style = MaterialTheme.typography.labelMedium)
            Text(text = primaryValue, style = MaterialTheme.typography.titleMedium)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun UnifiedDiffReviewCard(
    filePath: String,
    diffLines: List<String>,
    onApprovePatch: () -> Unit,
    onRejectPatch: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Diff Review: $filePath", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRejectPatch) { Text("Reject") }
                    Button(onClick = onApprovePatch) { Text("Apply Patch") }
                }
            }
            diffLines.take(25).forEach { line ->
                Text(text = line, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
