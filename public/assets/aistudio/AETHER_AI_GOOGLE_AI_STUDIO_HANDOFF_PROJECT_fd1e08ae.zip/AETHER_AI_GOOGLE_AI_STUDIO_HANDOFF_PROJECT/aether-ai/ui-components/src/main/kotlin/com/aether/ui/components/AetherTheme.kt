package com.aether.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

val AetherCharcoalBg = Color(0xFF0B0E14)
val AetherSurfaceDark = Color(0xFF131822)
val AetherSurfaceElevated = Color(0xFF1C2331)
val AetherCyanAccent = Color(0xFF00E5FF)
val AetherVioletAccent = Color(0xFF7C4DFF)
val AetherBlueAccent = Color(0xFF2979FF)

private val DarkWorkstationScheme = darkColorScheme(
    primary = AetherCyanAccent,
    secondary = AetherVioletAccent,
    tertiary = AetherBlueAccent,
    background = AetherCharcoalBg,
    surface = AetherSurfaceDark,
    surfaceVariant = AetherSurfaceElevated,
    onPrimary = Color(0xFF001F24),
    onBackground = Color(0xFFE6EDF3),
    onSurface = Color(0xFFE6EDF3)
)

private val LightWorkstationScheme = lightColorScheme(
    primary = Color(0xFF006876),
    secondary = Color(0xFF5E35B1),
    tertiary = Color(0xFF1565C0),
    background = Color(0xFFF6F8FA),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEEF2F6)
)

@Composable
fun AetherWorkstationTheme(
    darkTheme: Boolean = true,
    isPersianRtl: Boolean = false,
    content: @Composable () -> Unit
) {
    val direction = if (isPersianRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(
            colorScheme = if (darkTheme) DarkWorkstationScheme else LightWorkstationScheme,
            content = content
        )
    }
}
