package com.aether.git.integration

import com.aether.core.common.AetherResult
import org.eclipse.jgit.api.Git
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider
import java.io.ByteArrayOutputStream
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class ConflictRegion(
    val filePath: String,
    val startLine: Int,
    val oursContent: String,
    val theirsContent: String
)

data class GitWorkingTreeStatus(
    val branch: String,
    val isClean: Boolean,
    val modifiedFiles: Set<String>,
    val untrackedFiles: Set<String>,
    val conflictingFiles: Set<String>
)

@Singleton
class GitConflictInspector @Inject constructor() {
    fun detectMergeConflicts(filePath: String, content: String): List<ConflictRegion> {
        val conflicts = mutableListOf<ConflictRegion>()
        val lines = content.lines()
        var idx = 0
        while (idx < lines.size) {
            if (lines[idx].startsWith("<<<<<<<")) {
                val startLine = idx + 1
                val ours = mutableListOf<String>()
                val theirs = mutableListOf<String>()
                idx++
                while (idx < lines.size && !lines[idx].startsWith("=======")) {
                    ours.add(lines[idx])
                    idx++
                }
                if (idx < lines.size && lines[idx].startsWith("=======")) idx++
                while (idx < lines.size && !lines[idx].startsWith(">>>>>>>")) {
                    theirs.add(lines[idx])
                    idx++
                }
                conflicts.add(
                    ConflictRegion(
                        filePath = filePath,
                        startLine = startLine,
                        oursContent = ours.joinToString("\n"),
                        theirsContent = theirs.joinToString("\n")
                    )
                )
            }
            idx++
        }
        return conflicts
    }

    fun resolveConflictMarkers(content: String, preferOurs: Boolean): String {
        val out = mutableListOf<String>()
        val lines = content.lines()
        var idx = 0
        while (idx < lines.size) {
            if (lines[idx].startsWith("<<<<<<<")) {
                val ours = mutableListOf<String>()
                val theirs = mutableListOf<String>()
                idx++
                while (idx < lines.size && !lines[idx].startsWith("=======")) {
                    ours.add(lines[idx])
                    idx++
                }
                if (idx < lines.size && lines[idx].startsWith("=======")) idx++
                while (idx < lines.size && !lines[idx].startsWith(">>>>>>>")) {
                    theirs.add(lines[idx])
                    idx++
                }
                out.addAll(if (preferOurs) ours else theirs)
            } else {
                out.add(lines[idx])
            }
            idx++
        }
        return out.joinToString("\n")
    }
}

/**
 * Real Eclipse JGit repository controller supporting init, clone, status, diff, stage, commit,
 * branch creation/checkout/listing, pull, push (with OAuth token), merge, and stash.
 */
@Singleton
class JGitRepositoryController @Inject constructor() {
    fun initRepository(directory: File): AetherResult<String> = runCatching {
        Git.init().setDirectory(directory).call().use { git ->
            git.repository.directory.absolutePath
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_INIT_ERROR", it.message ?: "Failed to init repo", it) }
    )

    fun cloneRepository(
        remoteUrl: String,
        targetDir: File,
        oauthToken: String? = null
    ): AetherResult<String> = runCatching {
        val cmd = Git.cloneRepository()
            .setURI(remoteUrl)
            .setDirectory(targetDir)
        if (!oauthToken.isNullOrBlank()) {
            cmd.setCredentialsProvider(UsernamePasswordCredentialsProvider("oauth2", oauthToken))
        }
        cmd.call().use { git -> git.repository.branch }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_CLONE_ERROR", it.message ?: "Clone failed", it) }
    )

    fun inspectStatus(repoDir: File): AetherResult<GitWorkingTreeStatus> = runCatching {
        Git.open(repoDir).use { git ->
            val status = git.status().call()
            GitWorkingTreeStatus(
                branch = git.repository.branch ?: "HEAD",
                isClean = status.isClean,
                modifiedFiles = status.modified + status.changed,
                untrackedFiles = status.untracked,
                conflictingFiles = status.conflicting
            )
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_STATUS_ERROR", it.message ?: "Status check failed", it) }
    )

    fun diffWorkingTree(repoDir: File): AetherResult<String> = runCatching {
        Git.open(repoDir).use { git ->
            val out = ByteArrayOutputStream()
            git.diff().setOutputStream(out).call()
            out.toString(Charsets.UTF_8.name())
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_DIFF_ERROR", it.message ?: "Diff failed", it) }
    )

    fun listBranches(repoDir: File): AetherResult<List<String>> = runCatching {
        Git.open(repoDir).use { git ->
            git.branchList().call().map { it.name.removePrefix("refs/heads/") }
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_BRANCH_LIST_ERROR", it.message ?: "Branch list failed", it) }
    )

    fun stageAndCommit(
        repoDir: File,
        authorName: String,
        authorEmail: String,
        message: String
    ): AetherResult<String> = runCatching {
        Git.open(repoDir).use { git ->
            git.add().addFilepattern(".").call()
            val revCommit = git.commit()
                .setAuthor(authorName, authorEmail)
                .setCommitter(authorName, authorEmail)
                .setMessage(message)
                .call()
            revCommit.name
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_COMMIT_ERROR", it.message ?: "Commit failed", it) }
    )

    fun createAndCheckoutBranch(repoDir: File, branchName: String): AetherResult<String> = runCatching {
        Git.open(repoDir).use { git ->
            git.checkout().setCreateBranch(true).setName(branchName).call()
            git.repository.branch
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_BRANCH_ERROR", it.message ?: "Branch checkout failed", it) }
    )

    fun pullFromRemote(repoDir: File, oauthToken: String? = null): AetherResult<Boolean> = runCatching {
        Git.open(repoDir).use { git ->
            val cmd = git.pull()
            if (!oauthToken.isNullOrBlank()) {
                cmd.setCredentialsProvider(UsernamePasswordCredentialsProvider("oauth2", oauthToken))
            }
            cmd.call().isSuccessful
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_PULL_ERROR", it.message ?: "Pull failed", it) }
    )

    fun pushToRemote(repoDir: File, oauthToken: String): AetherResult<Boolean> = runCatching {
        Git.open(repoDir).use { git ->
            git.push()
                .setCredentialsProvider(UsernamePasswordCredentialsProvider("oauth2", oauthToken))
                .call()
            true
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_PUSH_ERROR", it.message ?: "Push failed", it) }
    )

    fun stashChanges(repoDir: File): AetherResult<String> = runCatching {
        Git.open(repoDir).use { git ->
            val commit = git.stashCreate().call()
            commit?.name ?: "NO_LOCAL_CHANGES"
        }
    }.fold(
        onSuccess = { AetherResult.Success(it) },
        onFailure = { AetherResult.Error("JGIT_STASH_ERROR", it.message ?: "Stash failed", it) }
    )
}
