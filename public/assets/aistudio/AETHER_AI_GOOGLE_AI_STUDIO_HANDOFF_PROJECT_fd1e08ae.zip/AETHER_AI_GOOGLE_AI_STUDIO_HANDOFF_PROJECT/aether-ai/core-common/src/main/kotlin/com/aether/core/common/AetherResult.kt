package com.aether.core.common

import java.security.MessageDigest

sealed interface AetherResult<out T> {
    data class Success<T>(val data: T) : AetherResult<T>
    data class Error(
        val code: String,
        val message: String,
        val cause: Throwable? = null,
        val recoverable: Boolean = true
    ) : AetherResult<Nothing>
}

inline fun <T, R> AetherResult<T>.map(transform: (T) -> R): AetherResult<R> = when (this) {
    is AetherResult.Success -> AetherResult.Success(transform(data))
    is AetherResult.Error -> this
}

object ChecksumVerifier {
    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifySha256(bytes: ByteArray, expectedHex: String): Boolean {
        return sha256Hex(bytes).equals(expectedHex.trim(), ignoreCase = true)
    }
}
