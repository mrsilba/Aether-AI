package com.aether.terminal.engine

import com.aether.core.common.AetherResult
import com.aether.core.security.CommandDecision
import com.aether.core.security.CommandGuardrailEngine
import com.aether.core.security.SecretScanner
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

data class TerminalCommandResult(
    val command: String,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val durationMs: Long
)

/**
 * Executes allowlisted workspace commands inside a canonical-path-confined working directory
 * using ProcessBuilder with sanitized environment variables.
 */
@Singleton
class SandboxedTerminalSession @Inject constructor(
    private val guardrailEngine: CommandGuardrailEngine = CommandGuardrailEngine()
) {
    fun verifyWorkspaceConfinement(workingDirectory: File, allowedWorkspaceRoot: File?): Boolean {
        if (allowedWorkspaceRoot == null) return true
        return try {
            val workCanon = workingDirectory.canonicalPath
            val rootCanon = allowedWorkspaceRoot.canonicalPath
            workCanon == rootCanon || workCanon.startsWith("$rootCanon${File.separator}")
        } catch (_: Exception) {
            false
        }
    }

    fun executeCommand(
        commandLine: String,
        workingDirectory: File,
        timeoutSeconds: Long = 30L,
        explicitlyApprovedByUser: Boolean = false,
        allowedWorkspaceRoot: File? = null
    ): AetherResult<TerminalCommandResult> {
        if (!verifyWorkspaceConfinement(workingDirectory, allowedWorkspaceRoot)) {
            return AetherResult.Error(
                "WORKSPACE_CONFINEMENT_VIOLATION",
                "Working directory '${workingDirectory.path}' is outside the allowed workspace root."
            )
        }
        when (val decision = guardrailEngine.evaluateCommand(commandLine)) {
            is CommandDecision.Denied -> {
                return AetherResult.Error("TERMINAL_COMMAND_DENIED", decision.reason)
            }
            is CommandDecision.RequiresExplicitApproval -> {
                if (!explicitlyApprovedByUser) {
                    return AetherResult.Error(
                        code = "APPROVAL_REQUIRED_${decision.operationType.name}",
                        message = decision.reason
                    )
                }
            }
            is CommandDecision.Allowed -> Unit
        }

        return try {
            val startMs = System.currentTimeMillis()
            val tokens = commandLine.trim().split(Regex("""\s+"""))
            val pb = ProcessBuilder(tokens)
                .directory(workingDirectory)
                .redirectErrorStream(false)
            // Scrub sensitive credential environment variables from child processes
            pb.environment().keys.removeIf { key ->
                val upper = key.uppercase()
                upper.contains("KEY") || upper.contains("TOKEN") || upper.contains("SECRET") || upper.contains("PASSWORD")
            }
            val process = pb.start()

            val completed = process.waitFor(timeoutSeconds, TimeUnit.SECONDS)
            if (!completed) {
                process.destroyForcibly()
                return AetherResult.Error("TERMINAL_TIMEOUT", "Command timed out after ${timeoutSeconds}s")
            }
            val stdout = SecretScanner.redactSecrets(process.inputStream.bufferedReader().readText())
            val stderr = SecretScanner.redactSecrets(process.errorStream.bufferedReader().readText())
            val elapsed = System.currentTimeMillis() - startMs
            AetherResult.Success(
                TerminalCommandResult(
                    command = SecretScanner.redactSecrets(commandLine),
                    exitCode = process.exitValue(),
                    stdout = stdout,
                    stderr = stderr,
                    durationMs = elapsed
                )
            )
        } catch (e: Exception) {
            AetherResult.Error("TERMINAL_EXEC_ERROR", e.message ?: "Process execution failed", e)
        }
    }
}
