plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}
android {
    namespace = "com.aether.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.aether.ai.workstation"
        minSdk = 28
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-rc1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    buildFeatures {
        compose = true
    }
}
dependencies {
    implementation(project(":core-common"))
    implementation(project(":core-database"))
    implementation(project(":core-security"))
    implementation(project(":core-network"))
    implementation(project(":ai-providers"))
    implementation(project(":local-inference"))
    implementation(project(":model-manager"))
    implementation(project(":agent-runtime"))
    implementation(project(":agent-orchestrator"))
    implementation(project(":skills-engine"))
    implementation(project(":mcp-runtime"))
    implementation(project(":project-manager"))
    implementation(project(":code-editor"))
    implementation(project(":git-integration"))
    implementation(project(":cloud-integrations"))
    implementation(project(":memory-engine"))
    implementation(project(":semantic-search"))
    implementation(project(":terminal-engine"))
    implementation(project(":build-engine"))
    implementation(project(":preview-engine"))
    implementation(project(":automation-engine"))
    implementation(project(":observability"))
    implementation(project(":ui-components"))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.hilt.navigation.compose)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    androidTestImplementation(libs.junit)
}
