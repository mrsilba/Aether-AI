# AETHER AI — ProGuard / R8 Rules
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Keep JNI Native Bridge classes and methods
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.aether.local.inference.LlamaCppNativeBridge { *; }

# Keep Room Entities and Database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class * { *; }

# Keep Kotlinx Serialization generated serializers
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-if @kotlinx.serialization.Serializable class **
-keepclassmembers class <1> {
    static <1>$Companion Companion;
}

# JGit & SQLCipher rules
-keep class org.eclipse.jgit.** { *; }
-dontwarn org.eclipse.jgit.**
-keep class net.sqlcipher.** { *; }
    
