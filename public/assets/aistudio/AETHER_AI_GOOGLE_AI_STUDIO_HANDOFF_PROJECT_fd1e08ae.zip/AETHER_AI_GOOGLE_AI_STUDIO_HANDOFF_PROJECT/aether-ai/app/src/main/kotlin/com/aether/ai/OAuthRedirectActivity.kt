package com.aether.ai

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/**
 * Handles OAuth 2.0 PKCE Custom Tabs redirect URI (`aether://oauth2redirect?code=...&state=...`)
 * for GitHub and Google Drive authentication and forwards callback parameters to MainActivity.
 */
class OAuthRedirectActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uri = intent?.data
        val code = uri?.getQueryParameter("code").orEmpty()
        val state = uri?.getQueryParameter("state").orEmpty()
        val error = uri?.getQueryParameter("error").orEmpty()

        val forward = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("oauth_code", code)
            putExtra("oauth_state", state)
            putExtra("oauth_error", error)
        }
        startActivity(forward)
        finish()
    }
}
