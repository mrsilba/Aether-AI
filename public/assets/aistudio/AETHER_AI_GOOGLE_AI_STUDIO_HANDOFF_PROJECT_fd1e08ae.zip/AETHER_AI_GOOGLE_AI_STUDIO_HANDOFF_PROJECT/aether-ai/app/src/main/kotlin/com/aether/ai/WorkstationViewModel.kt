package com.aether.ai

import androidx.lifecycle.ViewModel
import com.aether.agent.orchestrator.AgentSubTask
import com.aether.agent.orchestrator.AutonomousAgentLoopEngine
import com.aether.agent.orchestrator.SupervisorOrchestrator
import com.aether.agent.runtime.AgentDefinition
import com.aether.agent.runtime.AgentRole
import com.aether.agent.runtime.CoreAgentsRegistry
import com.aether.ai.providers.ModelRouter
import com.aether.build.engine.DeveloperLibraryManager
import com.aether.build.engine.ProjectBuildExecutor
import com.aether.build.engine.ToolRegistryEntry
import com.aether.cloud.integrations.GitHubRestClient
import com.aether.cloud.integrations.GoogleDriveRestClient
import com.aether.cloud.integrations.OAuth2PkceManager
import com.aether.code.editor.DiffAndHistoryManager
import com.aether.code.editor.IndexedSymbol
import com.aether.code.editor.PolyglotLanguageEngine
import com.aether.core.common.AetherResult
import com.aether.core.database.AetherDao
import com.aether.core.database.EncryptedDatabaseInitializer
import com.aether.core.database.SqlCipherKeyManager
import com.aether.core.security.CommandGuardrailEngine
import com.aether.core.security.EmergencyStopController
import com.aether.core.security.SecretScanner
import com.aether.git.integration.JGitRepositoryController
import com.aether.local.inference.LocalBackendType
import com.aether.local.inference.LocalModelLifecycleManager
import com.aether.local.inference.LocalModelSpec
import com.aether.mcp.runtime.McpClientRuntime
import com.aether.mcp.runtime.McpServerConfig
import com.aether.memory.engine.MemoryCategory
import com.aether.memory.engine.MemoryRecord
import com.aether.memory.engine.ProjectMemoryIsolationEngine
import com.aether.observability.HardwareCapabilityAssessor
import com.aether.observability.HardwareProfile
import com.aether.preview.engine.PreviewEngineController
import com.aether.preview.engine.PreviewMode
import com.aether.project.manager.AuditFinding
import com.aether.project.manager.ProjectAuditAndRepairEngine
import com.aether.project.manager.RepositoryFileSnapshot
import com.aether.semantic.search.HybridSemanticSearchEngine
import com.aether.semantic.search.IndexedCodeChunk
import com.aether.skills.engine.SkillManager
import com.aether.terminal.engine.SandboxedTerminalSession
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject

data class WorkstationUiState(
    val activeDestination: WorkstationDestination = WorkstationDestination.DASHBOARD,
    val darkTheme: Boolean = true,
    val isPersianRtl: Boolean = false,
    val isOfflineMode: Boolean = false,
    val emergencyHalted: Boolean = false,
    val hardwareProfile: HardwareProfile,
    val databaseEncryptionStatus: String = "ENCRYPTED_SQLCIPHER_ACTIVE",
    val databaseKeyFingerprint: String = "UNINITIALIZED",
    val activeModelName: String = "Claude Sonnet 4.5 + Qwen2.5-Coder-7B (Q4_K_M)",
    val localAllocatedRamMb: Int = 0,
    val activeEditorFileName: String = "MainActivity.kt",
    val activeEditorContent: String = "package com.aether.ai\n\nclass WorkstationBootstrap {\n    fun verifyReady(): Boolean = true\n}",
    val indexedSymbols: List<IndexedSymbol> = emptyList(),
    val pendingDiffLines: List<String> = emptyList(),
    val previewBadge: String = PreviewMode.DEVELOPMENT_WEB_PREVIEW.badgeText,
    val agents: List<AgentDefinition> = CoreAgentsRegistry.defaultAgents,
    val activeWavePlanSummary: String = "Wave 1: [ARCHITECT, SECURITY_AUDITOR] -> Wave 2: [SENIOR_DEVELOPER] -> Wave 3: [QA_ENGINEER]",
    val auditFindings: List<AuditFinding> = emptyList(),
    val registeredTools: List<ToolRegistryEntry> = emptyList(),
    val mcpServers: List<McpServerConfig> = listOf(
        McpServerConfig(
            serverId = "mcp-filesystem",
            displayName = "Workspace Filesystem MCP",
            transportType = "STDIO_LOCAL",
            endpointOrCommand = "ls -la",
            allowedTools = setOf("read_file", "list_dir", "search_repo")
        ),
        McpServerConfig(
            serverId = "mcp-github",
            displayName = "GitHub Remote MCP (HTTPS)",
            transportType = "HTTP_SSE",
            endpointOrCommand = "https://api.github.com/mcp",
            allowedTools = setOf("list_issues", "create_pull_request")
        )
    ),
    val projectMemories: List<MemoryRecord> = emptyList(),
    val semanticSearchResults: List<IndexedCodeChunk> = emptyList(),
    val gitBranchStatus: String = "master (clean)",
    val oauthPkceChallengePreview: String = "",
    val terminalLogs: List<String> = listOf("$ git status -> On branch master, working tree clean")
)

@HiltViewModel
class WorkstationViewModel @Inject constructor(
    private val hardwareAssessor: HardwareCapabilityAssessor,
    private val emergencyStopController: EmergencyStopController,
    private val guardrailEngine: CommandGuardrailEngine,
    private val auditEngine: ProjectAuditAndRepairEngine,
    private val aetherDao: AetherDao,
    private val databaseInitializer: EncryptedDatabaseInitializer,
    private val sqlCipherKeyManager: SqlCipherKeyManager,
    private val modelRouter: ModelRouter,
    private val localModelManager: LocalModelLifecycleManager,
    private val supervisorOrchestrator: SupervisorOrchestrator,
    private val agentLoopEngine: AutonomousAgentLoopEngine,
    private val developerLibrary: DeveloperLibraryManager,
    private val polyglotEngine: PolyglotLanguageEngine,
    private val diffHistoryManager: DiffAndHistoryManager,
    private val gitController: JGitRepositoryController,
    private val gitHubClient: GitHubRestClient,
    private val googleDriveClient: GoogleDriveRestClient,
    private val oauthPkceManager: OAuth2PkceManager,
    private val mcpRuntime: McpClientRuntime,
    private val skillManager: SkillManager,
    private val memoryEngine: ProjectMemoryIsolationEngine,
    private val semanticSearchEngine: HybridSemanticSearchEngine,
    private val terminalSession: SandboxedTerminalSession,
    private val buildExecutor: ProjectBuildExecutor,
    private val previewController: PreviewEngineController
) : ViewModel() {

    private val initialHardware = hardwareAssessor.assessRuntimeHardware(
        buildModel = "SM-S908U",
        socHardware = "sm8450",
        gpuRenderer = "Adreno (TM) 730",
        totalRamMb = 12288,
        availableRamMb = 6800,
        availableStorageMb = 45000L,
        androidSdkInt = 35,
        cpuFlags = setOf("asimddp", "i8mm", "fphp"),
        thermalStatusCode = 0,
        batteryPercent = 88,
        isCharging = true
    )

    private val initialSampleCode =
        "package com.aether.ai\n\nclass WorkstationBootstrap {\n    fun verifyReady(): Boolean = true\n}"

    private val _uiState: MutableStateFlow<WorkstationUiState>
    val uiState: StateFlow<WorkstationUiState>

    init {
        diffHistoryManager.recordSnapshot(initialSampleCode)
        val initialSymbols = polyglotEngine.indexSymbolsInFile(
            filePath = "MainActivity.kt",
            language = "Kotlin",
            content = initialSampleCode
        )
        memoryEngine.storeMemory(
            MemoryRecord(
                id = "mem-arch-1",
                projectId = "aether-ai",
                category = MemoryCategory.PROJECT_ARCHITECTURE,
                title = "24-Module Clean Architecture & SQLCipher Room DB",
                statement = "All persistent data is encrypted via SupportFactory with AndroidKeystore AES-256-GCM wrapped 256-bit keys.",
                isVerifiedCurrentState = true,
                sourceCommitHash = "HEAD",
                timestampMs = System.currentTimeMillis()
            )
        )
        val verifier = oauthPkceManager.generateCodeVerifier()
        val challenge = oauthPkceManager.deriveS256CodeChallenge(verifier)

        _uiState = MutableStateFlow(
            WorkstationUiState(
                hardwareProfile = initialHardware,
                databaseEncryptionStatus = databaseInitializer.state.value.name,
                databaseKeyFingerprint = sqlCipherKeyManager.lastKeyFingerprintSha256,
                activeEditorContent = initialSampleCode,
                indexedSymbols = initialSymbols,
                registeredTools = developerLibrary.listAllTools(),
                projectMemories = memoryEngine.retrieveForProject("aether-ai"),
                oauthPkceChallengePreview = "S256:${challenge.take(24)}..."
            )
        )
        uiState = _uiState
    }

    fun selectDestination(dest: WorkstationDestination) {
        _uiState.update { it.copy(activeDestination = dest) }
    }

    fun toggleLanguageRtl() {
        _uiState.update { it.copy(isPersianRtl = !it.isPersianRtl) }
    }

    fun toggleDarkTheme() {
        _uiState.update { it.copy(darkTheme = !it.darkTheme) }
    }

    fun toggleOfflineMode() {
        _uiState.update { state ->
            val nextOffline = !state.isOfflineMode
            state.copy(
                isOfflineMode = nextOffline,
                activeModelName = if (nextOffline) {
                    "Qwen2.5-Coder-7B-Instruct (Q4_K_M • Local Offline)"
                } else {
                    "Claude Sonnet 4.5 + Qwen2.5-Coder-7B (Q4_K_M)"
                }
            )
        }
    }

    fun triggerEmergencyStop() {
        emergencyStopController.triggerEmergencyStop("User tapped Emergency Stop")
        localModelManager.cancelActiveGeneration()
        _uiState.update { it.copy(emergencyHalted = true) }
    }

    fun resumeFromEmergencyStop() {
        emergencyStopController.resetAfterUserConfirmation()
        _uiState.update { it.copy(emergencyHalted = false) }
    }

    fun updateEditorContent(newContent: String) {
        diffHistoryManager.recordSnapshot(_uiState.value.activeEditorContent)
        val symbols = polyglotEngine.indexSymbolsInFile(
            filePath = _uiState.value.activeEditorFileName,
            language = "Kotlin",
            content = newContent
        )
        val diff = diffHistoryManager.computeUnifiedDiff(_uiState.value.activeEditorContent, newContent)
        _uiState.update {
            it.copy(
                activeEditorContent = newContent,
                indexedSymbols = symbols,
                pendingDiffLines = diff
            )
        }
    }

    fun undoEditorChange() {
        val current = _uiState.value.activeEditorContent
        val prev = diffHistoryManager.undo(current) ?: return
        val symbols = polyglotEngine.indexSymbolsInFile(_uiState.value.activeEditorFileName, "Kotlin", prev)
        _uiState.update { it.copy(activeEditorContent = prev, indexedSymbols = symbols) }
    }

    fun redoEditorChange() {
        val current = _uiState.value.activeEditorContent
        val next = diffHistoryManager.redo(current) ?: return
        val symbols = polyglotEngine.indexSymbolsInFile(_uiState.value.activeEditorFileName, "Kotlin", next)
        _uiState.update { it.copy(activeEditorContent = next, indexedSymbols = symbols) }
    }

    fun runRepositoryAuditSample() {
        val snapshots = listOf(
            RepositoryFileSnapshot(
                relativePath = _uiState.value.activeEditorFileName,
                content = _uiState.value.activeEditorContent
            ),
            RepositoryFileSnapshot(
                relativePath = "settings.gradle.kts",
                content = "rootProject.name = \"AetherAI\""
            ),
            RepositoryFileSnapshot(
                relativePath = "gradle/wrapper/gradle-wrapper.properties",
                content = "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.10.2-bin.zip"
            )
        )
        val findings = auditEngine.execute13StepAudit(snapshots)
        _uiState.update { it.copy(auditFindings = findings) }
    }

    fun buildAgentWavePlan() {
        val tasks = listOf(
            AgentSubTask("t1", "Audit Architecture & Security", AgentRole.ARCHITECT),
            AgentSubTask("t2", "Verify SQLCipher & Keystore", AgentRole.SECURITY_AUDITOR),
            AgentSubTask("t3", "Implement Patch & Diff", AgentRole.SENIOR_DEVELOPER, dependsOn = setOf("t1", "t2")),
            AgentSubTask("t4", "Run Regression Verification", AgentRole.QA_ENGINEER, dependsOn = setOf("t3"))
        )
        when (val res = supervisorOrchestrator.buildParallelWaves(tasks)) {
            is AetherResult.Success -> {
                val formatted = res.data.mapIndexed { idx, wave ->
                    "Wave ${idx + 1}: ${wave.joinToString { it.assignedRole.name }}"
                }.joinToString(" -> ")
                _uiState.update { it.copy(activeWavePlanSummary = formatted) }
            }
            is AetherResult.Error -> {
                _uiState.update { it.copy(activeWavePlanSummary = "Error: ${res.message}") }
            }
        }
    }

    fun allocateLocalModel(spec: LocalModelSpec) {
        when (val res = localModelManager.loadModel(spec, spec.defaultContextLength, _uiState.value.hardwareProfile)) {
            is AetherResult.Success -> {
                _uiState.update {
                    it.copy(
                        activeModelName = "${spec.modelId} (Loaded • ${localModelManager.currentAllocatedRamMb()} MB)",
                        localAllocatedRamMb = localModelManager.currentAllocatedRamMb()
                    )
                }
            }
            is AetherResult.Error -> {
                _uiState.update {
                    it.copy(terminalLogs = it.terminalLogs + "[ModelManager] ${res.code}: ${res.message}")
                }
            }
        }
    }

    fun runSemanticSearch(query: String) {
        val chunks = semanticSearchEngine.chunkSourceFile(
            projectId = "aether-ai",
            filePath = _uiState.value.activeEditorFileName,
            content = _uiState.value.activeEditorContent
        )
        val ranked = semanticSearchEngine.rankChunks(
            projectId = "aether-ai",
            query = query,
            chunks = chunks
        )
        _uiState.update { it.copy(semanticSearchResults = ranked) }
    }

    fun runTerminalCommand(cmd: String) {
        val decision = guardrailEngine.evaluateCommand(cmd)
        val sanitized = SecretScanner.redactSecrets(cmd)
        _uiState.update { state ->
            state.copy(terminalLogs = state.terminalLogs + "$ $sanitized -> $decision")
        }
    }
}
