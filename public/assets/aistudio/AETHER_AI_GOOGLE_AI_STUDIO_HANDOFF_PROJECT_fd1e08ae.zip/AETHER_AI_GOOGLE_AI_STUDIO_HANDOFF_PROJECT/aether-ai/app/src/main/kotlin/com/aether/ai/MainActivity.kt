package com.aether.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aether.local.inference.LocalBackendType
import com.aether.local.inference.LocalModelSpec
import com.aether.ui.components.AetherWorkstationTheme
import com.aether.ui.components.ResizableSplitPane
import com.aether.ui.components.TelemetryMetricCard
import com.aether.ui.components.UnifiedDiffReviewCard
import dagger.hilt.android.AndroidEntryPoint

enum class WorkstationDestination(val titleEn: String, val titleFa: String) {
    DASHBOARD("1. Dashboard", "۱. داشبورد"),
    AI_WORKSPACE("2. AI Workspace", "۲. فضای کاری هوشمند"),
    AGENTS("3. Agents", "۳. ایجنت‌ها"),
    PROJECTS("4. Projects & Audit", "۴. پروژه‌ها و ممیزی"),
    MODELS("5. Models", "۵. مدل‌ها"),
    SKILLS("6. Skills & MCP", "۶. مهارت‌ها و MCP"),
    INTEGRATIONS("7. Integrations", "۷. یکپارچه‌سازی‌ها"),
    AUTOMATIONS("8. Automations", "۸. اتوماسیون"),
    MEMORY("9. Memory", "۹. حافظه پروژه"),
    SETTINGS("10. Settings", "۱۰. تنظیمات")
}

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val viewModel: WorkstationViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by viewModel.uiState.collectAsState()

            AetherWorkstationTheme(
                darkTheme = state.darkTheme,
                isPersianRtl = state.isPersianRtl
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    WorkstationRootScreen(
                        state = state,
                        onSelectDestination = viewModel::selectDestination,
                        onToggleRtl = viewModel::toggleLanguageRtl,
                        onToggleTheme = viewModel::toggleDarkTheme,
                        onToggleOffline = viewModel::toggleOfflineMode,
                        onEmergencyStop = viewModel::triggerEmergencyStop,
                        onResumeEmergency = viewModel::resumeFromEmergencyStop,
                        onUpdateEditorContent = viewModel::updateEditorContent,
                        onUndoEditor = viewModel::undoEditorChange,
                        onRedoEditor = viewModel::redoEditorChange,
                        onRunAudit = viewModel::runRepositoryAuditSample,
                        onBuildWavePlan = viewModel::buildAgentWavePlan,
                        onAllocateLocalModel = viewModel::allocateLocalModel,
                        onRunSemanticSearch = viewModel::runSemanticSearch,
                        onRunTerminalCommand = viewModel::runTerminalCommand
                    )
                }
            }
        }
    }
}

@Composable
fun WorkstationRootScreen(
    state: WorkstationUiState,
    onSelectDestination: (WorkstationDestination) -> Unit,
    onToggleRtl: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleOffline: () -> Unit,
    onEmergencyStop: () -> Unit,
    onResumeEmergency: () -> Unit,
    onUpdateEditorContent: (String) -> Unit,
    onUndoEditor: () -> Unit,
    onRedoEditor: () -> Unit,
    onRunAudit: () -> Unit,
    onBuildWavePlan: () -> Unit,
    onAllocateLocalModel: (LocalModelSpec) -> Unit,
    onRunSemanticSearch: (String) -> Unit,
    onRunTerminalCommand: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Top Telemetry & Security Bar
        Surface(tonalElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (state.isPersianRtl) "ایستگاه مهندسی هوش مصنوعی اِتر" else "AETHER AI WORKSTATION",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${state.hardwareProfile.deviceModel} • ${state.hardwareProfile.socModel} • Safe Budget: ${state.hardwareProfile.maxSafeLocalModelRamMb}MB • DB: ${state.databaseEncryptionStatus}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onToggleOffline) {
                        Text(if (state.isOfflineMode) "Offline Local" else "Hybrid Cloud+Local")
                    }
                    OutlinedButton(onClick = onToggleRtl) {
                        Text(if (state.isPersianRtl) "فارسی (RTL)" else "English (LTR)")
                    }
                    OutlinedButton(onClick = onToggleTheme) {
                        Text(if (state.darkTheme) "Dark" else "Light")
                    }
                    Button(
                        onClick = if (state.emergencyHalted) onResumeEmergency else onEmergencyStop,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(if (state.emergencyHalted) "RESUME" else "EMERGENCY STOP")
                    }
                }
            }
        }

        if (state.emergencyHalted) {
            Surface(color = MaterialTheme.colorScheme.errorContainer, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "EMERGENCY STOP ACTIVE: All agent loops, local JNI threads, and SSE streams halted.",
                    modifier = Modifier.padding(12.dp),
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }

        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
            // Navigation Rail across all 10 destinations
            NavigationRail(modifier = Modifier.fillMaxHeight()) {
                WorkstationDestination.entries.forEach { dest ->
                    NavigationRailItem(
                        selected = state.activeDestination == dest,
                        onClick = { onSelectDestination(dest) },
                        icon = { Text(dest.ordinal.plus(1).toString()) },
                        label = { Text(if (state.isPersianRtl) dest.titleFa else dest.titleEn) }
                    )
                }
            }

            // Active Destination Pane (Dedicated Compose Screen per Destination)
            Box(modifier = Modifier.weight(1f).fillMaxHeight().padding(16.dp)) {
                when (state.activeDestination) {
                    WorkstationDestination.DASHBOARD -> DashboardDestinationPane(state)
                    WorkstationDestination.AI_WORKSPACE -> AiWorkspaceDestinationPane(
                        state = state,
                        onUpdateEditorContent = onUpdateEditorContent,
                        onUndo = onUndoEditor,
                        onRedo = onRedoEditor,
                        onRunCommand = onRunTerminalCommand
                    )
                    WorkstationDestination.AGENTS -> AgentsDestinationPane(
                        state = state,
                        onBuildWavePlan = onBuildWavePlan
                    )
                    WorkstationDestination.PROJECTS -> ProjectsAuditDestinationPane(
                        state = state,
                        onRunAudit = onRunAudit
                    )
                    WorkstationDestination.MODELS -> ModelsDestinationPane(
                        state = state,
                        onAllocateLocalModel = onAllocateLocalModel
                    )
                    WorkstationDestination.SKILLS -> SkillsAndMcpDestinationPane(state)
                    WorkstationDestination.INTEGRATIONS -> IntegrationsDestinationPane(state)
                    WorkstationDestination.AUTOMATIONS -> AutomationsDestinationPane(state)
                    WorkstationDestination.MEMORY -> MemoryAndSemanticSearchPane(
                        state = state,
                        onRunSemanticSearch = onRunSemanticSearch
                    )
                    WorkstationDestination.SETTINGS -> SettingsAndSecurityDestinationPane(
                        state = state,
                        onToggleRtl = onToggleRtl,
                        onToggleTheme = onToggleTheme,
                        onToggleOffline = onToggleOffline
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardDestinationPane(state: WorkstationUiState) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            TelemetryMetricCard(
                title = "Active Hybrid Model & Routing",
                primaryValue = state.activeModelName,
                subtitle = "Recommended Backend: ${state.hardwareProfile.recommendedBackend}"
            )
        }
        item {
            TelemetryMetricCard(
                title = "Galaxy S22 Ultra Live Hardware Telemetry",
                primaryValue = "RAM: ${state.hardwareProfile.availableRamMb} MB free / ${state.hardwareProfile.totalRamMb} MB total",
                subtitle = "Thermal: ${state.hardwareProfile.thermalState} • Battery: ${state.hardwareProfile.batteryPercent}% • Safe Local Budget: ${state.hardwareProfile.maxSafeLocalModelRamMb} MB"
            )
        }
        item {
            TelemetryMetricCard(
                title = "SQLCipher & AndroidKeyStore Encryption Status",
                primaryValue = state.databaseEncryptionStatus,
                subtitle = "Key Fingerprint: ${state.databaseKeyFingerprint} • Plaintext Fallback: DISABLED"
            )
        }
    }
}

@Composable
fun AiWorkspaceDestinationPane(
    state: WorkstationUiState,
    onUpdateEditorContent: (String) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onRunCommand: (String) -> Unit
) {
    var commandInput by remember { mutableStateOf("git status") }
    ResizableSplitPane(
        initialLeftWeight = 0.58f,
        leftContent = {
            Column(modifier = Modifier.fillMaxSize().padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Editor: ${state.activeEditorFileName} (${state.previewBadge})", style = MaterialTheme.typography.titleSmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = onUndo) { Text("Undo") }
                        OutlinedButton(onClick = onRedo) { Text("Redo") }
                    }
                }
                OutlinedTextField(
                    value = state.activeEditorContent,
                    onValueChange = onUpdateEditorContent,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    label = { Text("Source Code (Sora Editor / Tree-sitter / TextMate Bridge)") }
                )
                Text(
                    text = "Indexed Symbols (${state.indexedSymbols.size}): " +
                        state.indexedSymbols.joinToString { "${it.kind}:${it.name}@L${it.line}" },
                    style = MaterialTheme.typography.labelSmall
                )
            }
        },
        rightContent = {
            Column(modifier = Modifier.fillMaxSize().padding(start = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sandboxed Terminal & Diff Review", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = commandInput,
                        onValueChange = { commandInput = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        label = { Text("Guardrailed Command") }
                    )
                    Button(onClick = { onRunCommand(commandInput) }) {
                        Text("Run")
                    }
                }
                if (state.pendingDiffLines.isNotEmpty()) {
                    UnifiedDiffReviewCard(
                        filePath = state.activeEditorFileName,
                        diffLines = state.pendingDiffLines,
                        onApprovePatch = {},
                        onRejectPatch = onUndo
                    )
                }
                Card(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    LazyColumn(modifier = Modifier.padding(8.dp)) {
                        items(state.terminalLogs) { log ->
                            Text(text = log, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun AgentsDestinationPane(
    state: WorkstationUiState,
    onBuildWavePlan: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Supervisor DAG & ReAct Orchestrator", style = MaterialTheme.typography.titleSmall)
                    Button(onClick = onBuildWavePlan) { Text("Verify DAG Waves") }
                }
                Text(state.activeWavePlanSummary, style = MaterialTheme.typography.bodySmall)
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.agents) { agent ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${agent.displayName} (${agent.role.name})", style = MaterialTheme.typography.titleSmall)
                        Text(agent.systemInstructions, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = "Allowed Tools: ${agent.allowedTools.joinToString(", ")} • Max Iterations: ${agent.maxIterations}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ProjectsAuditDestinationPane(
    state: WorkstationUiState,
    onRunAudit: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("13-Step Repository Forensic Audit & Controlled Repair", style = MaterialTheme.typography.titleMedium)
            Button(onClick = onRunAudit) { Text("Run 13-Step Audit") }
        }
        if (state.auditFindings.isEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "0 active findings in current workspace snapshot. Tap 'Run 13-Step Audit' to scan.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.auditFindings) { finding ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("[${finding.severity}] ${finding.id}: ${finding.category}", style = MaterialTheme.typography.titleSmall)
                            Text("${finding.affectedFile}:${finding.lineNumber} — ${finding.description}", style = MaterialTheme.typography.bodySmall)
                            Text("Fix: ${finding.recommendedSolution}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModelsDestinationPane(
    state: WorkstationUiState,
    onAllocateLocalModel: (LocalModelSpec) -> Unit
) {
    val catalog = remember {
        listOf(
            LocalModelSpec("Qwen2.5-Coder-1.5B-Q8_0", LocalBackendType.LLAMA_CPP_GGUF, "aether_tiny_coder_q8_0.gguf", 1650, 28, 1536, 4096),
            LocalModelSpec("Qwen2.5-Coder-7B-Q4_K_M", LocalBackendType.LLAMA_CPP_GGUF, "qwen2.5-coder-7b-q4_k_m.gguf", 4350, 28, 3584, 4096),
            LocalModelSpec("Gemma-2-2B-IT-LiteRT", LocalBackendType.LITERT_LM, "gemma2-2b-it.litertlm", 1400, 26, 2304, 4096)
        )
    }
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TelemetryMetricCard(
            title = "Local Inference Memory & Process Isolation (:inference_service)",
            primaryValue = "Allocated RAM: ${state.localAllocatedRamMb} MB / Safe Budget: ${state.hardwareProfile.maxSafeLocalModelRamMb} MB",
            subtitle = "Supported GGUF Quantizations: F32, F16, Q4_0, Q8_0, Q4_K (Q4_K_M), Q6_K"
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(catalog) { spec ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(spec.modelId, style = MaterialTheme.typography.titleSmall)
                            Text("Backend: ${spec.backendType} • Weights: ${spec.weightsSizeMb} MB • Ctx: ${spec.defaultContextLength}", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { onAllocateLocalModel(spec) }) {
                            Text("Load Model")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SkillsAndMcpDestinationPane(state: WorkstationUiState) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Model Context Protocol (MCP 2025-03-26) Servers & Skills Sandbox", style = MaterialTheme.typography.titleMedium)
        }
        items(state.mcpServers) { server ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${server.displayName} (${server.transportType})", style = MaterialTheme.typography.titleSmall)
                    Text("Endpoint/Cmd: ${server.endpointOrCommand}", style = MaterialTheme.typography.bodySmall)
                    Text("Allowed Tools: ${server.allowedTools.joinToString(", ")}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun IntegrationsDestinationPane(state: WorkstationUiState) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TelemetryMetricCard(
                title = "Eclipse JGit Local Repository Status",
                primaryValue = "Branch: ${state.gitBranchStatus}",
                subtitle = "Supported: init, clone, status, diff, branch, commit, pull, push, stash, conflict resolution"
            )
        }
        item {
            TelemetryMetricCard(
                title = "GitHub REST API v3 & OAuth 2.0 PKCE Redirect",
                primaryValue = "Redirect URI: aether://oauth2redirect",
                subtitle = "PKCE Challenge: ${state.oauthPkceChallengePreview} • Endpoints: /user, /user/repos, /issues, /pulls, /actions/runs"
            )
        }
        item {
            TelemetryMetricCard(
                title = "Google Drive v3 Verified Backup Sync",
                primaryValue = "SHA-256 Multipart Upload & Restore Verification Active",
                subtitle = "Rejects any backup where remote Drive SHA-256 or byte size differs from local archive."
            )
        }
    }
}

@Composable
fun AutomationsDestinationPane(state: WorkstationUiState) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("WorkManager Background Automations & Developer Library (${state.registeredTools.size} Tools)", style = MaterialTheme.typography.titleMedium)
        }
        items(state.registeredTools) { tool ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("${tool.displayName} (${tool.version})", style = MaterialTheme.typography.titleSmall)
                    Text(tool.description, style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = "Status: ${tool.installationStatus} • License: ${tool.licenseSpdx} • Env: ${tool.executionEnvironment}",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
fun MemoryAndSemanticSearchPane(
    state: WorkstationUiState,
    onRunSemanticSearch: (String) -> Unit
) {
    var query by remember { mutableStateOf("verifyReady") }
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Hybrid Cosine + BM25 Code & Memory Search") }
            )
            Button(onClick = { onRunSemanticSearch(query) }) {
                Text("Search")
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.projectMemories) { mem ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        val badge = if (mem.isVerifiedCurrentState) "[VERIFIED_CURRENT]" else "[HISTORICAL_UNVERIFIED]"
                        Text("$badge ${mem.title}", style = MaterialTheme.typography.titleSmall)
                        Text(mem.statement, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
            items(state.semanticSearchResults) { chunk ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Match: ${chunk.filePath} (L${chunk.startLine}–L${chunk.endLine})", style = MaterialTheme.typography.titleSmall)
                        Text(chunk.content, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsAndSecurityDestinationPane(
    state: WorkstationUiState,
    onToggleRtl: () -> Unit,
    onToggleTheme: () -> Unit,
    onToggleOffline: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            TelemetryMetricCard(
                title = "AndroidKeyStore AES-256-GCM Credential Vault & SQLCipher",
                primaryValue = "Database State: ${state.databaseEncryptionStatus}",
                subtitle = "Master Key Alias: aether_master_aes256_gcm_key • cipher_memory_security = ON • allowBackup = false"
            )
        }
        item {
            TelemetryMetricCard(
                title = "Network & Command Security Guardrails",
                primaryValue = "SSRF Private/Metadata Blocking: ENABLED • Shell Chaining Blocking: ENABLED",
                subtitle = "Blocks 169.254.169.254, 127.0.0.1, RFC1918 private IPs, path traversal ('..'), and unapproved shell metacharacters."
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onToggleRtl) {
                    Text(if (state.isPersianRtl) "Switch to English (LTR)" else "Switch to Persian (فارسی RTL)")
                }
                Button(onClick = onToggleTheme) {
                    Text(if (state.darkTheme) "Switch to Light Theme" else "Switch to Dark Theme")
                }
                Button(onClick = onToggleOffline) {
                    Text(if (state.isOfflineMode) "Enable Hybrid Cloud+Local" else "Force Offline Mode")
                }
            }
        }
    }
}
