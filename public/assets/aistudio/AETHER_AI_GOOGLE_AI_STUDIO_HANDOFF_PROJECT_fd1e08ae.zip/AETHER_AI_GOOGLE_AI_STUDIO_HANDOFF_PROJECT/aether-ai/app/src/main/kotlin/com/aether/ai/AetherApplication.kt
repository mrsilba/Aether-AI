package com.aether.ai

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AetherApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
    
