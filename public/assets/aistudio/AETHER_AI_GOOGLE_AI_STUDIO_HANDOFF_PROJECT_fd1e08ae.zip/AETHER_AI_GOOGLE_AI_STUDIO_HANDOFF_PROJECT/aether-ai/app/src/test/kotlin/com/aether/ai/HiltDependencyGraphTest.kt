package com.aether.ai

import com.aether.core.database.EncryptedDatabaseInitializer
import com.aether.core.database.EncryptedDatabaseState
import com.aether.core.database.SqlCipherKeyManager
import com.aether.core.database.SqlCipherMigrationEngine
import com.aether.core.security.AndroidKeystoreVault
import org.junit.Assert.assertEquals
import org.junit.Test

class HiltDependencyGraphTest {

    @Test
    fun `EncryptedDatabaseInitializer starts in UNINITIALIZED state before Context open`() {
        val keyManager = SqlCipherKeyManager(AndroidKeystoreVault())
        val migrationEngine = SqlCipherMigrationEngine()
        val initializer = EncryptedDatabaseInitializer(keyManager, migrationEngine)
        assertEquals(EncryptedDatabaseState.UNINITIALIZED, initializer.state.value)
    }
}
